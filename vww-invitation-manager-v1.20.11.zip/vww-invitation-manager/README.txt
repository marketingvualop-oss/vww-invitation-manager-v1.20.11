=== VWW Invitation Manager ===
Contributors: Vietnam Wedding Week
Tags: invitation, qr, checkin, contact form 7, excel, event
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.20.11

Quản lý đăng ký, Vé Mời, email QR, import/export Excel và check-in cho Vietnam Wedding Week.

== Phiên bản 1.20.11 ==
- Staff Export: Core POST Export qua admin-post.php, browser tải XLSX trực tiếp; bỏ Fetch/Blob/custom download route.
- Sửa Staff Export khi hosting/CDN gắn sai Content-Type cho dữ liệu XLSX.
- Frontend xác thực XLSX bằng chữ ký ZIP PK trước khi quyết định tải file.
- Chỉ giải mã response thành text khi body không phải XLSX, tránh hiển thị chuỗi binary PK.
- Tăng cache-busting riêng cho staff-center.js để hạn chế JS cũ còn lưu trên trình duyệt/CDN.
- Bổ sung header binary/nosniff cho response Excel.

== Phiên bản 1.20.9 ==
- Sửa bug Staff Export hiện “Đang tạo file Excel…” nhưng trình duyệt không tải file.
- Bỏ cơ chế submit download vào iframe ẩn; Staff Export dùng Fetch + Blob và kích hoạt tải `.xlsx` trực tiếp.
- Kiểm tra response HTTP, Content-Type, dung lượng và chữ ký ZIP/XLSX trước khi tải để tránh file lỗi/corrupt.
- Backend trả lỗi rõ cho Staff khi nonce hết hạn, thiếu quyền, không tạo được file tạm hoặc máy chủ thiếu ZipArchive.
- Làm sạch output buffer trước khi stream XLSX để tránh warning/HTML chen vào làm hỏng file.
- Giữ nguyên bộ lọc, chọn field, export theo khách đã chọn/toàn bộ kết quả và Ngày Check-in của v1.20.8.

== Phiên bản 1.20.8 ==
- Camera Staff Check-in mặc định tắt; chỉ mở sau khi bấm “Mở camera”. Chuyển sang tab Khách mời sẽ tắt camera và quay lại tab QR không tự bật lại.
- Chuẩn hóa typography Staff Center: Be Vietnam Pro/VWW Sans cho UI vận hành, body 15px, badge 13px/500, table header 13px, button 16px/500; không còn font-weight 800 trong Staff UI.
- Sửa luồng Export của role Check-in: tải file qua route frontend `/check-in-center/export/`, không phụ thuộc `wp-admin/admin-post.php`.
- Thêm modal chọn trường dữ liệu trước khi Export; chỉ cho Staff xuất các field vận hành an toàn.
- Thêm checkbox từng khách, chọn cả trang, chọn toàn bộ kết quả đang lọc và Export theo lựa chọn.
- Thêm Staff Bulk an toàn: Check-in hàng loạt và Gửi lại vé hàng loạt; không mở các thao tác xóa/hủy/thùng rác/hoàn tác hàng loạt.
- Nâng quick tabs giống trang quản trị: Tất cả, Đăng ký, Đã gửi vé, Đã check-in, Đã hủy kèm số lượng.
- Thêm bộ lọc Ngày Check-in: Hôm nay, Hôm qua, ngày cụ thể hoặc khoảng ngày; kết hợp được với Sự kiện/Nguồn/Trạng thái và Export.
- Khi lọc theo Ngày Check-in, danh sách và file Export ưu tiên sắp xếp theo thời gian Check-in mới nhất.

== Phiên bản 1.20.7 ==
- Nâng cấp toàn bộ giao diện Staff Check-in Center theo hướng Event Operations UI.
- Mobile-first: camera gần toàn màn hình, bottom navigation cố định, guest card và filter bottom sheet.
- Thêm section “Check-in gần nhất” dưới scanner, cập nhật sau mỗi lượt check-in thành công.
- Thiết kế lại overlay kết quả Check-in, modal xác nhận và toast thông báo nội bộ.
- Danh sách khách có search nổi bật, filter chips, action menu gọn hơn và thống kê dạng compact.
- Trang đăng nhập Staff được làm mới theo nhận diện Burgundy + Champagne Gold.
- Toàn bộ khai báo CSS font-weight: 800 được chuẩn hóa về 700.
- Giữ nguyên permission và backend nghiệp vụ của v1.20.6.

== Phiên bản 1.20.6 ==

* Thêm VWW Staff Check-in Center độc lập tại `/check-in-center/` và trang đăng nhập riêng `/check-in-login/`.
* Tài khoản “Nhân viên Check-in VWW” đăng nhập xong được đưa thẳng vào Check-in Center; truy cập wp-admin sẽ tự quay về Center.
* Staff có quyền quét QR, xem/tìm/lọc danh sách khách, xuất Excel, check-in thủ công, gửi lại vé đã phát hành và chuyển vé về chưa check-in.
* Staff không có quyền thêm, sửa, xóa vé, sửa email, import, quản lý email template hoặc cấu hình. Backend kiểm tra capability, không chỉ ẩn nút giao diện.
* Export của Staff dùng bộ cột vận hành an toàn, không xuất IP, user-agent hoặc dữ liệu kỹ thuật nội bộ.
* Scanner dừng sau mỗi lượt quét và chỉ tiếp tục sau khi bấm “XÁC NHẬN · QUÉT VÉ TIẾP”.
* Phân biệt rõ overlay: CHECK-IN THÀNH CÔNG, VÉ ĐÃ CHECK IN, VÉ KHÔNG TỒN TẠI và các trạng thái không hợp lệ; thêm âm báo/rung khi thiết bị hỗ trợ.
* Gửi lại vé của Staff chỉ áp dụng cho vé đã gửi/đã check-in, không thể phát hành đăng ký chưa được Administrator xác nhận.

== Phiên bản 1.20.5 ==

* Nâng cấp màn quét thành Check-in Center theo luồng vận hành của VWW Fashion Invitation Manager.
* Thay thư viện QR bị thiếu dữ liệu bằng bản cục bộ đầy đủ và đã kiểm tra cú pháp.
* Thêm Mở camera, Dừng camera, Đổi camera và trạng thái camera trực tiếp.
* Ưu tiên camera chính phía sau; tự thử cấu hình dự phòng khi thiết bị không trả tên camera.
* Phân biệt lỗi HTTPS, quyền camera, không có camera, camera đang bận và trình duyệt không hỗ trợ.
* Giữ nhập mã thủ công, phản hồi check-in và tự mở lại camera sau mỗi lượt quét.

== Phiên bản 1.18.3 ==

* Tách hoàn toàn email khách khỏi request gửi Contact Form 7 bằng hàng đợi WP-Cron.
* CF7 chỉ tạo vé và trả phản hồi thành công; lỗi/timeout của email vé không thể đổi trạng thái form.
* Bỏ bộ lọc spam/rate-limit riêng khỏi luồng CF7; Turnstile tiếp tục xử lý chống spam để tránh chặn nhầm lúc kiểm thử.
* Tiếp tục giới hạn toàn bộ tích hợp theo đúng Contact Form 7 đã cấu hình.

== Phiên bản 1.18.2 ==

* Chỉ xử lý đúng một Contact Form 7 được chọn trong Cấu hình; chưa chọn form thì không tác động form nào.
* Thay ô nhập ID thủ công bằng danh sách chọn form gồm tên và ID.
* Khóa kiểm tra trùng, chống spam, tạo vé, email, phản hồi AJAX, chuyển trang và ghi nguồn theo Form ID.
* JavaScript không chèn trường nguồn hoặc chuyển trang đối với các form Contact Form 7 khác.
* Đồng bộ Flamingo chỉ đọc dữ liệu của form đã cấu hình và không còn chế độ lấy tất cả form.

== Phiên bản 1.18.1 ==

* Bỏ hoàn toàn xử lý tạo vé khỏi `wpcf7_before_send_mail` để không can thiệp giao dịch gửi mail của Contact Form 7.
* Chỉ tạo vé, ghi nguồn và gửi email VWW sau khi Mail chính của Contact Form 7 đã thành công.
* Giữ nguyên CSS trang vé, xuất dữ liệu nguồn và đồng bộ Flamingo của phiên bản 1.18.0.

== Phiên bản 1.17 ==

* Thêm ô CSS tùy chỉnh riêng cho trang Vé mời và áp dụng trực tiếp trong preview Desktop/Mobile.
* Tự ghi nhận nguồn truy cập đầu tiên trong 30 ngày, kể cả khi khách xem nhiều trang trước khi đăng ký.
* Hỗ trợ nguồn giới thiệu, landing page, referrer và UTM source/medium/campaign/content/term.
* Thêm nguồn tiếp thị vào danh sách, bộ lọc, trang chi tiết vé và file xuất Excel/CSV.
* Vé cũ tiếp tục hoạt động và hiển thị nguồn kỹ thuật cũ khi chưa có dữ liệu nguồn tiếp thị.

== Phiên bản 1.16 ==

* Trang Vé mời độc lập, bỏ header/footer của theme và tập trung hoàn toàn vào nội dung vé.
* Desktop chia hai cột: Tổng quan và Vé mời; mobile tự chuyển một cột và ưu tiên QR.
* Thêm menu “Thiết kế trang vé” với xem trước Desktop/Mobile trực tiếp.
* Cho phép chỉnh nội dung, màu nhận diện và các nút lịch trình/liên hệ/trang chủ.
* Email trên trang vé được che bớt; QR và URL tiếp tục dùng token ngẫu nhiên.
* Giữ nguyên luồng đăng ký Contact Form 7 thành công rồi chuyển thẳng đến Vé mời.

== Phiên bản 1.15 ==

* Sau khi Contact Form 7 đăng ký thành công, khách được chuyển thẳng tới Vé Mời vừa tạo.
* URL vé chỉ dùng token ngẫu nhiên; không đưa họ tên, email hoặc số điện thoại lên URL.
* Không chuyển trang nếu biểu mẫu báo lỗi hoặc plugin không tạo được vé.

== Nâng cấp từ phiên bản cũ ==

1. Sao lưu cơ sở dữ liệu trước khi cập nhật plugin trên website thật.
2. Cài file ZIP mới đè lên plugin hiện tại rồi kích hoạt.
3. Plugin tự bổ sung cột và bảng dữ liệu mới; không xóa vé, QR hoặc nhật ký cũ.
4. Vào VWW Vé mời > Cấu hình, kiểm tra ID Contact Form 7, field Nội dung sự kiện và chế độ gửi email.
5. Vào VWW Vé mời > Mẫu email, kiểm tra cả hai tab và gửi email thử.
6. Vào VWW Vé mời > Thiết kế trang vé, chỉnh nội dung/màu và bấm Lưu & xuất bản.
7. Kiểm tra SMTP, đăng ký thử, xác nhận gửi vé và quét thử QR trước khi vận hành.

== Contact Form 7 ==

Plugin đọc các field:

* your-name
* your-phone
* your-email
* wedding-date
* your-role

Field “Nội dung sự kiện” không bị cố định. Cấu hình tên field tại VWW Vé mời > Cấu hình, mặc định là your-interest.

Plugin hỗ trợ ID CF7 dạng hash trong shortcode, ví dụ 0efd5a4, và ID số.

Luồng mặc định:

* Form hợp lệ tạo vé ở trạng thái “Đăng ký, chưa gửi vé”.
* Khách nhận email đăng ký thành công, chưa có QR.
* Administrator bấm “Xác nhận & Gửi vé”; chỉ khi email gửi thành công trạng thái mới chuyển thành “Đã gửi vé”.

Luồng tự động:

* Bật “Bỏ qua email đăng ký thành công và gửi Vé Mời ngay” tại Cấu hình.
* Phải xác nhận Cloudflare Turnstile đã được cấu hình.
* Chỉ áp dụng với CF7; vé thủ công và vé import không tự gửi.
* Trùng email + sự kiện không tạo hoặc gửi lại vé.
* Trùng số điện thoại nhưng khác email được giữ lại để Administrator duyệt.

== Bảo vệ form ==

* Tận dụng kết quả spam/Turnstile của Contact Form 7; plugin không lưu secret Turnstile.
* Giới hạn mặc định: email 3 lần/giờ, số điện thoại 3 lần/giờ, IP 10 lần/15 phút và 30 lần/ngày.
* IP chỉ được dùng dưới dạng hash trong nhật ký bảo mật.
* Cơ sở dữ liệu có khóa chống trùng email + sự kiện để hạn chế tạo vé lặp khi có nhiều request đồng thời.

== Mẫu email trực quan ==

Vào VWW Vé mời > Mẫu email:

* Tab Email đăng ký thành công.
* Tab Email Vé Mời.
* Tùy chỉnh subject, preheader, thương hiệu, tiêu đề, nội dung, logo, footer và màu sắc.
* Chèn biến dữ liệu bằng nút.
* Xem trước và gửi thử không tạo vé, không đổi trạng thái vé.
* Mẫu đăng ký không hỗ trợ biến QR hoặc mã vé.
* Mẫu Vé Mời luôn tự bổ sung QR và nút mở vé nếu hai thành phần này bị xóa.

== Import Excel ==

Vào VWW Vé mời > Import Excel:

1. Bấm “Tải file Excel mẫu (.xlsx)”.
2. Điền dữ liệu trong sheet DANH_SACH_IMPORT; giữ nguyên hàng tiêu đề.
3. Upload `.xlsx` hoặc `.csv`.
4. Kiểm tra ghép cột và bản xem trước.
5. Chọn “Chỉ thêm vé mới” hoặc “Thêm mới + cập nhật trường an toàn”.
6. Xác nhận import.

Quy tắc:

* Bắt buộc full_name và email hợp lệ.
* Hỗ trợ ngày dd/mm/yyyy, yyyy-mm-dd và ngày dạng serial của Excel.
* Ưu tiên nhận diện: ticket_code; external_id + source; email + sự kiện; số điện thoại + sự kiện.
* Nếu email và số điện thoại trỏ tới hai vé khác nhau, dòng bị chặn là xung đột.
* Vé import mới ở trạng thái “Đăng ký, chưa gửi vé” và không tự gửi email.
* Không ghi đè mã vé, token QR, trạng thái, ngày gửi email hoặc check-in.
* Không tự khôi phục vé đã hủy hoặc vé trong thùng rác.
* Lịch sử import lưu số dòng tạo, cập nhật, bỏ qua và lỗi; có thể tải CSV các dòng lỗi.
* Giới hạn 10.000 dòng mỗi file.

Máy chủ cần extension PHP ZipArchive và SimpleXML để đọc/ghi `.xlsx`. Nếu thiếu, vẫn có thể dùng CSV.

== Xuất dữ liệu ==

* “Xuất Excel” là định dạng mặc định `.xlsx`; CSV là tùy chọn phụ.
* File xuất áp dụng toàn bộ bộ lọc đang chọn, không bị giới hạn bởi số dòng đang hiển thị.
* Có thể chọn một số vé rồi “Xuất Excel vé đã chọn”.
* File xuất có thể chỉnh sửa và import lại nhờ cột ticket_code.

== Danh sách, hủy vé và thùng rác ==

Dashboard hỗ trợ:

* Tìm kiếm và lọc theo trạng thái, sự kiện, Nội dung sự kiện, nguồn, đợt import và khoảng ngày.
* Tab nhanh: Tất cả, Đăng ký, Đã gửi vé, Đã check-in, Đã hủy, Thùng rác.
* Chọn trang hiện tại hoặc toàn bộ kết quả lọc.
* Xác nhận & gửi vé, gửi lại, hủy, khôi phục hủy, chuyển thùng rác, khôi phục, xóa vĩnh viễn và xuất Excel hàng loạt.

Quy tắc an toàn:

* Vé đã hủy vẫn còn lịch sử nhưng QR không hợp lệ, không thể gửi hoặc check-in.
* Khôi phục vé đã hủy về “Đã gửi vé” nếu từng gửi; nếu chưa gửi thì về “Đăng ký, chưa gửi vé”.
* Thùng rác là xóa mềm, không tính vào thống kê chính và có thể khôi phục.
* Chỉ xóa vĩnh viễn từ thùng rác.
* Vé đã check-in không thể bị hủy; có thể chuyển vào thùng rác và chỉ được xóa vĩnh viễn khi đang nằm trong thùng rác.
* Các thao tác thay đổi dữ liệu chỉ dành cho Administrator.

== Check-in ==

* Nhân viên dùng ứng dụng frontend riêng tại `/check-in-center/`; trang đăng nhập riêng tại `/check-in-login/`.
* Staff được quét QR, xem/tìm/lọc khách, xuất Excel, check-in thủ công, gửi lại Vé Mời đã phát hành và chuyển vé đã check-in về chưa check-in.
* Staff không được thêm, sửa, xóa vé; không sửa email; không import, chỉnh mẫu email, cấu hình hoặc truy cập WordPress Admin.
* Administrator vẫn quản lý đầy đủ trong VWW Vé mời tại wp-admin và có thể mở Check-in Center để kiểm thử.
* Camera sau được ưu tiên mặc định; nút đổi camera cho phép chuyển camera khi thiết bị có nhiều camera.
* QR hợp lệ tự check-in, hiển thị “CHECK-IN THÀNH CÔNG” + tên + mã vé; camera dừng cho đến khi bấm “XÁC NHẬN · QUÉT VÉ TIẾP”.
* Vé đã check-in hiển thị cảnh báo màu cam; mã không tồn tại hiển thị “VÉ KHÔNG TỒN TẠI”; có âm báo/rung khi thiết bị hỗ trợ.
* Danh sách chỉ cập nhật sau thao tác hoặc khi bấm ↻ Làm mới; không polling tự động.
* HTTPS là bắt buộc để camera hoạt động.

== Changelog ==

= 1.20.4 =
* Cho phép gửi lại Vé Mời ở mọi trạng thái, kể cả đã check-in hoặc đã hủy; chỉ chặn vé trong thùng rác và vé thiếu email hợp lệ.
* Giữ nguyên trạng thái vé khi dùng thao tác Gửi lại.
* Kích hoạt ghi nhận lỗi `wp_mail_failed` theo đúng vé để hiển thị lỗi SMTP/Brevo thực tế.
* Đổi thông báo thành “đã chuyển yêu cầu gửi” để không nhầm `wp_mail() = true` với email đã được giao tới hộp thư.
* Mở thao tác gửi lại cho từng vé và thao tác hàng loạt.

= 1.20.3 =
* Áp dụng chuỗi font tùy chỉnh của Trang vé cho cả email đăng ký và email Vé Mời.
* Nhúng webfont tiếng Việt từ plugin cho các ứng dụng email có hỗ trợ.
* Giữ font Georgia/Times New Roman dự phòng để Gmail và Outlook không làm vỡ bố cục khi chặn webfont.

= 1.19.2 =
* Sửa đọc payload trường Flamingo dạng lồng và dạng name/value.
* Tự dò tên, email từ metadata chuẩn của Flamingo và loại placeholder [field].
* Giữ Select Form, mapping, chống trùng và múi giờ website.

= 1.19.1 =
* Sửa nhận diện Form nguồn Flamingo qua metadata, metadata lồng và channel taxonomy.
* Bổ sung thống kê số bản ghi đã quét, khớp Form, hợp lệ, trùng và không hợp lệ.
* Bổ sung cảnh báo chẩn đoán khi khoảng thời gian không có dữ liệu hoặc dữ liệu không khớp Form.

= 1.19.0 =

* Nâng cấp Import Flamingo: Select Form CF7, mapping trường, xem trước từng dòng và checkbox lựa chọn.
* Phân loại trùng theo Flamingo ID, email và số điện thoại chuẩn hóa.
* Giữ thời gian đăng ký gốc theo múi giờ website; import không tự gửi email.

= 1.18.8 =

* Chuẩn hóa toàn bộ mốc thời gian theo múi giờ cấu hình trong WordPress.
* Loại bỏ cách hiển thị phụ thuộc múi giờ PHP/server có thể làm lệch thêm giờ.
* Thời gian đăng ký trực tiếp tiếp tục được ghi bằng giờ website qua current_time().
* Import Flamingo giữ nguyên post_date theo giờ website và lọc khoảng ngày/giờ theo cùng chuẩn.
* Hiển thị tên múi giờ website tại trang Đồng bộ Flamingo và trang chi tiết vé.
* Check-in, email, lịch sử import, API quản trị và tên file xuất dùng nhất quán giờ website.

= 1.18.7 =

* Thao tác hàng loạt tự thay đổi theo tab và bộ lọc trạng thái đang xem.
* Tất cả chỉ còn hành động chung an toàn; xóa vĩnh viễn chỉ xuất hiện trong Thùng rác.
* Thùng rác chỉ hiển thị khôi phục, xóa vĩnh viễn và xuất Excel.
* Backend tiếp tục kiểm tra trạng thái thực tế và báo số vé xử lý, bỏ qua, lỗi gửi.
* Cho phép chuyển vé đã check-in vào Thùng rác; chỉ vé trong Thùng rác mới được xóa vĩnh viễn.
* Cảnh báo xóa vĩnh viễn hiển thị rõ số lượng vé và yêu cầu xác nhận lần cuối.

= 1.18.6 =

* Ghi nhớ nguồn/UTM trong trình duyệt tối đa 30 ngày mà không chèn trường vào Contact Form 7.
* Link có UTM mới được ưu tiên cập nhật nguồn; hỗ trợ thêm tham số rút gọn `vww_source`.
* Chuẩn hóa nhãn nguồn Zalo, Facebook, Google, TikTok, Instagram, YouTube, Mã QR và Truy cập trực tiếp.
* Chỉ gửi dữ liệu nguồn cùng API tạo vé sau khi sự kiện `wpcf7mailsent` thành công.
* Giữ nguyên bộ lọc nguồn, trang chi tiết vé và các cột UTM trong Excel/CSV.

= 1.18.5 =
* Clean patch: plugin không chạy bất kỳ xử lý JavaScript nào trước khi CF7 báo gửi mail thành công.
* Ngừng nạp script chèn trường nguồn/UTM vào form trước submit.
* Ngừng theo dõi `wp_mail_failed` toàn cục của WordPress.
* Dữ liệu nguồn/UTM được gửi sau `wpcf7mailsent` cùng API tạo vé độc lập.

= 1.18.4 =
* Tách hoàn toàn vòng đời gửi Contact Form 7 khỏi quá trình tạo vé.
* Gỡ các hook tạo vé, sửa response và kiểm tra trùng khỏi request CF7.
* Chỉ gọi REST API riêng sau sự kiện wpcf7mailsent để tạo vé và chuyển hướng.
* Thêm submission ID chống gọi API lặp và tạo vé trùng.
* Lỗi API/tạo vé không còn làm Contact Form 7 báo gửi thất bại.
* Email VWW tiếp tục chạy qua hàng đợi riêng sau khi vé được tạo.

= 1.14 =
* Thêm cấu hình bật/tắt riêng cho kiểm tra trùng email, số điện thoại và từng giới hạn tần suất.
* Lỗi đăng ký trùng hiển thị trực tiếp tại trường Contact Form 7 tương ứng.
* Cho phép chỉnh số lượt, khoảng thời gian và khôi phục cấu hình chống spam mặc định.
* Hiển thị và xuất Excel thời gian khách đăng ký vé.

= 1.13 =
* Lưu URL trang đăng ký Contact Form 7 và Referrer URL, giữ nguyên tham số UTM.
* Hiển thị liên kết trang đăng ký trong danh sách, bộ lọc nâng cao và file xuất Excel.
* Thêm thao tác hàng loạt đánh dấu đã check-in và chuyển về chưa check-in.
* Lưu nhật ký khi check-in hoặc hủy kết quả check-in hàng loạt.
* Thu gọn bộ lọc, chỉ hiện thanh thao tác sau khi chọn vé và tối ưu responsive.

= 1.12 =

* Thêm import `.xlsx`/`.csv`, file Excel mẫu ba sheet, ghép cột, xem trước, chống trùng, lịch sử import và file dòng lỗi.
* Đổi xuất mặc định sang `.xlsx`, xuất toàn bộ kết quả lọc và hỗ trợ xuất các vé đã chọn.
* Thêm trình soạn thảo trực quan cho email đăng ký thành công, song song với email Vé Mời.
* Thêm tùy chọn bỏ qua email đăng ký và gửi Vé Mời trực tiếp cho CF7.
* Thêm kiểm soát Turnstile, giới hạn tần suất, chống gửi trùng và khóa dữ liệu chống tạo vé lặp.
* Thêm bộ lọc nâng cao, chọn trang/toàn bộ kết quả và thao tác hàng loạt.
* Thêm trạng thái hủy có lý do, khôi phục vé hủy, thùng rác mềm, khôi phục và xóa vĩnh viễn có bảo vệ.
* QR của vé đã hủy hoặc trong thùng rác không còn hiển thị và không thể check-in.
* Mở rộng migration dữ liệu mà không làm mất vé và nhật ký của phiên bản trước.

= 1.11 =

* Sửa nút Email lại bằng REST POST và nonce đăng nhập.
* Giữ nguyên trạng thái Đã check-in khi gửi lại Vé Mời.

= 1.10 =

* Thêm trình soạn thảo email Vé Mời trực quan.

= 1.0.9 =

* Bỏ check-in thủ công riêng khỏi trang quản trị; giữ nút Check-in tại từng dòng.

= 1.0.8 =

* Gộp quản trị vé và Check-in Dashboard, đồng bộ quyền Nhân viên Check-in VWW.

= 1.0.4 =

* Thêm lớp xác nhận dấu tích trên camera và ưu tiên camera sau.
= 1.20.2 =
* Tích hợp trực tiếp bộ CSS tùy chỉnh đã duyệt cho tiêu đề, nội dung vé, hướng dẫn lưu và trạng thái vé.
* Ưu tiên UTM Essendine Caps; tự động dùng font VWW Serif đóng gói khi thiết bị không có UTM.
* Tăng phiên bản tài nguyên để trình duyệt và CDN nhận stylesheet mới.

= 1.20.1 =
* Đóng gói font Cormorant Garamond và Be Vietnam Pro trong plugin, hỗ trợ đầy đủ tiếng Việt.
* Trang vé độc lập và bản xem trước dùng cùng một font trên mọi trình duyệt, thiết bị.
* Không còn phụ thuộc font của theme, Google Fonts hoặc bộ nhớ đệm của trình duyệt.

= 1.20.0 =
* Thêm mẫu Trang vé mời v2 với logo/monogram và tên Vietnam Wedding Week luôn hiển thị.
* Bổ sung concept, ngày giờ, địa điểm, địa chỉ, vai trò, số khách, QR và mã tham dự.
* Bổ sung chọn logo từ Media Library, nút chỉ đường và xem trước responsive trong quản trị.
* Chuyển Nội dung quan tâm ra khỏi mặt vé chính.

= 1.19.4 =
* Fix Flamingo phone fields stored as prefixed, underscored, or single-item array metadata.
* Recover attribution source from saved source fields, UTM query parameters, and referrer metadata.

= 1.19.3 =
* Đồng bộ Form/Flamingo và Excel theo 8 field: time, date, your-name, your-email, your-phone, wedding-date, your-role, your-interest.
* Import ghép date + time thành thời gian đăng ký gốc theo múi giờ website.
* Export XLSX/CSV xuất đúng tên và thứ tự 8 field đã thống nhất.

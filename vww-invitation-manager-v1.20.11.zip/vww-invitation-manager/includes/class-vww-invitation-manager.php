<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class VWW_Invitation_Manager {
    const VERSION    = '1.20.11';
    const OPTION     = 'vww_im_settings';
    const DB_VERSION = '1.5.0';

    private static $instance;
    private $cf7_ticket_url = '';
    private $cf7_pending_ticket_id = 0;
    private $mail_context_ticket_id = 0;
    private $mail_last_error = '';

    public static function instance() {
        if ( ! self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', array( $this, 'boot' ) );
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_init', array( $this, 'redirect_checkin_staff_dashboard' ) );
        add_filter( 'login_redirect', array( $this, 'checkin_login_redirect' ), 10, 3 );
        add_filter( 'show_admin_bar', array( $this, 'hide_checkin_staff_admin_bar' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'public_assets' ) );
        add_action( 'template_redirect', array( $this, 'render_staff_routes' ), 0 );
        add_action( 'template_redirect', array( $this, 'render_public_ticket' ) );
        add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
        add_action( 'admin_post_vww_im_create_ticket', array( $this, 'handle_manual_ticket' ) );
        add_action( 'admin_post_vww_im_update_ticket', array( $this, 'handle_update_ticket' ) );
        add_action( 'admin_post_vww_im_save_ticket_design', array( $this, 'handle_save_ticket_design' ) );
        add_action( 'admin_post_vww_im_export_xlsx', array( $this, 'handle_export_xlsx' ) );
        add_action( 'admin_post_vww_im_staff_export_xlsx', array( $this, 'handle_staff_export_xlsx' ) );
        add_action( 'admin_post_vww_im_export_csv', array( $this, 'handle_export_csv' ) );
        add_action( 'admin_post_vww_im_import_preview', array( $this, 'handle_import_preview' ) );
        add_action( 'admin_post_vww_im_import_map', array( $this, 'handle_import_map' ) );
        add_action( 'admin_post_vww_im_import_commit', array( $this, 'handle_import_commit' ) );
        add_action( 'admin_post_vww_im_import_errors', array( $this, 'handle_import_errors' ) );
        add_action( 'admin_post_vww_im_download_template', array( $this, 'handle_download_template' ) );
        add_action( 'admin_post_vww_im_flamingo_preview', array( $this, 'handle_flamingo_preview' ) );
        add_action( 'admin_post_vww_im_flamingo_commit', array( $this, 'handle_flamingo_commit' ) );
        add_shortcode( 'vww_checkin_scanner', array( $this, 'scanner_shortcode' ) );
        add_shortcode( 'vww_ticket', array( $this, 'ticket_shortcode' ) );
        // Contact Form 7 owns its complete validation/mail/response lifecycle.
        // Ticket creation starts later through the plugin's isolated REST route.
        add_action( 'vww_im_send_queued_cf7_email', array( $this, 'send_queued_cf7_email' ), 10, 1 );
        add_action( 'wp_mail_failed', array( $this, 'capture_mail_failure' ), 10, 1 );
    }

    /**
     * Parse a database/local date as wall-clock time in the website timezone.
     * This deliberately avoids strtotime(), whose result can depend on the
     * PHP/server timezone and then be shifted again by wp_date().
     */
    private function site_datetime( $value, $formats = array( 'Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d' ) ) {
        $value = trim( (string) $value );
        if ( '' === $value ) {
            return false;
        }
        foreach ( $formats as $format ) {
            $date = DateTimeImmutable::createFromFormat( '!' . $format, $value, wp_timezone() );
            $errors = DateTimeImmutable::getLastErrors();
            if ( $date && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) ) {
                return $date;
            }
        }
        return false;
    }

    private function format_site_datetime( $value, $format = 'd/m/Y H:i', $fallback = '' ) {
        $date = $this->site_datetime( $value );
        return $date ? $date->format( $format ) : $fallback;
    }

    private function site_timezone_label() {
        $timezone = wp_timezone();
        $now      = new DateTimeImmutable( 'now', $timezone );
        return $timezone->getName() . ' (UTC' . $now->format( 'P' ) . ')';
    }

    public static function default_settings() {
        return array(
            'event_name'                    => 'Vietnam Wedding Week 2026',
            'cf7_form_id'                    => '',
            'cf7_event_content_field'        => 'your-interest',
            'from_name'                      => get_bloginfo( 'name' ),
            'from_email'                     => get_option( 'admin_email' ),
            'auto_send_invitation'           => 0,
            'rate_limit_enabled'             => 1,
            'duplicate_email_enabled'         => 1,
            'duplicate_phone_enabled'         => 1,
            'rate_email_enabled'              => 1,
            'rate_email_limit'                => 3,
            'rate_email_minutes'              => 60,
            'rate_phone_enabled'              => 1,
            'rate_phone_limit'                => 3,
            'rate_phone_minutes'              => 60,
            'rate_ip_short_enabled'           => 1,
            'rate_ip_short_limit'             => 10,
            'rate_ip_short_minutes'           => 15,
            'rate_ip_day_enabled'             => 1,
            'rate_ip_day_limit'               => 30,
            'rate_ip_day_hours'               => 24,
            'turnstile_confirmed'            => 0,
            'registration_subject'           => 'Đăng ký tham dự Vietnam Wedding Week 2026 thành công',
            'registration_intro'             => 'Chúc mừng bạn đã đăng ký tham dự Vietnam Wedding Week 2026 thành công. Chúng tôi sẽ gửi Vé Mời qua email này sau khi thông tin được kiểm tra và xác nhận.',
            'registration_preheader'         => 'Thông tin đăng ký của bạn đã được ghi nhận.',
            'registration_brand_name'        => 'VIETNAM WEDDING WEEK',
            'registration_heading'           => 'ĐĂNG KÝ THÀNH CÔNG',
            'registration_body'              => '',
            'registration_footer'            => 'Vui lòng theo dõi email. Vé Mời chính thức sẽ được gửi sau khi đăng ký được xác nhận.',
            'registration_logo_url'          => '',
            'registration_bg_color'          => '#f3ece5',
            'registration_card_color'        => '#fbf6ef',
            'registration_primary_color'     => '#77171d',
            'registration_accent_color'      => '#b99155',
            'registration_text_color'        => '#401619',
            'email_subject'                  => 'Vé mời Vietnam Wedding Week 2026 dành cho {customer_name}',
            'email_intro'                    => 'Cảm ơn bạn đã đăng ký tham dự Vietnam Wedding Week 2026. Vui lòng xuất trình QR code dưới đây khi check-in.',
            'invitation_preheader'           => 'Vé Mời chính thức và mã QR check-in của bạn.',
            'invitation_brand_name'          => 'VIETNAM WEDDING WEEK',
            'invitation_heading'             => 'VÉ MỜI THAM DỰ',
            'invitation_body'                => '',
            'invitation_button_text'         => 'MỞ VÉ MỜI CỦA TÔI',
            'invitation_footer'              => 'Vui lòng không chia sẻ QR code. Mỗi vé chỉ được check-in một lần.',
            'invitation_logo_url'            => '',
            'invitation_bg_color'            => '#f3ece5',
            'invitation_card_color'          => '#fbf6ef',
            'invitation_primary_color'       => '#77171d',
            'invitation_accent_color'        => '#b99155',
            'invitation_text_color'          => '#401619',
            'ticket_eyebrow'                 => 'ĐĂNG KÝ THÀNH CÔNG',
            'ticket_title'                   => 'Hẹn gặp bạn tại Thành phố Tình Yêu',
            'ticket_intro'                   => 'Cảm ơn {customer_name} đã đăng ký tham dự. Vé mời cá nhân hóa của bạn đã sẵn sàng.',
            'ticket_email_note'              => 'Vé mời cũng được gửi tới {customer_email}. Vui lòng kiểm tra cả thư rác nếu chưa thấy email.',
            'ticket_event_label'             => 'VIETNAM WEDDING WEEK',
            'ticket_invitation_title'        => 'VÉ MỜI THAM DỰ',
            'ticket_logo_url'                 => '',
            'ticket_monogram'                 => 'W',
            'ticket_brand_name'               => 'Vietnam Wedding Week',
            'ticket_invite_phrase'            => 'Trân trọng kính mời',
            'ticket_concept'                  => 'The Love City',
            'ticket_event_date'               => '22–23.08.2026',
            'ticket_event_time'               => '09:00–21:00 hằng ngày',
            'ticket_venue'                    => 'White Palace Hoàng Văn Thụ',
            'ticket_address'                  => '194 Hoàng Văn Thụ, Phường 9, Quận Phú Nhuận, TP.HCM',
            'ticket_guest_count'              => '02 khách',
            'ticket_checkin_note'             => 'Quét hoặc xuất trình tại quầy check-in',
            'ticket_instruction'             => 'Vui lòng xuất trình mã QR này tại quầy check-in. Mỗi vé chỉ có hiệu lực một lần.',
            'ticket_primary_color'           => '#711d2b',
            'ticket_accent_color'            => '#b8945d',
            'ticket_background_color'        => '#f4eee6',
            'ticket_card_color'              => '#fffaf3',
            'ticket_text_color'              => '#3f2024',
            'ticket_schedule_url'            => home_url( '/' ),
            'ticket_contact_url'             => '',
            'ticket_map_url'                 => '',
            'ticket_home_url'                => home_url( '/' ),
            'ticket_schedule_label'          => 'Xem lịch trình sự kiện',
            'ticket_contact_label'           => 'Liên hệ Ban tổ chức',
            'ticket_map_label'               => 'Chỉ đường',
            'ticket_home_label'              => 'Về trang chủ',
            'ticket_custom_css'              => '',
            'ticket_design_version'          => 1,
        );
    }

    public static function activate() {
        global $wpdb;
        $tickets = $wpdb->prefix . 'vww_tickets';
        $logs    = $wpdb->prefix . 'vww_ticket_logs';
        $batches = $wpdb->prefix . 'vww_import_batches';
        $rows    = $wpdb->prefix . 'vww_import_rows';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( "CREATE TABLE $tickets (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_code varchar(32) NOT NULL,
            token_hash char(64) NOT NULL,
            token varchar(100) NOT NULL,
            external_id varchar(100) NOT NULL DEFAULT '',
            event_name varchar(190) NOT NULL,
            full_name varchar(190) NOT NULL,
            phone varchar(40) NOT NULL DEFAULT '',
            normalized_phone varchar(40) NOT NULL DEFAULT '',
            email varchar(190) NOT NULL DEFAULT '',
            normalized_email varchar(190) NOT NULL DEFAULT '',
            dedupe_key char(64) NULL,
            wedding_date date NULL,
            customer_role varchar(190) NOT NULL DEFAULT '',
            interest varchar(255) NOT NULL DEFAULT '',
            source varchar(40) NOT NULL DEFAULT 'admin',
            source_form_id bigint(20) unsigned NULL,
            registration_url text NULL,
            referrer_url text NULL,
            attribution_source varchar(100) NOT NULL DEFAULT '',
            attribution_type varchar(40) NOT NULL DEFAULT '',
            landing_page text NULL,
            first_referrer text NULL,
            referrer_domain varchar(190) NOT NULL DEFAULT '',
            utm_source varchar(190) NOT NULL DEFAULT '',
            utm_medium varchar(190) NOT NULL DEFAULT '',
            utm_campaign varchar(190) NOT NULL DEFAULT '',
            utm_content varchar(190) NOT NULL DEFAULT '',
            utm_term varchar(190) NOT NULL DEFAULT '',
            attributed_at datetime NULL,
            visitor_ip varchar(100) NOT NULL DEFAULT '',
            user_agent text NULL,
            source_page_title varchar(255) NOT NULL DEFAULT '',
            source_raw longtext NULL,
            import_batch_id bigint(20) unsigned NULL,
            status varchar(30) NOT NULL DEFAULT 'issued',
            previous_status varchar(30) NOT NULL DEFAULT '',
            emailed_at datetime NULL,
            checked_in_at datetime NULL,
            checked_in_by bigint(20) unsigned NULL,
            cancelled_at datetime NULL,
            cancelled_by bigint(20) unsigned NULL,
            cancel_reason text NULL,
            trashed_at datetime NULL,
            trashed_by bigint(20) unsigned NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ticket_code (ticket_code),
            UNIQUE KEY token_hash (token_hash),
            UNIQUE KEY dedupe_key (dedupe_key),
            KEY event_status (event_name(100),status),
            KEY normalized_email (normalized_email),
            KEY normalized_phone (normalized_phone),
            KEY external_source (external_id,source),
            KEY import_batch_id (import_batch_id),
            KEY trashed_at (trashed_at)
        ) $charset;" );
        dbDelta( "CREATE TABLE $logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            action varchar(50) NOT NULL,
            note text NULL,
            user_id bigint(20) unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_id (ticket_id),
            KEY action (action)
        ) $charset;" );
        dbDelta( "CREATE TABLE $batches (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            batch_code varchar(32) NOT NULL,
            file_name varchar(255) NOT NULL,
            mode varchar(30) NOT NULL DEFAULT 'add_only',
            total_rows int(11) unsigned NOT NULL DEFAULT 0,
            created_count int(11) unsigned NOT NULL DEFAULT 0,
            updated_count int(11) unsigned NOT NULL DEFAULT 0,
            unchanged_count int(11) unsigned NOT NULL DEFAULT 0,
            conflict_count int(11) unsigned NOT NULL DEFAULT 0,
            error_count int(11) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NULL,
            status varchar(30) NOT NULL DEFAULT 'processing',
            created_at datetime NOT NULL,
            completed_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY batch_code (batch_code),
            KEY created_at (created_at)
        ) $charset;" );
        dbDelta( "CREATE TABLE $rows (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint(20) unsigned NOT NULL,
            row_number int(11) unsigned NOT NULL,
            ticket_id bigint(20) unsigned NULL,
            action varchar(30) NOT NULL,
            message text NULL,
            row_data longtext NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id),
            KEY action (action)
        ) $charset;" );

        $legacy_rows = $wpdb->get_results( "SELECT id,email,phone,event_name,dedupe_key FROM $tickets WHERE normalized_email='' OR (phone<>'' AND normalized_phone='')" );
        foreach ( $legacy_rows as $legacy ) {
            $normalized_email = strtolower( sanitize_email( trim( (string) $legacy->email ) ) );
            $phone            = trim( (string) $legacy->phone );
            $normalized_phone = ( 0 === strpos( $phone, '+' ) ? '+' : '' ) . preg_replace( '/\D+/', '', $phone );
            $dedupe           = null;
            if ( $normalized_email && $legacy->event_name ) {
                $candidate = hash( 'sha256', $normalized_email . '|' . strtolower( trim( wp_strip_all_tags( $legacy->event_name ) ) ) );
                $owner     = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $tickets WHERE dedupe_key=%s AND id<>%d", $candidate, $legacy->id ) );
                if ( ! $owner ) {
                    $dedupe = $candidate;
                }
            }
            $wpdb->update(
                $tickets,
                array(
                    'normalized_email' => $normalized_email,
                    'normalized_phone' => $normalized_phone,
                    'dedupe_key'       => $dedupe,
                ),
                array( 'id'=>(int) $legacy->id )
            );
        }

        update_option( 'vww_im_db_version', self::DB_VERSION );
        if ( false === get_option( self::OPTION, false ) ) {
            add_option( self::OPTION, self::default_settings() );
        }
        self::ensure_roles();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public function boot() {
        if ( get_option( 'vww_im_db_version' ) !== self::DB_VERSION ) {
            self::activate();
        }
        self::ensure_roles();
    }

    public static function ensure_roles() {
        $staff_caps = array(
            'read'               => true,
            'vww_checkin'        => true,
            'vww_view_tickets'   => true,
            'vww_export_tickets' => true,
            'vww_resend_ticket'  => true,
            'vww_reset_checkin'  => true,
        );
        add_role( 'vww_checkin_staff', 'Nhân viên Check-in VWW', $staff_caps );
        $staff = get_role( 'vww_checkin_staff' );
        if ( $staff ) {
            foreach ( array_keys( $staff_caps ) as $cap ) {
                $staff->add_cap( $cap );
            }
            // Staff is an operator role only: no create/edit/delete/settings capabilities.
            foreach ( array( 'vww_manage_tickets', 'manage_options', 'edit_posts', 'publish_posts', 'delete_posts' ) as $cap ) {
                $staff->remove_cap( $cap );
            }
        }
        foreach ( array( 'administrator', 'editor' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                $role->add_cap( 'vww_checkin' );
                $role->add_cap( 'vww_view_tickets' );
                if ( 'administrator' === $role_name ) {
                    foreach ( array( 'vww_manage_tickets', 'vww_export_tickets', 'vww_resend_ticket', 'vww_reset_checkin' ) as $cap ) {
                        $role->add_cap( $cap );
                    }
                }
            }
        }
    }

    private function table() {
        global $wpdb;
        return $wpdb->prefix . 'vww_tickets';
    }

    private function logs() {
        global $wpdb;
        return $wpdb->prefix . 'vww_ticket_logs';
    }

    private function batches() {
        global $wpdb;
        return $wpdb->prefix . 'vww_import_batches';
    }

    private function import_rows() {
        global $wpdb;
        return $wpdb->prefix . 'vww_import_rows';
    }

    public function settings() {
        return wp_parse_args( get_option( self::OPTION, array() ), self::default_settings() );
    }

    private function log( $ticket_id, $action, $note = '' ) {
        global $wpdb;
        $wpdb->insert(
            $this->logs(),
            array(
                'ticket_id' => (int) $ticket_id,
                'action'    => sanitize_key( $action ),
                'note'      => sanitize_textarea_field( $note ),
                'user_id'   => get_current_user_id() ?: null,
                'created_at'=> current_time( 'mysql' ),
            )
        );
    }

    private function normalize_email( $email ) {
        return strtolower( sanitize_email( trim( (string) $email ) ) );
    }

    private function normalize_phone( $phone ) {
        $phone = trim( (string) $phone );
        $plus  = 0 === strpos( $phone, '+' ) ? '+' : '';
        return $plus . preg_replace( '/\D+/', '', $phone );
    }

    private function dedupe_key( $email, $event_name ) {
        $email = $this->normalize_email( $email );
        $event = strtolower( trim( wp_strip_all_tags( (string) $event_name ) ) );
        return ( $email && $event ) ? hash( 'sha256', $email . '|' . $event ) : null;
    }

    private function make_code() {
        global $wpdb;
        do {
            $code   = 'VWW26-' . strtoupper( wp_generate_password( 6, false, false ) );
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE ticket_code=%s", $code ) );
        } while ( $exists );
        return $code;
    }

    private function make_token() {
        return wp_generate_password( 48, false, false ) . bin2hex( random_bytes( 16 ) );
    }

    private function valid_status( $status ) {
        return in_array( $status, array( 'registered', 'issued', 'emailed', 'checked_in', 'cancelled' ), true ) ? $status : 'registered';
    }

    public function create_ticket( $data, $send = true ) {
        global $wpdb;
        $settings = $this->settings();
        $token    = $this->make_token();
        $now      = current_time( 'mysql' );
        $event    = sanitize_text_field( $data['event_name'] ?? $settings['event_name'] );
        $email    = $this->normalize_email( $data['email'] ?? '' );
        $phone    = sanitize_text_field( $data['phone'] ?? '' );
        $row      = array(
            'ticket_code'      => $this->make_code(),
            'token'            => $token,
            'token_hash'       => hash( 'sha256', $token ),
            'external_id'      => sanitize_text_field( $data['external_id'] ?? '' ),
            'event_name'       => $event,
            'full_name'        => sanitize_text_field( $data['full_name'] ?? '' ),
            'phone'            => $phone,
            'normalized_phone' => $this->normalize_phone( $phone ),
            'email'            => $email,
            'normalized_email' => $email,
            'dedupe_key'       => $this->dedupe_key( $email, $event ),
            'wedding_date'     => ! empty( $data['wedding_date'] ) ? sanitize_text_field( $data['wedding_date'] ) : null,
            'customer_role'    => sanitize_text_field( $data['customer_role'] ?? '' ),
            'interest'         => sanitize_text_field( $data['interest'] ?? '' ),
            'source'           => sanitize_key( $data['source'] ?? 'admin' ) ?: 'admin',
            'source_form_id'   => ! empty( $data['source_form_id'] ) ? absint( $data['source_form_id'] ) : null,
            'registration_url' => esc_url_raw( $data['registration_url'] ?? '' ),
            'referrer_url'     => esc_url_raw( $data['referrer_url'] ?? '' ),
            'attribution_source' => sanitize_text_field( $data['attribution_source'] ?? '' ),
            'attribution_type' => sanitize_key( $data['attribution_type'] ?? '' ),
            'landing_page'     => esc_url_raw( $data['landing_page'] ?? '' ),
            'first_referrer'   => esc_url_raw( $data['first_referrer'] ?? '' ),
            'referrer_domain'  => sanitize_text_field( $data['referrer_domain'] ?? '' ),
            'utm_source'       => sanitize_text_field( $data['utm_source'] ?? '' ),
            'utm_medium'       => sanitize_text_field( $data['utm_medium'] ?? '' ),
            'utm_campaign'     => sanitize_text_field( $data['utm_campaign'] ?? '' ),
            'utm_content'      => sanitize_text_field( $data['utm_content'] ?? '' ),
            'utm_term'         => sanitize_text_field( $data['utm_term'] ?? '' ),
            'attributed_at'    => ! empty( $data['attributed_at'] ) ? sanitize_text_field( $data['attributed_at'] ) : null,
            'visitor_ip'       => sanitize_text_field( $data['visitor_ip'] ?? '' ),
            'user_agent'       => sanitize_textarea_field( $data['user_agent'] ?? '' ),
            'source_page_title'=> sanitize_text_field( $data['source_page_title'] ?? '' ),
            'source_raw'       => ! empty( $data['source_raw'] ) ? wp_json_encode( $data['source_raw'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '',
            'import_batch_id'  => ! empty( $data['import_batch_id'] ) ? absint( $data['import_batch_id'] ) : null,
            'status'           => $this->valid_status( $data['status'] ?? 'issued' ),
            'created_at'       => ! empty( $data['created_at'] ) ? sanitize_text_field( $data['created_at'] ) : $now,
            'updated_at'       => $now,
        );
        if ( empty( $row['full_name'] ) || ! is_email( $row['email'] ) ) {
            return new WP_Error( 'vww_missing', 'Họ tên và email hợp lệ là bắt buộc.' );
        }
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$this->table()} WHERE normalized_email=%s AND event_name=%s LIMIT 1",
                $row['normalized_email'],
                $row['event_name']
            )
        );
        if ( $existing ) {
            return new WP_Error( 'vww_duplicate', 'Khách này đã có vé trong cùng sự kiện.' );
        }
        $inserted = $wpdb->insert( $this->table(), $row );
        if ( ! $inserted ) {
            if ( false !== stripos( (string) $wpdb->last_error, 'duplicate' ) ) {
                return new WP_Error( 'vww_duplicate', 'Khách này đã có vé trong cùng sự kiện.' );
            }
            return new WP_Error( 'vww_db', 'Không thể tạo vé trong cơ sở dữ liệu.' );
        }
        $ticket = $this->get_ticket( (int) $wpdb->insert_id );
        $this->log( $ticket->id, 'created', 'Nguồn: ' . $row['source'] );
        if ( $send ) {
            $this->send_ticket_email( $ticket );
        }
        return $ticket;
    }

    public function get_ticket( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE id=%d", absint( $id ) ) );
    }

    public function get_by_token( $token ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE token_hash=%s", hash( 'sha256', (string) $token ) ) );
    }

    public function ticket_url( $ticket ) {
        return add_query_arg( 'vww_ticket', rawurlencode( $ticket->token ), home_url( '/' ) );
    }

    public function qr_url( $ticket ) {
        return 'https://api.qrserver.com/v1/create-qr-code/?size=360x360&format=png&data=' . rawurlencode( $this->ticket_url( $ticket ) );
    }

    private function template_defaults( $type ) {
        $all = self::default_settings();
        if ( 'registration' === $type ) {
            $keys = array(
                'registration_subject', 'registration_intro', 'registration_preheader',
                'registration_brand_name', 'registration_heading', 'registration_body',
                'registration_footer', 'registration_logo_url', 'registration_bg_color',
                'registration_card_color', 'registration_primary_color',
                'registration_accent_color', 'registration_text_color',
            );
        } else {
            $keys = array(
                'email_subject', 'email_intro', 'invitation_preheader',
                'invitation_brand_name', 'invitation_heading', 'invitation_body',
                'invitation_button_text', 'invitation_footer', 'invitation_logo_url',
                'invitation_bg_color', 'invitation_card_color',
                'invitation_primary_color', 'invitation_accent_color',
                'invitation_text_color',
            );
        }
        return array_intersect_key( $all, array_flip( $keys ) );
    }

    private function sanitize_template( $type, $input ) {
        $type     = 'registration' === $type ? 'registration' : 'invitation';
        $prefix   = 'registration' === $type ? 'registration_' : 'invitation_';
        $defaults = $this->template_defaults( $type );
        $input    = is_array( $input ) ? $input : array();
        $subject_key = 'registration' === $type ? 'registration_subject' : 'email_subject';
        $body_key    = $prefix . 'body';
        $clean = array(
            $subject_key             => sanitize_text_field( $input[ $subject_key ] ?? $defaults[ $subject_key ] ),
            $prefix . 'preheader'     => sanitize_text_field( $input[ $prefix . 'preheader' ] ?? $defaults[ $prefix . 'preheader' ] ),
            $prefix . 'brand_name'    => sanitize_text_field( $input[ $prefix . 'brand_name' ] ?? $defaults[ $prefix . 'brand_name' ] ),
            $prefix . 'heading'       => sanitize_text_field( $input[ $prefix . 'heading' ] ?? $defaults[ $prefix . 'heading' ] ),
            $body_key                 => wp_kses_post( $input[ $body_key ] ?? '' ),
            $prefix . 'footer'        => sanitize_textarea_field( $input[ $prefix . 'footer' ] ?? $defaults[ $prefix . 'footer' ] ),
            $prefix . 'logo_url'      => esc_url_raw( $input[ $prefix . 'logo_url' ] ?? '' ),
        );
        if ( 'invitation' === $type ) {
            $clean['invitation_button_text'] = sanitize_text_field( $input['invitation_button_text'] ?? $defaults['invitation_button_text'] );
        }
        foreach ( array( 'bg_color', 'card_color', 'primary_color', 'accent_color', 'text_color' ) as $suffix ) {
            $key = $prefix . $suffix;
            $clean[ $key ] = sanitize_hex_color( $input[ $key ] ?? '' ) ?: $defaults[ $key ];
        }
        if ( '' === $clean[ $subject_key ] ) {
            $clean[ $subject_key ] = $defaults[ $subject_key ];
        }
        foreach ( array( 'brand_name', 'heading' ) as $suffix ) {
            $key = $prefix . $suffix;
            if ( '' === $clean[ $key ] ) {
                $clean[ $key ] = $defaults[ $key ];
            }
        }
        if ( 'invitation' === $type && '' === $clean['invitation_button_text'] ) {
            $clean['invitation_button_text'] = $defaults['invitation_button_text'];
        }
        return $clean;
    }

    private function sample_ticket() {
        return (object) array(
            'id'            => 0,
            'token'         => 'vww-email-preview',
            'ticket_code'   => 'VWW26-DEMO26',
            'event_name'    => 'Vietnam Wedding Week 2026',
            'full_name'     => 'NGUYỄN VĂN AN',
            'phone'         => '0988 888 888',
            'email'         => 'khachmoi@example.com',
            'wedding_date'  => '2026-12-20',
            'customer_role' => 'Cô dâu / Chú rể tương lai',
            'interest'      => 'Hoạt động trải nghiệm & Show diễn thời trang',
            'status'        => 'emailed',
            'created_at'    => current_time( 'mysql' ),
        );
    }

    private function plain_tokens( $ticket ) {
        $wedding_date = '';
        if ( ! empty( $ticket->wedding_date ) ) {
            $wedding_date = $this->format_site_datetime( $ticket->wedding_date, 'd/m/Y', $ticket->wedding_date );
        }
        $registration_date = ! empty( $ticket->created_at ) ? $this->format_site_datetime( $ticket->created_at, 'd/m/Y H:i' ) : wp_date( 'd/m/Y H:i' );
        return array(
            '{customer_name}'      => (string) $ticket->full_name,
            '{customer_email}'     => (string) $ticket->email,
            '{customer_phone}'     => (string) $ticket->phone,
            '{ticket_code}'        => (string) $ticket->ticket_code,
            '{event_name}'         => (string) $ticket->event_name,
            '{event_content}'      => (string) $ticket->interest,
            '{customer_role}'      => (string) $ticket->customer_role,
            '{wedding_date}'       => $wedding_date,
            '{registration_date}'  => $registration_date,
            '{ticket_url}'         => $this->ticket_url( $ticket ),
            '{qr_url}'             => $this->qr_url( $ticket ),
        );
    }

    private function default_registration_body( $settings ) {
        $intro = ! empty( $settings['registration_intro'] ) ? $settings['registration_intro'] : self::default_settings()['registration_intro'];
        return '<p>Xin chào <strong>{customer_name}</strong>,</p>'
            . '<p>' . esc_html( $intro ) . '</p>'
            . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:22px 0;background:#ffffff;border-left:4px solid {accent_color};border-collapse:collapse">'
            . '<tr><td style="padding:8px 16px;color:#856e66;width:145px">Sự kiện</td><td style="padding:8px 16px;font-weight:700">{event_name}</td></tr>'
            . '<tr><td style="padding:8px 16px;color:#856e66">Nội dung sự kiện</td><td style="padding:8px 16px;font-weight:700">{event_content}</td></tr>'
            . '</table>';
    }

    private function default_invitation_body( $settings ) {
        $intro = ! empty( $settings['email_intro'] ) ? $settings['email_intro'] : self::default_settings()['email_intro'];
        return '<p>Xin chào <strong>{customer_name}</strong>,</p>'
            . '<p>' . esc_html( $intro ) . '</p>'
            . '<p style="text-align:center">{qr_code}</p>'
            . '{ticket_details}'
            . '<p style="text-align:center">{ticket_button}</p>';
    }

    private function invitation_ticket_details( $ticket, $settings ) {
        $plain = $this->plain_tokens( $ticket );
        $rows  = array(
            'Mã vé'           => $plain['{ticket_code}'],
            'Sự kiện'         => $plain['{event_name}'],
            'Nội dung sự kiện'=> $plain['{event_content}'],
        );
        if ( '' !== $plain['{customer_role}'] ) {
            $rows['Vai trò'] = $plain['{customer_role}'];
        }
        if ( '' !== $plain['{wedding_date}'] ) {
            $rows['Ngày cưới dự kiến'] = $plain['{wedding_date}'];
        }
        $html = '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:22px 0;background:#ffffff;border-left:4px solid ' . esc_attr( $settings['invitation_accent_color'] ) . ';border-collapse:collapse">';
        foreach ( $rows as $label => $value ) {
            $html .= '<tr><td style="padding:8px 16px;color:#856e66;font-family:\'UTM Essendine Caps\',\'VWW Email Serif\',Georgia,\'Times New Roman\',serif;font-size:13px;width:145px;vertical-align:top">' . esc_html( $label ) . '</td><td style="padding:8px 16px;color:' . esc_attr( $settings['invitation_text_color'] ) . ';font-family:\'UTM Essendine Caps\',\'VWW Email Serif\',Georgia,\'Times New Roman\',serif;font-size:14px;font-weight:700">' . esc_html( $value ?: '—' ) . '</td></tr>';
        }
        return $html . '</table>';
    }

    private function render_email_subject( $type, $ticket, $settings ) {
        $key = 'registration' === $type ? 'registration_subject' : 'email_subject';
        return sanitize_text_field( strtr( $settings[ $key ], $this->plain_tokens( $ticket ) ) );
    }

    private function render_email( $type, $ticket, $settings = array() ) {
        $type     = 'registration' === $type ? 'registration' : 'invitation';
        $prefix   = 'registration' === $type ? 'registration_' : 'invitation_';
        $settings = array_merge( $this->settings(), is_array( $settings ) ? $settings : array() );
        $settings = array_merge( $settings, $this->sanitize_template( $type, $settings ) );
        $plain    = $this->plain_tokens( $ticket );
        $escaped  = array();
        foreach ( $plain as $token => $value ) {
            $escaped[ $token ] = esc_html( $value );
        }

        if ( 'registration' === $type ) {
            $body_template = trim( (string) $settings['registration_body'] );
            if ( '' === $body_template ) {
                $body_template = $this->default_registration_body( $settings );
            }
            $body = strtr( $body_template, array_merge( $escaped, array( '{accent_color}' => esc_attr( $settings['registration_accent_color'] ) ) ) );
        } else {
            $body_template = trim( (string) $settings['invitation_body'] );
            if ( '' === $body_template ) {
                $body_template = $this->default_invitation_body( $settings );
            }
            if ( false === strpos( $body_template, '{qr_code}' ) ) {
                $body_template .= '<p style="text-align:center">{qr_code}</p>';
            }
            if ( false === strpos( $body_template, '{ticket_button}' ) ) {
                $body_template .= '<p style="text-align:center">{ticket_button}</p>';
            }
            $qr = '<img src="' . esc_url( $plain['{qr_url}'] ) . '" width="220" alt="QR check-in" style="display:inline-block;width:220px;max-width:100%;height:auto;border:0">';
            $button = '<a href="' . esc_url( $plain['{ticket_url}'] ) . '" style="display:inline-block;padding:13px 22px;background:' . esc_attr( $settings['invitation_primary_color'] ) . ';color:#ffffff;text-decoration:none;font-family:\'UTM Essendine Caps\',\'VWW Email Serif\',Georgia,\'Times New Roman\',serif;font-size:14px;font-weight:700;border-radius:3px">' . esc_html( $settings['invitation_button_text'] ) . '</a>';
            $body = strtr(
                $body_template,
                array_merge(
                    $escaped,
                    array(
                        '{qr_code}'       => $qr,
                        '{ticket_details}'=> $this->invitation_ticket_details( $ticket, $settings ),
                        '{ticket_button}' => $button,
                    )
                )
            );
        }

        $brand     = strtr( $settings[ $prefix . 'brand_name' ], $plain );
        $heading   = strtr( $settings[ $prefix . 'heading' ], $plain );
        $preheader = strtr( $settings[ $prefix . 'preheader' ], $plain );
        $logo      = '';
        if ( ! empty( $settings[ $prefix . 'logo_url' ] ) ) {
            $logo = '<img src="' . esc_url( $settings[ $prefix . 'logo_url' ] ) . '" alt="' . esc_attr( $brand ) . '" style="display:block;max-width:220px;max-height:90px;width:auto;height:auto;margin:0 auto 12px;border:0">';
        }
        $font_vietnamese = plugins_url( 'assets/fonts/cormorant-garamond-vietnamese-600-normal.woff2', VWW_IM_FILE );
        $font_latin_ext  = plugins_url( 'assets/fonts/cormorant-garamond-latin-ext-600-normal.woff2', VWW_IM_FILE );
        $font_latin      = plugins_url( 'assets/fonts/cormorant-garamond-latin-600-normal.woff2', VWW_IM_FILE );
        $email_font      = "'UTM Essendine Caps','VWW Email Serif',Georgia,'Times New Roman',serif";
        $font_css        = '<style type="text/css">'
            . '@font-face{font-family:\'VWW Email Serif\';font-style:normal;font-weight:600;src:url(\'' . esc_url( $font_vietnamese ) . '\') format(\'woff2\');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB}'
            . '@font-face{font-family:\'VWW Email Serif\';font-style:normal;font-weight:600;src:url(\'' . esc_url( $font_latin_ext ) . '\') format(\'woff2\');unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}'
            . '@font-face{font-family:\'VWW Email Serif\';font-style:normal;font-weight:600;src:url(\'' . esc_url( $font_latin ) . '\') format(\'woff2\');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}'
            . 'body,table,td,p,a,h1,h2,h3{font-family:' . $email_font . '}@media screen and (max-width:640px){.vww-email-card{padding:28px 20px!important}.vww-email-heading{font-size:27px!important}}</style>';
        return '<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">' . $font_css . '</head><body style="margin:0;padding:0;background:' . esc_attr( $settings[ $prefix . 'bg_color' ] ) . ';font-family:' . $email_font . '">'
            . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent">' . esc_html( $preheader ) . '</div>'
            . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;background:' . esc_attr( $settings[ $prefix . 'bg_color' ] ) . ';border-collapse:collapse"><tr><td align="center" style="padding:28px 12px">'
            . '<table role="presentation" width="620" cellspacing="0" cellpadding="0" style="width:100%;max-width:620px;background:' . esc_attr( $settings[ $prefix . 'card_color' ] ) . ';border:1px solid #eadbce;border-collapse:collapse;font-family:' . $email_font . '"><tr><td class="vww-email-card" style="padding:36px 34px;color:' . esc_attr( $settings[ $prefix . 'text_color' ] ) . ';font-family:' . $email_font . ';font-size:15px;line-height:1.65">'
            . $logo
            . '<div style="text-align:center;color:' . esc_attr( $settings[ $prefix . 'accent_color' ] ) . ';font-family:' . $email_font . ';font-size:12px;font-weight:700;letter-spacing:2px">' . esc_html( $brand ) . '</div>'
            . '<h1 class="vww-email-heading" style="margin:10px 0 24px;text-align:center;color:' . esc_attr( $settings[ $prefix . 'primary_color' ] ) . ';font-family:' . $email_font . ';font-size:32px;line-height:1.2">' . esc_html( $heading ) . '</h1>'
            . wp_kses_post( $body )
            . '<p style="margin:24px 0 0;text-align:center;color:#856e66;font-family:' . $email_font . ';font-size:12px;line-height:1.6">' . nl2br( esc_html( $settings[ $prefix . 'footer' ] ) ) . '</p>'
            . '</td></tr></table></td></tr></table></body></html>';
    }

    private function mail_headers( $settings ) {
        return array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . sanitize_text_field( $settings['from_name'] ) . ' <' . sanitize_email( $settings['from_email'] ) . '>',
        );
    }

    public function send_registration_email( $ticket ) {
        if ( ! $ticket || empty( $ticket->email ) ) {
            return false;
        }
        $settings = $this->settings();
        $this->mail_context_ticket_id = (int) $ticket->id;
        $sent = wp_mail(
            $ticket->email,
            $this->render_email_subject( 'registration', $ticket, $settings ),
            $this->render_email( 'registration', $ticket, $settings ),
            $this->mail_headers( $settings )
        );
        $this->mail_context_ticket_id = 0;
        $this->log( $ticket->id, $sent ? 'registration_email_sent' : 'registration_email_failed' );
        return $sent;
    }

    public function send_ticket_email( $ticket, $force_resend = false ) {
        if ( ! $ticket || empty( $ticket->email ) || ! is_email( $ticket->email ) ) {
            return false;
        }
        if ( ! empty( $ticket->trashed_at ) || ( ! $force_resend && 'cancelled' === $ticket->status ) ) {
            $this->log( $ticket->id, 'email_blocked', 'Vé đã hủy hoặc nằm trong thùng rác.' );
            return false;
        }
        $settings = $this->settings();
        $this->mail_last_error = '';
        $this->mail_context_ticket_id = (int) $ticket->id;
        $sent = wp_mail(
            $ticket->email,
            $this->render_email_subject( 'invitation', $ticket, $settings ),
            $this->render_email( 'invitation', $ticket, $settings ),
            $this->mail_headers( $settings )
        );
        $this->mail_context_ticket_id = 0;
        if ( $sent && ! $force_resend ) {
            global $wpdb;
            $update = array(
                'emailed_at' => current_time( 'mysql' ),
                'updated_at' => current_time( 'mysql' ),
            );
            if ( in_array( $ticket->status, array( 'registered', 'issued' ), true ) ) {
                $update['status'] = 'emailed';
            }
            $wpdb->update( $this->table(), $update, array( 'id' => $ticket->id ) );
            $this->log( $ticket->id, 'email_sent', 'WordPress/SMTP đã tiếp nhận yêu cầu gửi.' );
        } elseif ( $sent ) {
            $this->log( $ticket->id, 'email_resent', 'WordPress/SMTP đã tiếp nhận yêu cầu gửi lại đến ' . sanitize_email( $ticket->email ) . '. Trạng thái vé được giữ nguyên.' );
        } else {
            $this->log( $ticket->id, 'email_failed', $this->mail_last_error ?: 'wp_mail() trả về false nhưng không cung cấp lỗi chi tiết.' );
        }
        return $sent;
    }

    private function cf7_form_matches( $contact_form, $configured_id ) {
        $configured_id = trim( (string) $configured_id );
        if ( preg_match( '/id=["\']([^"\']+)["\']/', $configured_id, $match ) ) {
            $configured_id = $match[1];
        }
        if ( '' === $configured_id || ! is_object( $contact_form ) || ! method_exists( $contact_form, 'id' ) ) {
            return false;
        }
        $identifiers = array( (string) $contact_form->id() );
        if ( method_exists( $contact_form, 'hash' ) ) {
            $identifiers[] = (string) $contact_form->hash();
        }
        return in_array( $configured_id, array_filter( $identifiers ), true );
    }

    private function configured_cf7_form_id() {
        $settings = $this->settings();
        return trim( (string) ( $settings['cf7_form_id'] ?? '' ) );
    }

    private function cf7_forms_for_settings() {
        if ( ! class_exists( 'WPCF7_ContactForm' ) || ! method_exists( 'WPCF7_ContactForm', 'find' ) ) {
            return array();
        }
        $forms = WPCF7_ContactForm::find();
        return is_array( $forms ) ? $forms : array();
    }

    private function cf7_field_name( $value ) {
        $value = trim( (string) $value );
        if ( preg_match( '/^\[(?:[a-z0-9_-]+\*?\s+)?([a-z0-9_-]+)/i', $value, $match ) ) {
            $value = $match[1];
        }
        return sanitize_key( preg_replace( '/\[\]$/', '', $value ) );
    }

    private function cf7_value( $posted, $field_name ) {
        $field_name = $this->cf7_field_name( $field_name );
        if ( ! $field_name || ! is_array( $posted ) || ! array_key_exists( $field_name, $posted ) ) {
            return '';
        }
        $value = $posted[ $field_name ];
        if ( is_array( $value ) ) {
            $value = implode( ', ', array_map( 'sanitize_text_field', $value ) );
        }
        return sanitize_text_field( $value );
    }

    private function cf7_current_form() {
        if ( class_exists( 'WPCF7_ContactForm' ) && method_exists( 'WPCF7_ContactForm', 'get_current' ) ) {
            return WPCF7_ContactForm::get_current();
        }
        return null;
    }

    private function rate_hit( $group, $value, $window, $limit ) {
        if ( '' === (string) $value ) {
            return false;
        }
        $key   = 'vww_rl_' . sanitize_key( $group ) . '_' . hash_hmac( 'sha256', (string) $value, wp_salt( 'auth' ) );
        $count = (int) get_transient( $key );
        $count++;
        set_transient( $key, $count, $window );
        return $count > $limit;
    }

    public function cf7_validate_duplicate( $result, $tag ) {
        $settings = $this->settings();
        $form     = $this->cf7_current_form();
        if ( ! $this->cf7_form_matches( $form, $settings['cf7_form_id'] ) ) {
            return $result;
        }

        $name = isset( $tag->name ) ? sanitize_key( $tag->name ) : '';
        $type = isset( $tag->basetype ) ? sanitize_key( $tag->basetype ) : '';
        $raw  = isset( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
        if ( is_array( $raw ) ) {
            $raw = reset( $raw );
        }
        $event_name = sanitize_text_field( $settings['event_name'] );

        if ( 'email' === $type && 'your-email' === $name && ! empty( $settings['duplicate_email_enabled'] ) ) {
            $email = $this->normalize_email( $raw );
            if ( $email && $this->find_email_event( $email, $event_name ) ) {
                $result->invalidate( $tag, 'Email đã được đăng ký.' );
                $this->log( 0, 'duplicate_email_blocked', 'CF7 chặn email đã đăng ký trong sự kiện.' );
            }
        }

        if ( 'tel' === $type && 'your-phone' === $name && ! empty( $settings['duplicate_phone_enabled'] ) ) {
            $phone = $this->normalize_phone( $raw );
            if ( $phone && $this->find_phone_event( $phone, $event_name ) ) {
                $result->invalidate( $tag, 'Số điện thoại đã được đăng ký.' );
                $this->log( 0, 'duplicate_phone_blocked', 'CF7 chặn số điện thoại đã đăng ký trong sự kiện.' );
            }
        }

        return $result;
    }

    public function cf7_spam_guard( $spam ) {
        if ( $spam ) {
            return $spam;
        }
        $settings = $this->settings();
        if ( empty( $settings['rate_limit_enabled'] ) || ! class_exists( 'WPCF7_Submission' ) ) {
            return $spam;
        }
        $submission = WPCF7_Submission::get_instance();
        $form       = $this->cf7_current_form();
        if ( ! $submission || ! $this->cf7_form_matches( $form, $settings['cf7_form_id'] ) ) {
            return $spam;
        }
        $posted = $submission->get_posted_data();
        $email  = $this->normalize_email( $this->cf7_value( $posted, 'your-email' ) );
        $phone  = $this->normalize_phone( $this->cf7_value( $posted, 'your-phone' ) );
        $ip     = '';
        if ( method_exists( $submission, 'get_meta' ) ) {
            $ip = (string) $submission->get_meta( 'remote_ip' );
        }
        if ( '' === $ip && isset( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
        }
        $blocked = ( ! empty( $settings['rate_email_enabled'] ) && $this->rate_hit( 'email', $email, max( 1, absint( $settings['rate_email_minutes'] ) ) * MINUTE_IN_SECONDS, max( 1, absint( $settings['rate_email_limit'] ) ) ) )
            || ( ! empty( $settings['rate_phone_enabled'] ) && $this->rate_hit( 'phone', $phone, max( 1, absint( $settings['rate_phone_minutes'] ) ) * MINUTE_IN_SECONDS, max( 1, absint( $settings['rate_phone_limit'] ) ) ) )
            || ( ! empty( $settings['rate_ip_short_enabled'] ) && $this->rate_hit( 'ip_short', $ip, max( 1, absint( $settings['rate_ip_short_minutes'] ) ) * MINUTE_IN_SECONDS, max( 1, absint( $settings['rate_ip_short_limit'] ) ) ) )
            || ( ! empty( $settings['rate_ip_day_enabled'] ) && $this->rate_hit( 'ip_day', $ip, max( 1, absint( $settings['rate_ip_day_hours'] ) ) * HOUR_IN_SECONDS, max( 1, absint( $settings['rate_ip_day_limit'] ) ) ) );
        if ( $blocked ) {
            $this->log( 0, 'security_rate_limited', 'CF7 request blocked; IP hash: ' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ), 0, 16 ) );
            if ( method_exists( $submission, 'add_spam_log' ) ) {
                $submission->add_spam_log(
                    array(
                        'agent'  => 'vww-invitation-manager',
                        'reason' => 'Vượt giới hạn gửi đăng ký.',
                    )
                );
            }
            return true;
        }
        return $spam;
    }

    private function find_email_event( $email, $event_name ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->table()} WHERE normalized_email=%s AND event_name=%s ORDER BY id ASC LIMIT 1",
                $this->normalize_email( $email ),
                sanitize_text_field( $event_name )
            )
        );
    }

    private function find_phone_event( $phone, $event_name ) {
        global $wpdb;
        $normalized = $this->normalize_phone( $phone );
        if ( '' === $normalized ) {
            return null;
        }
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->table()} WHERE normalized_phone=%s AND event_name=%s ORDER BY id ASC LIMIT 1",
                $normalized,
                sanitize_text_field( $event_name )
            )
        );
    }

    /**
     * Disable Contact Form 7's customer autoresponder for the current request.
     *
     * The plugin sends its own invitation email in automatic mode. Leaving CF7
     * Mail (2) active would make the guest receive both the invitation and the
     * old "registration successful" message. This only changes the in-memory
     * form object for the current submission; the saved CF7 form is untouched
     * and the primary administrator notification remains enabled.
     */
    private function suppress_cf7_customer_autoresponder( $contact_form ) {
        if ( ! is_object( $contact_form ) || ! method_exists( $contact_form, 'prop' ) || ! method_exists( $contact_form, 'set_properties' ) ) {
            return;
        }

        $mail_2 = $contact_form->prop( 'mail_2' );
        if ( ! is_array( $mail_2 ) || empty( $mail_2['active'] ) ) {
            return;
        }

        $mail_2['active'] = false;
        $contact_form->set_properties( array( 'mail_2' => $mail_2 ) );
    }

    private function attribution_from_cf7( $posted ) {
        $get = function( $key ) use ( $posted ) {
            return $this->cf7_value( $posted, $key );
        };
        $utm_source = sanitize_text_field( $get( 'vww_utm_source' ) );
        $raw_source = sanitize_text_field( $get( 'vww_first_source' ) );
        $referrer   = esc_url_raw( $get( 'vww_first_referrer' ) );
        $landing    = esc_url_raw( $get( 'vww_landing_page' ) );
        $host       = $referrer ? strtolower( (string) wp_parse_url( $referrer, PHP_URL_HOST ) ) : '';
        $host       = preg_replace( '/^www\./', '', $host );
        $source     = $utm_source ?: $raw_source;
        $source_labels = array(
            'zalo'      => 'Zalo',
            'facebook'  => 'Facebook',
            'instagram' => 'Instagram',
            'tiktok'    => 'TikTok',
            'google'    => 'Google',
            'youtube'   => 'YouTube',
            'qr'        => 'Mã QR',
            'direct'    => 'Truy cập trực tiếp',
        );
        $source_key = strtolower( trim( $source ) );
        if ( isset( $source_labels[ $source_key ] ) ) {
            $source = $source_labels[ $source_key ];
        }
        if ( ! $source && $host ) {
            $map = array( 'facebook.com'=>'Facebook', 'l.facebook.com'=>'Facebook', 'instagram.com'=>'Instagram', 'tiktok.com'=>'TikTok', 'google.com'=>'Google', 'youtube.com'=>'YouTube', 'zalo.me'=>'Zalo' );
            foreach ( $map as $domain => $label ) {
                if ( $host === $domain || substr( $host, -strlen( '.' . $domain ) ) === '.' . $domain ) {
                    $source = $label;
                    break;
                }
            }
            $source = $source ?: $host;
        }
        $source = $source ?: 'Truy cập trực tiếp';
        $medium = sanitize_text_field( $get( 'vww_utm_medium' ) );
        $type   = $utm_source ? ( preg_match( '/cpc|ppc|paid|ads?/i', $medium ) ? 'paid' : 'campaign' ) : ( $referrer ? 'referral' : 'direct' );
        $time   = sanitize_text_field( $get( 'vww_attributed_at' ) );
        return array(
            'attribution_source' => $source,
            'attribution_type'   => $type,
            'landing_page'       => $landing,
            'first_referrer'     => $referrer,
            'referrer_domain'    => $host,
            'utm_source'         => $utm_source,
            'utm_medium'         => $medium,
            'utm_campaign'       => sanitize_text_field( $get( 'vww_utm_campaign' ) ),
            'utm_content'        => sanitize_text_field( $get( 'vww_utm_content' ) ),
            'utm_term'           => sanitize_text_field( $get( 'vww_utm_term' ) ),
            'attributed_at'      => preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $time ) ? $time : current_time( 'mysql' ),
        );
    }

    public function create_from_cf7( $contact_form, &$abort, $submission ) {
        if ( ! $submission || ! is_object( $submission ) || $abort ) {
            return;
        }
        $settings = $this->settings();
        if ( ! $this->cf7_form_matches( $contact_form, $settings['cf7_form_id'] ) ) {
            return;
        }

        $posted    = $submission->get_posted_data();
        $full_name= $this->cf7_value( $posted, 'your-name' );
        $email    = $this->normalize_email( $this->cf7_value( $posted, 'your-email' ) );
        if ( ! $full_name || ! is_email( $email ) ) {
            return;
        }
        $event_name = sanitize_text_field( $settings['event_name'] );
        $existing   = $this->find_email_event( $email, $event_name );
        if ( $existing ) {
            $this->log( $existing->id, 'duplicate_registration_ignored', 'CF7 gửi trùng email/sự kiện; không cấp và không gửi lại vé.' );
            return;
        }

        $phone          = $this->cf7_value( $posted, 'your-phone' );
        $registration_url = method_exists( $submission, 'get_meta' ) ? esc_url_raw( (string) $submission->get_meta( 'url' ) ) : '';
        if ( ! $registration_url ) {
            $registration_url = esc_url_raw( wp_get_referer() ?: '' );
        }
        $referrer_url = method_exists( $submission, 'get_meta' ) ? esc_url_raw( (string) $submission->get_meta( 'referrer' ) ) : '';
        $phone_duplicate= $this->find_phone_event( $phone, $event_name );
        $ticket_data = array_merge(
            array(
                'full_name'      => $full_name,
                'phone'          => $phone,
                'email'          => $email,
                'wedding_date'   => $this->cf7_value( $posted, 'wedding-date' ),
                'customer_role'  => $this->cf7_value( $posted, 'your-role' ),
                'interest'       => $this->cf7_value( $posted, $settings['cf7_event_content_field'] ),
                'event_name'     => $event_name,
                'source'         => 'cf7',
                'source_form_id' => method_exists( $contact_form, 'id' ) ? $contact_form->id() : null,
                'registration_url'=> $registration_url,
                'referrer_url'    => $referrer_url,
                'status'          => 'registered',
            ),
            $this->attribution_from_cf7( $posted )
        );
        $ticket = $this->create_ticket(
            $ticket_data,
            false
        );
        if ( is_wp_error( $ticket ) ) {
            error_log( 'VWW ticket error: ' . $ticket->get_error_message() );
            return;
        }
        $this->cf7_ticket_url = $this->ticket_url( $ticket );
        $this->cf7_pending_ticket_id = (int) $ticket->id;
        if ( $phone_duplicate && $this->normalize_email( $phone_duplicate->email ) !== $email ) {
            $this->log( $ticket->id, 'needs_review_phone_duplicate', 'Trùng số điện thoại với vé ' . $phone_duplicate->ticket_code . '; giữ trạng thái chờ duyệt.' );
            return;
        }
    }

    /**
     * Run every VWW write only after Contact Form 7 has successfully completed
     * its own mail transaction. Nothing in ticket creation, attribution or the
     * guest email can change CF7's mail status.
     */
    public function process_cf7_after_mail_sent( $contact_form ) {
        if ( ! class_exists( 'WPCF7_Submission' ) ) {
            return;
        }
        $submission = WPCF7_Submission::get_instance();
        if ( ! $submission ) {
            return;
        }
        $abort = false;
        $this->create_from_cf7( $contact_form, $abort, $submission );
        $this->queue_pending_cf7_email( $contact_form );
    }

    /**
     * Queue the guest email and immediately return control to Contact Form 7.
     * No second wp_mail() call is allowed inside CF7's AJAX/REST request.
     */
    private function queue_pending_cf7_email( $contact_form ) {
        if ( ! $this->cf7_pending_ticket_id ) {
            return;
        }
        $settings = $this->settings();
        if ( ! $this->cf7_form_matches( $contact_form, $settings['cf7_form_id'] ) ) {
            return;
        }
        $ticket_id = (int) $this->cf7_pending_ticket_id;
        $this->cf7_pending_ticket_id = 0;
        if ( ! $ticket_id ) {
            return;
        }

        $args = array( $ticket_id );
        if ( ! wp_next_scheduled( 'vww_im_send_queued_cf7_email', $args ) ) {
            $scheduled = wp_schedule_single_event( time() + 10, 'vww_im_send_queued_cf7_email', $args );
            $this->log( $ticket_id, $scheduled ? 'cf7_email_queued' : 'cf7_email_queue_failed', 'Email được tách khỏi request Contact Form 7.' );
        }
    }

    /**
     * WP-Cron worker. Mail failures here can never change CF7's submission
     * status because the original request has already finished.
     */
    public function send_queued_cf7_email( $ticket_id ) {
        $ticket = $this->get_ticket( absint( $ticket_id ) );
        if ( ! $ticket || ! empty( $ticket->trashed_at ) || 'cancelled' === $ticket->status ) {
            return;
        }
        $settings  = $this->settings();
        $auto_send = ! empty( $settings['auto_send_invitation'] ) && ! empty( $settings['turnstile_confirmed'] );
        if ( $auto_send ) {
            $sent = $this->send_ticket_email( $ticket );
            $this->log( $ticket->id, $sent ? 'auto_invitation_sent' : 'auto_invitation_failed', 'Gửi qua hàng đợi sau khi request CF7 kết thúc.' );
        } else {
            $this->send_registration_email( $ticket );
        }
    }

    public function capture_mail_failure( $error ) {
        if ( ! $this->mail_context_ticket_id || ! is_wp_error( $error ) ) {
            return;
        }
        $data = $error->get_error_data();
        $details = $error->get_error_message();
        if ( is_array( $data ) && ! empty( $data['phpmailer_exception_code'] ) ) {
            $details .= ' | PHPMailer code: ' . sanitize_text_field( (string) $data['phpmailer_exception_code'] );
        }
        $this->mail_last_error = $details;
        $this->log( $this->mail_context_ticket_id, 'wp_mail_failed', $details );
    }

    /**
     * Return the newly created ticket URL in Contact Form 7's successful AJAX
     * response. The URL contains only the plugin's random ticket token; guest
     * details are never exposed as individual query parameters.
     */
    public function cf7_feedback_response( $response, $result = array() ) {
        $form = $this->cf7_current_form();
        if ( $this->cf7_ticket_url && is_array( $response ) && $this->cf7_form_matches( $form, $this->configured_cf7_form_id() ) ) {
            $response['vww_ticket_url'] = esc_url_raw( $this->cf7_ticket_url );
        }
        return $response;
    }

    private function is_checkin_staff_user( $user = null ) {
        $user = $user instanceof WP_User ? $user : wp_get_current_user();
        return $user && in_array( 'vww_checkin_staff', (array) $user->roles, true ) && ! user_can( $user, 'manage_options' );
    }

    private function staff_center_url() {
        return home_url( '/check-in-center/' );
    }

    private function staff_login_url() {
        return home_url( '/check-in-login/' );
    }

    private function current_public_path() {
        $path = wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH );
        $path = is_string( $path ) ? $path : '/';
        $home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
        $home_path = is_string( $home_path ) ? rtrim( $home_path, '/' ) : '';
        if ( $home_path && '/' !== $home_path && 0 === strpos( $path, $home_path ) ) {
            $path = substr( $path, strlen( $home_path ) );
        }
        return '/' . trim( $path, '/' ) . '/';
    }

    public function hide_checkin_staff_admin_bar( $show ) {
        return $this->is_checkin_staff_user() ? false : $show;
    }

    public function checkin_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if ( $user instanceof WP_User && $this->is_checkin_staff_user( $user ) ) {
            return $this->staff_center_url();
        }
        return $redirect_to;
    }

    public function redirect_checkin_staff_dashboard() {
        global $pagenow;
        if ( ! $this->is_checkin_staff_user() || wp_doing_ajax() || is_network_admin() ) {
            return;
        }
        // Staff never sees wp-admin, but admin-post.php remains available for the
        // one whitelisted core download action used by Check-in Center Export.
        $action = sanitize_key( wp_unslash( $_REQUEST['action'] ?? '' ) );
        if ( 'admin-post.php' === $pagenow && 'vww_im_staff_export_xlsx' === $action ) {
            return;
        }
        wp_safe_redirect( $this->staff_center_url() );
        exit;
    }

    public function render_staff_routes() {
        $path = $this->current_public_path();
        if ( '/check-in-login/' === $path ) {
            $this->render_staff_login_page();
        }
        if ( '/check-in-center/' === $path ) {
            $this->render_staff_center_page();
        }
    }

    private function staff_page_header( $title, $body_class = '' ) {
        nocache_headers();
        status_header( 200 );
        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
        echo '<!doctype html><html lang="vi"><head><meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>' . esc_html( $title ) . '</title>';
        echo '<link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/ticket-fonts.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( self::VERSION ) . '">';
        echo '<link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/public.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( self::VERSION ) . '">';
        echo '<link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/staff-center.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( self::VERSION ) . '">';
        echo '</head><body class="vww-staff-app ' . esc_attr( $body_class ) . '">';
    }

    private function staff_page_footer() {
        echo '</body></html>';
        exit;
    }

    private function render_staff_login_page() {
        if ( is_user_logged_in() && ( current_user_can( 'vww_checkin' ) || current_user_can( 'manage_options' ) ) ) {
            wp_safe_redirect( $this->staff_center_url() );
            exit;
        }

        $error = '';
        if ( 'POST' === strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            $nonce = sanitize_text_field( wp_unslash( $_POST['vww_staff_nonce'] ?? '' ) );
            if ( ! wp_verify_nonce( $nonce, 'vww_staff_login' ) ) {
                $error = 'Phiên đăng nhập đã hết hạn. Vui lòng thử lại.';
            } else {
                $credentials = array(
                    'user_login'    => sanitize_text_field( wp_unslash( $_POST['log'] ?? '' ) ),
                    'user_password' => (string) wp_unslash( $_POST['pwd'] ?? '' ),
                    'remember'      => ! empty( $_POST['rememberme'] ),
                );
                $user = wp_signon( $credentials, is_ssl() );
                if ( is_wp_error( $user ) ) {
                    $error = 'Tên đăng nhập/email hoặc mật khẩu chưa đúng.';
                } elseif ( $this->is_checkin_staff_user( $user ) || user_can( $user, 'manage_options' ) ) {
                    wp_safe_redirect( $this->staff_center_url() );
                    exit;
                } else {
                    wp_logout();
                    $error = 'Tài khoản này không có quyền truy cập VWW Check-in Center.';
                }
            }
        }

        $this->staff_page_header( 'Đăng nhập · VWW Check-in Center', 'vww-staff-login-page' );
        echo '<main class="vww-staff-login-shell"><section class="vww-staff-login-card">'
            . '<div class="vww-staff-login-brand"><span class="vww-staff-mark">W</span><small>VIETNAM WEDDING WEEK</small><strong>STAFF CHECK-IN</strong></div>'
            . '<div class="vww-staff-login-copy"><p>EVENT OPERATIONS</p><h1>Đăng nhập</h1><span>Hệ thống dành cho nhân viên vận hành sự kiện.</span></div>';
        if ( $error ) {
            echo '<div class="vww-staff-alert is-error">' . esc_html( $error ) . '</div>';
        }
        echo '<form class="vww-staff-login-form" method="post" action="' . esc_url( $this->staff_login_url() ) . '">'
            . wp_nonce_field( 'vww_staff_login', 'vww_staff_nonce', true, false )
            . '<label><span>Tên đăng nhập hoặc Email</span><input type="text" name="log" autocomplete="username" required autofocus></label>'
            . '<label><span>Mật khẩu</span><input type="password" name="pwd" autocomplete="current-password" required></label>'
            . '<label class="vww-staff-remember"><input type="checkbox" name="rememberme" value="forever"> <span>Ghi nhớ đăng nhập trên thiết bị này</span></label>'
            . '<button type="submit" class="vww-staff-primary">ĐĂNG NHẬP</button>'
            . '</form><p class="vww-staff-login-note">VWW Check-in Center · Authorized staff only</p>'
            . '</section></main>';
        $this->staff_page_footer();
    }

    private function staff_scanner_markup() {
        return '<div class="vww-scanner vww-checkin-center">'
            . '<div class="vww-scanner-app-head"><div><p class="vww-kicker">CHECK-IN</p><h1>Quét vé mời</h1></div><span id="vww-camera-status" class="vww-camera-status is-idle"><i></i><span>Camera tắt</span></span></div>'
            . '<div class="vww-camera-tools"><span id="vww-camera-name">Ưu tiên camera chính phía sau</span><div class="vww-camera-actions"><button type="button" id="vww-start-camera">Mở camera</button><button type="button" id="vww-switch-camera" hidden>↻ Đổi camera</button><button type="button" id="vww-stop-camera" hidden>Dừng camera</button></div></div>'
            . '<div class="vww-reader-wrap"><div id="vww-reader" class="vww-reader"><div class="vww-camera-off-state"><span aria-hidden="true">◉</span><strong>Camera đang tắt</strong><p>Bấm “Mở camera” để bắt đầu quét QR.</p></div></div><div class="vww-camera-guide" aria-hidden="true"><span>Đưa mã QR vào khung</span></div>'
            . '<div id="vww-scan-success" class="vww-scan-success" role="status" aria-live="assertive" aria-hidden="true"><span id="vww-scan-success-icon" class="vww-scan-success__icon" aria-hidden="true">✓</span><strong id="vww-scan-success-title">CHECK-IN THÀNH CÔNG</strong><span id="vww-scan-success-name" class="vww-scan-success__name"></span><small id="vww-scan-success-code" class="vww-scan-success__code"></small><small id="vww-scan-success-meta" class="vww-scan-success__meta"></small><button type="button" id="vww-scan-continue" class="vww-scan-success__continue">QUÉT VÉ TIẾP →</button></div></div>'
            . '<details class="vww-manual-disclosure"><summary>⌨ Nhập mã vé thủ công</summary><div class="vww-manual"><input id="vww-ticket-code" placeholder="Nhập mã vé"><button id="vww-checkin">Xác nhận check-in</button></div><div id="vww-result" class="vww-result">Sẵn sàng quét Vé Mời.</div></details>'
            . '</div>';
    }

    private function render_staff_center_page() {
        if ( ! is_user_logged_in() ) {
            wp_safe_redirect( $this->staff_login_url() );
            exit;
        }
        if ( ! current_user_can( 'vww_checkin' ) && ! current_user_can( 'manage_options' ) ) {
            status_header( 403 );
            wp_die( 'Tài khoản không có quyền truy cập VWW Check-in Center.' );
        }

        $user = wp_get_current_user();
        $yesterday_dt = current_datetime()->modify( '-1 day' );
        $config = array(
            'listEndpoint'      => rest_url( 'vww/v1/tickets' ),
            'ticketEndpoint'    => rest_url( 'vww/v1/tickets' ),
            'bulkEndpoint'      => rest_url( 'vww/v1/staff/tickets/bulk' ),
            'checkinEndpoint'   => rest_url( 'vww/v1/checkin' ),
            'recentEndpoint'    => rest_url( 'vww/v1/checkins/recent' ),
            'exportUrl'         => admin_url( 'admin-post.php' ),
            'exportAction'      => 'vww_im_staff_export_xlsx',
            'exportNonce'       => wp_create_nonce( 'vww_staff_export' ),
            'nonce'             => wp_create_nonce( 'wp_rest' ),
            'today'             => current_time( 'Y-m-d' ),
            'yesterday'         => $yesterday_dt->format( 'Y-m-d' ),
            'canResend'         => current_user_can( 'vww_resend_ticket' ) || current_user_can( 'manage_options' ),
            'canReset'          => current_user_can( 'vww_reset_checkin' ) || current_user_can( 'manage_options' ),
            'canExport'         => current_user_can( 'vww_export_tickets' ) || current_user_can( 'manage_options' ),
            'canBulkCheckin'    => current_user_can( 'vww_checkin' ) || current_user_can( 'manage_options' ),
            'canBulkResend'     => current_user_can( 'vww_resend_ticket' ) || current_user_can( 'manage_options' ),
        );
        $scanner_config = array(
            'endpoint' => rest_url( 'vww/v1/checkin' ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
        );
        $export_fields   = $this->staff_export_field_map();
        $export_defaults = $this->staff_export_default_fields();
        $export_groups   = array(
            'Thông tin khách' => array( 'ticket_code','full_name','phone','email' ),
            'Thông tin sự kiện' => array( 'event_name','event_content','customer_role','wedding_date','source' ),
            'Trạng thái & thời gian' => array( 'status','created_at','emailed_at','checked_in_at','checked_in_by' ),
        );
        $export_field_html = '';
        foreach ( $export_groups as $group_label => $keys ) {
            $export_field_html .= '<fieldset class="vww-export-field-group"><legend>' . esc_html( $group_label ) . '</legend><div class="vww-export-field-grid">';
            foreach ( $keys as $key ) {
                if ( ! isset( $export_fields[ $key ] ) ) {
                    continue;
                }
                $checked = in_array( $key, $export_defaults, true );
                $export_field_html .= '<label><input type="checkbox" data-export-field value="' . esc_attr( $key ) . '" data-default="' . ( $checked ? '1' : '0' ) . '" ' . checked( $checked, true, false ) . '><span>' . esc_html( $export_fields[ $key ] ) . '</span></label>';
            }
            $export_field_html .= '</div></fieldset>';
        }

        $this->staff_page_header( 'VWW Check-in Center', 'vww-staff-center-page' );
        echo '<header class="vww-staff-topbar"><div class="vww-staff-brand"><span class="vww-staff-mark">W</span><div><small>VIETNAM WEDDING WEEK</small><strong>CHECK-IN CENTER</strong></div></div>'
            . '<div class="vww-staff-topbar-right"><span class="vww-staff-online"><i></i> ONLINE</span><details class="vww-staff-user-menu"><summary><span class="vww-staff-avatar">' . esc_html( strtoupper( substr( $user->user_login, 0, 1 ) ) ) . '</span><span class="vww-staff-user-copy"><strong>' . esc_html( $user->display_name ) . '</strong><small>Nhân viên Check-in</small></span><span class="vww-staff-chevron">⌄</span></summary><div class="vww-staff-user-popover"><span>' . esc_html( $user->user_email ) . '</span><a href="' . esc_url( wp_logout_url( $this->staff_login_url() ) ) . '">Đăng xuất</a></div></details></div></header>';
        echo '<nav class="vww-staff-nav" aria-label="Check-in Center"><button type="button" class="is-active" data-vww-staff-tab="scanner"><span class="vww-nav-icon">▣</span><span>Quét QR</span></button><button type="button" data-vww-staff-tab="guests"><span class="vww-nav-icon">◉</span><span>Khách mời</span></button></nav>';
        echo '<main class="vww-staff-main">'
            . '<section class="vww-staff-panel is-active" data-vww-staff-panel="scanner"><div class="vww-scanner-column">' . $this->staff_scanner_markup()
            . '<section class="vww-recent-checkins"><header><div><p>LIVE LOG</p><h2>Check-in gần nhất</h2></div><div class="vww-recent-head-meta"><span id="vww-recent-today">Hôm nay: 0</span><button type="button" id="vww-recent-view-all">Xem tất cả →</button></div></header><div id="vww-recent-list" class="vww-recent-list"><div class="vww-recent-empty">Đang tải check-in gần nhất…</div></div></section></div></section>'
            . '<section class="vww-staff-panel" data-vww-staff-panel="guests">'
            . '<div class="vww-staff-section-head"><div><p>GUEST OPERATIONS</p><h1>Khách mời</h1><div class="vww-guest-summary"><span><b id="vww-staff-stat-total">0</b> khách</span><span><b id="vww-staff-stat-checked">0</b> check-in</span><span><b id="vww-staff-stat-waiting">0</b> chờ</span><span><b id="vww-staff-stat-today">0</b> hôm nay</span></div></div><div class="vww-staff-section-actions"><button type="button" id="vww-staff-refresh">↻ Làm mới</button>'
            . ( $config['canExport'] ? '<button type="button" id="vww-staff-export" class="is-primary">↓ Xuất Excel</button>' : '' )
            . '</div></div>'
            . '<div class="vww-status-tabs" aria-label="Lọc nhanh"><button type="button" class="is-active" data-status-chip="">Tất cả <b id="vww-staff-count-all">0</b></button><button type="button" data-status-chip="pending">Đăng ký <b id="vww-staff-count-registered">0</b></button><button type="button" data-status-chip="emailed">Đã gửi vé <b id="vww-staff-count-emailed">0</b></button><button type="button" data-status-chip="checked_in">Đã check-in <b id="vww-staff-count-checked_in">0</b></button><button type="button" data-status-chip="cancelled">Đã hủy <b id="vww-staff-count-cancelled">0</b></button></div>'
            . '<div class="vww-staff-searchbar"><span>⌕</span><input id="vww-staff-search" type="search" placeholder="Tìm tên, SĐT, Email hoặc Mã vé"><button type="button" id="vww-staff-filter-toggle">⚙ Bộ lọc</button></div>'
            . '<div id="vww-staff-filter-panel" class="vww-staff-filter-panel"><div class="vww-filter-panel-head"><div><p>BỘ LỌC</p><h2>Lọc danh sách khách</h2></div><button type="button" id="vww-staff-filter-close" aria-label="Đóng">×</button></div><div class="vww-staff-filters"><label><span>Trạng thái</span><select id="vww-staff-status"><option value="">Tất cả trạng thái</option><option value="pending">Đăng ký / Chưa phát hành</option><option value="registered">Đăng ký, chưa gửi vé</option><option value="issued">Chưa gửi vé</option><option value="emailed">Đã gửi vé / Chưa check-in</option><option value="checked_in">Đã check-in</option><option value="cancelled">Đã hủy</option></select></label><label><span>Sự kiện</span><select id="vww-staff-event"><option value="">Tất cả sự kiện</option></select></label><label><span>Nguồn</span><select id="vww-staff-source"><option value="">Tất cả nguồn</option></select></label>'
            . '<div class="vww-checkin-date-filter"><span class="vww-filter-label">Ngày Check-in</span><div class="vww-date-quick"><button type="button" data-date-quick="today">Hôm nay</button><button type="button" data-date-quick="yesterday">Hôm qua</button><button type="button" data-date-quick="clear">Bỏ ngày</button></div><div class="vww-date-range"><label><span>Từ ngày</span><input type="date" id="vww-staff-checkin-from"></label><label><span>Đến ngày</span><input type="date" id="vww-staff-checkin-to"></label></div><small>Chọn cùng một ngày để xuất danh sách Check-in của đúng ngày sự kiện.</small></div>'
            . '</div><div class="vww-filter-panel-actions"><button type="button" id="vww-staff-filter-reset">Xóa bộ lọc</button><button type="button" id="vww-staff-filter-apply">Áp dụng</button></div></div><div id="vww-filter-backdrop" class="vww-filter-backdrop"></div>'
            . '<div id="vww-staff-notice" class="vww-staff-alert" hidden></div><div class="vww-staff-list-meta"><span id="vww-staff-count">Đang tải…</span><span id="vww-staff-sync">Chỉ làm mới khi có thao tác hoặc bấm ↻</span></div>'
            . '<div id="vww-selection-bar" class="vww-selection-bar" hidden><div class="vww-selection-summary"><strong id="vww-selected-count">0 khách đã chọn</strong><button type="button" id="vww-select-all-results" hidden>Chọn toàn bộ kết quả đang lọc</button></div><div class="vww-selection-actions"><select id="vww-bulk-action"><option value="">Thao tác với khách đã chọn</option>'
            . ( $config['canBulkCheckin'] ? '<option value="mark_checked_in">Check-in khách đã chọn</option>' : '' )
            . ( $config['canBulkResend'] ? '<option value="resend">Gửi lại vé đã chọn</option>' : '' )
            . '</select><button type="button" id="vww-bulk-apply">Áp dụng</button>'
            . ( $config['canExport'] ? '<button type="button" id="vww-export-selected">↓ Export đã chọn</button>' : '' )
            . '<button type="button" id="vww-selection-clear" class="is-quiet">Bỏ chọn</button></div></div>'
            . '<div class="vww-staff-table-wrap"><table class="vww-staff-table"><thead><tr><th class="vww-select-col"><input type="checkbox" id="vww-select-page" aria-label="Chọn khách trên trang này"></th><th>Khách mời</th><th>Liên hệ</th><th>Sự kiện</th><th>Nguồn</th><th>Trạng thái</th><th></th></tr></thead><tbody id="vww-staff-rows"><tr><td colspan="7">Đang tải dữ liệu…</td></tr></tbody></table></div><div id="vww-staff-cards" class="vww-staff-cards"></div>'
            . '<div class="vww-staff-pagination"><button type="button" id="vww-staff-prev">← Trước</button><span id="vww-staff-page">Trang 1</span><button type="button" id="vww-staff-next">Sau →</button></div>'
            . '</section></main>'
            . '<div id="vww-staff-modal" class="vww-staff-modal" hidden><div class="vww-staff-modal-backdrop" data-modal-close></div><section class="vww-staff-modal-card" role="dialog" aria-modal="true" aria-labelledby="vww-staff-modal-title"><button type="button" class="vww-staff-modal-x" data-modal-close aria-label="Đóng">×</button><p id="vww-staff-modal-kicker">XÁC NHẬN</p><h2 id="vww-staff-modal-title">Xác nhận thao tác</h2><div id="vww-staff-modal-body" class="vww-staff-modal-body"></div><div class="vww-staff-modal-actions"><button type="button" id="vww-staff-modal-cancel" data-modal-close>Hủy</button><button type="button" id="vww-staff-modal-confirm">Xác nhận</button></div></section></div>'
            . ( $config['canExport'] ? '<div id="vww-export-modal" class="vww-staff-modal vww-export-modal" hidden><div class="vww-staff-modal-backdrop" data-export-close></div><section class="vww-staff-modal-card vww-export-modal-card" role="dialog" aria-modal="true" aria-labelledby="vww-export-title"><button type="button" class="vww-staff-modal-x" data-export-close aria-label="Đóng">×</button><p>EXPORT EXCEL</p><h2 id="vww-export-title">Xuất danh sách khách</h2><div class="vww-export-scope"><strong>Phạm vi xuất</strong><label><input type="radio" name="vww-export-scope" value="filtered" checked><span>Kết quả đang lọc <b id="vww-export-filtered-count">0 khách</b></span></label><label id="vww-export-selected-option" hidden><input type="radio" name="vww-export-scope" value="selected"><span>Khách đã chọn <b id="vww-export-selected-count">0 khách</b></span></label></div><div class="vww-export-fields-head"><strong>Trường dữ liệu</strong><div><button type="button" id="vww-export-default-fields">Chọn mặc định</button><button type="button" id="vww-export-all-fields">Chọn tất cả</button></div></div>' . $export_field_html . '<div class="vww-staff-modal-actions"><button type="button" data-export-close>Hủy</button><button type="button" id="vww-export-confirm">XUẤT EXCEL</button></div></section></div>' : '' )
            . '<div id="vww-staff-toast" class="vww-staff-toast" role="status" aria-live="polite"></div>';
        echo '<script>window.VWWScanner=' . wp_json_encode( $scanner_config ) . ';window.VWWStaffCenter=' . wp_json_encode( $config ) . ';</script>';
        echo '<script src="' . esc_url( plugins_url( 'assets/js/html5-qrcode.min.js', VWW_IM_FILE ) ) . '?ver=' . esc_attr( self::VERSION ) . '"></script>';
        echo '<script src="' . esc_url( plugins_url( 'assets/js/scanner.js', VWW_IM_FILE ) ) . '?ver=' . esc_attr( self::VERSION ) . '"></script>';
        $staff_js_path = VWW_IM_DIR . 'assets/js/staff-center.js';
        $staff_js_ver  = self::VERSION . '.' . ( is_file( $staff_js_path ) ? (string) filemtime( $staff_js_path ) : '0' );
        echo '<script src="' . esc_url( plugins_url( 'assets/js/staff-center.js', VWW_IM_FILE ) ) . '?ver=' . esc_attr( $staff_js_ver ) . '"></script>';
        $this->staff_page_footer();
    }

    public function admin_menu() {
        add_menu_page( 'VWW Vé mời', 'VWW Vé mời', 'vww_view_tickets', 'vww-invitations', array( $this, 'admin_dashboard' ), 'dashicons-tickets-alt', 26 );
        add_submenu_page( 'vww-invitations', 'Vé mời & Khách đăng ký', 'Danh sách khách mời', 'vww_view_tickets', 'vww-invitations', array( $this, 'admin_dashboard' ) );
        add_submenu_page( 'vww-invitations', 'Tạo vé mới', 'Tạo vé mới', 'manage_options', 'vww-create-ticket', array( $this, 'admin_create' ) );
        add_submenu_page( 'vww-invitations', 'Import Excel', 'Import Excel', 'manage_options', 'vww-import', array( $this, 'admin_import' ) );
        add_submenu_page( 'vww-invitations', 'Đồng bộ Flamingo', 'Đồng bộ Flamingo', 'manage_options', 'vww-flamingo', array( $this, 'admin_flamingo' ) );
        add_submenu_page( 'vww-invitations', 'Mẫu email', 'Mẫu email', 'manage_options', 'vww-email-template', array( $this, 'admin_email_template' ) );
        add_submenu_page( 'vww-invitations', 'Thiết kế trang vé', 'Thiết kế trang vé', 'manage_options', 'vww-ticket-design', array( $this, 'admin_ticket_design' ) );
        add_submenu_page( 'vww-invitations', 'Cấu hình', 'Cấu hình', 'manage_options', 'vww-settings', array( $this, 'admin_settings' ) );
        add_submenu_page( 'vww-invitations', 'Sửa vé', 'Sửa vé', 'manage_options', 'vww-edit-ticket', array( $this, 'admin_edit_ticket' ) );
        if ( $this->is_checkin_staff_user() ) {
            remove_menu_page( 'index.php' );
        }
    }

    public function admin_assets( $hook ) {
        if ( false === strpos( $hook, 'vww' ) ) {
            return;
        }
        wp_enqueue_style( 'vww-im-admin', plugins_url( 'assets/css/admin.css', VWW_IM_FILE ), array(), self::VERSION );
        if ( false !== strpos( $hook, 'vww-invitations' ) ) {
            $this->enqueue_dashboard_assets();
        }
        if ( false !== strpos( $hook, 'vww-email-template' ) ) {
            $this->enqueue_email_template_assets();
        }
        if ( false !== strpos( $hook, 'vww-ticket-design' ) ) {
            wp_enqueue_media();
            wp_enqueue_style( 'vww-im-ticket-design', plugins_url( 'assets/css/ticket-design.css', VWW_IM_FILE ), array( 'vww-im-admin' ), self::VERSION );
            wp_enqueue_style( 'vww-im-ticket-design-patch', plugins_url( 'assets/css/ticket-design-patch.css', VWW_IM_FILE ), array( 'vww-im-ticket-design' ), self::VERSION );
            wp_enqueue_style( 'vww-im-ticket-v2', plugins_url( 'assets/css/ticket-v2.css', VWW_IM_FILE ), array( 'vww-im-ticket-design-patch' ), self::VERSION );
            wp_enqueue_style( 'vww-im-ticket-custom', plugins_url( 'assets/css/ticket-custom.css', VWW_IM_FILE ), array( 'vww-im-ticket-v2' ), self::VERSION );
            wp_enqueue_script( 'vww-im-ticket-design', plugins_url( 'assets/js/ticket-design.js', VWW_IM_FILE ), array(), self::VERSION, true );
            wp_localize_script( 'vww-im-ticket-design', 'VWWTicketDesign', array( 'fontCss'=>plugins_url( 'assets/css/ticket-fonts.css', VWW_IM_FILE ) . '?ver=' . self::VERSION, 'publicCss'=>plugins_url( 'assets/css/public.css', VWW_IM_FILE ) . '?ver=' . self::VERSION, 'publicV2Css'=>plugins_url( 'assets/css/ticket-v2.css', VWW_IM_FILE ) . '?ver=' . self::VERSION, 'customCss'=>plugins_url( 'assets/css/ticket-custom.css', VWW_IM_FILE ) . '?ver=' . self::VERSION ) );
            wp_enqueue_script( 'vww-im-ticket-design-patch', plugins_url( 'assets/js/ticket-design-patch.js', VWW_IM_FILE ), array( 'vww-im-ticket-design' ), self::VERSION, true );
        }
        if ( false !== strpos( $hook, 'vww-import' ) ) {
            wp_enqueue_style( 'vww-im-import', plugins_url( 'assets/css/import.css', VWW_IM_FILE ), array( 'vww-im-admin' ), self::VERSION );
        }
    }

    public function public_assets() {
        $design = $this->ticket_design_settings();
        $style_version = self::VERSION . '.' . absint( $design['ticket_design_version'] ?? 1 );
        wp_register_style( 'vww-im-ticket-fonts', plugins_url( 'assets/css/ticket-fonts.css', VWW_IM_FILE ), array(), $style_version );
        wp_register_style( 'vww-im-public-base', plugins_url( 'assets/css/public.css', VWW_IM_FILE ), array( 'vww-im-ticket-fonts' ), $style_version );
        wp_register_style( 'vww-im-public', plugins_url( 'assets/css/ticket-v2.css', VWW_IM_FILE ), array( 'vww-im-public-base' ), $style_version );
        if ( ! empty( $_GET['vww_ticket'] ) ) {
            wp_enqueue_style( 'vww-im-public' );
            if ( ! empty( $design['ticket_custom_css'] ) ) wp_add_inline_style( 'vww-im-public', $design['ticket_custom_css'] );
        }
        wp_register_script( 'vww-html5-qrcode', plugins_url( 'assets/js/html5-qrcode.min.js', VWW_IM_FILE ), array(), self::VERSION, true );
        wp_register_script( 'vww-im-scanner', plugins_url( 'assets/js/scanner.js', VWW_IM_FILE ), array( 'vww-html5-qrcode' ), self::VERSION, true );
        $configured_form_id = $this->configured_cf7_form_id();
        if ( '' !== $configured_form_id ) {
            wp_enqueue_script( 'vww-im-cf7-ticket-redirect', plugins_url( 'assets/js/cf7-ticket-redirect.js', VWW_IM_FILE ), array(), self::VERSION, true );
            wp_localize_script( 'vww-im-cf7-ticket-redirect', 'VWWCF7Config', array(
                'formId'   => $configured_form_id,
                'endpoint' => rest_url( 'vww/v1/cf7-ticket' ),
                'nonce'    => wp_create_nonce( 'wp_rest' ),
            ) );
        }
    }

    private function enqueue_dashboard_assets() {
        wp_enqueue_style( 'vww-im-dashboard', plugins_url( 'assets/css/dashboard.css', VWW_IM_FILE ), array( 'vww-im-admin' ), self::VERSION );
        wp_enqueue_script( 'vww-im-dashboard', plugins_url( 'assets/js/dashboard.js', VWW_IM_FILE ), array(), self::VERSION, true );
        wp_localize_script(
            'vww-im-dashboard',
            'VWWDashboard',
            array(
                'listEndpoint'    => rest_url( 'vww/v1/tickets' ),
                'ticketEndpoint'  => rest_url( 'vww/v1/tickets' ),
                'bulkEndpoint'    => rest_url( 'vww/v1/tickets/bulk' ),
                'checkinEndpoint' => rest_url( 'vww/v1/checkin' ),
                'exportXlsxUrl'   => wp_nonce_url( admin_url( 'admin-post.php?action=vww_im_export_xlsx' ), 'vww_export' ),
                'exportCsvUrl'    => wp_nonce_url( admin_url( 'admin-post.php?action=vww_im_export_csv' ), 'vww_export' ),
                'nonce'           => wp_create_nonce( 'wp_rest' ),
                'canManage'       => current_user_can( 'manage_options' ),
            )
        );
    }

    private function enqueue_email_template_assets() {
        $type = isset( $_GET['email_type'] ) && 'registration' === sanitize_key( wp_unslash( $_GET['email_type'] ) ) ? 'registration' : 'invitation';
        wp_enqueue_media();
        wp_enqueue_style( 'vww-im-email-template', plugins_url( 'assets/css/email-template.css', VWW_IM_FILE ), array( 'vww-im-admin' ), self::VERSION );
        wp_enqueue_script( 'vww-im-email-template', plugins_url( 'assets/js/email-template.js', VWW_IM_FILE ), array(), self::VERSION, true );
        wp_localize_script(
            'vww-im-email-template',
            'VWWEmailTemplate',
            array(
                'previewEndpoint' => rest_url( 'vww/v1/email-preview' ),
                'testEndpoint'    => rest_url( 'vww/v1/email-test' ),
                'nonce'           => wp_create_nonce( 'wp_rest' ),
                'type'            => $type,
                'bodyId'          => 'registration' === $type ? 'vww_registration_body' : 'vww_invitation_body',
                'bodyKey'         => 'registration' === $type ? 'registration_body' : 'invitation_body',
            )
        );
    }

    private function ticket_design_keys() {
        return array(
            'ticket_eyebrow','ticket_title','ticket_intro','ticket_email_note','ticket_event_label',
            'ticket_invitation_title','ticket_logo_url','ticket_monogram','ticket_brand_name','ticket_invite_phrase',
            'ticket_concept','ticket_event_date','ticket_event_time','ticket_venue','ticket_address','ticket_guest_count',
            'ticket_checkin_note','ticket_instruction','ticket_primary_color','ticket_accent_color',
            'ticket_background_color','ticket_card_color','ticket_text_color','ticket_schedule_url',
            'ticket_contact_url','ticket_map_url','ticket_home_url','ticket_schedule_label','ticket_contact_label','ticket_map_label','ticket_home_label',
            'ticket_custom_css',
            'ticket_design_version',
        );
    }

    private function ticket_design_settings() {
        return array_intersect_key( $this->settings(), array_flip( $this->ticket_design_keys() ) );
    }

    private function sanitize_ticket_design( $input ) {
        $defaults = self::default_settings();
        $input    = is_array( $input ) ? $input : array();
        $clean    = array();
        $textarea = array( 'ticket_intro', 'ticket_email_note', 'ticket_instruction' );
        $colors   = array( 'ticket_primary_color','ticket_accent_color','ticket_background_color','ticket_card_color','ticket_text_color' );
        $urls     = array( 'ticket_logo_url','ticket_schedule_url','ticket_contact_url','ticket_map_url','ticket_home_url' );
        foreach ( $this->ticket_design_keys() as $key ) {
            $value = $input[ $key ] ?? $defaults[ $key ];
            if ( 'ticket_custom_css' === $key ) {
                $value = wp_strip_all_tags( (string) $value );
                $value = preg_replace( '#</?style[^>]*>#i', '', $value );
                $value = preg_replace( '/@import\s+[^;]+;?/i', '', $value );
                $value = preg_replace( '/(?:expression|javascript\s*:|behavior\s*:|-moz-binding)\s*/i', '', $value );
                $clean[ $key ] = substr( $value, 0, 50000 );
            } elseif ( in_array( $key, $colors, true ) ) {
                $clean[ $key ] = sanitize_hex_color( $value ) ?: $defaults[ $key ];
            } elseif ( in_array( $key, $urls, true ) ) {
                $clean[ $key ] = esc_url_raw( $value );
            } elseif ( in_array( $key, $textarea, true ) ) {
                $clean[ $key ] = sanitize_textarea_field( $value );
            } elseif ( 'ticket_design_version' === $key ) {
                $clean[ $key ] = max( 1, absint( $value ) );
            } else {
                $clean[ $key ] = sanitize_text_field( $value );
            }
        }
        return $clean;
    }

    public function handle_save_ticket_design() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_save_ticket_design', 'vww_nonce' ) ) {
            wp_die( 'Bạn không có quyền thực hiện thao tác này.' );
        }
        $current = get_option( self::OPTION, array() );
        $current = is_array( $current ) ? $current : array();
        $design  = $this->sanitize_ticket_design( wp_unslash( $_POST ) );
        $design['ticket_design_version'] = max( 1, absint( $current['ticket_design_version'] ?? 1 ) + 1 );
        update_option( self::OPTION, array_merge( $current, $design ), false );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-ticket-design&vww_notice=saved' ) );
        exit;
    }

    public function admin_ticket_design() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Bạn không có quyền truy cập.' );
        }
        $s = $this->ticket_design_settings();
        $this->admin_head( 'Thiết kế trang Vé mời' );
        if ( isset( $_GET['vww_notice'] ) && 'saved' === sanitize_key( wp_unslash( $_GET['vww_notice'] ) ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Đã lưu và xuất bản thiết kế trang vé.</p></div>';
        }
        echo '<div class="vww-design-editor"><form class="vww-design-panel" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" method="post">';
        echo '<input type="hidden" name="action" value="vww_im_save_ticket_design">';
        wp_nonce_field( 'vww_save_ticket_design', 'vww_nonce' );
        echo '<section><h2>Nhận diện trên vé</h2><p class="description">Logo ảnh hoặc monogram luôn hiển thị cùng tên Vietnam Wedding Week.</p>';
        echo '<label>Logo dạng ảnh<div class="vww-ticket-logo-picker"><input type="url" id="vww-ticket-logo-url" name="ticket_logo_url" value="' . esc_attr( $s['ticket_logo_url'] ) . '" data-vww-field="ticket_logo_url"><button type="button" id="vww-select-ticket-logo" class="button">Chọn ảnh</button><button type="button" id="vww-remove-ticket-logo" class="button">Xóa logo</button></div></label>';
        echo '<label>Monogram dự phòng<input type="text" name="ticket_monogram" maxlength="4" value="' . esc_attr( $s['ticket_monogram'] ) . '" data-vww-field="ticket_monogram"></label>';
        echo '<label>Tên thương hiệu luôn hiển thị<input type="text" name="ticket_brand_name" value="' . esc_attr( $s['ticket_brand_name'] ) . '" data-vww-field="ticket_brand_name"></label></section>';
        echo '<section><h2>Thông tin trên vé</h2>';
        $ticket_fields = array(
            'ticket_invite_phrase'=>'Lời mời','ticket_invitation_title'=>'Nhãn loại vé','ticket_concept'=>'Concept / Chủ đề',
            'ticket_event_date'=>'Ngày tổ chức','ticket_event_time'=>'Khung giờ','ticket_venue'=>'Địa điểm',
            'ticket_address'=>'Địa chỉ','ticket_guest_count'=>'Số khách mặc định','ticket_checkin_note'=>'Chỉ dẫn cạnh QR',
        );
        foreach ( $ticket_fields as $key=>$label ) echo '<label>' . esc_html( $label ) . '<input type="text" name="' . esc_attr( $key ) . '" value="' . esc_attr( $s[ $key ] ) . '" data-vww-field="' . esc_attr( $key ) . '"></label>';
        echo '</section>';
        $fields = array(
            'ticket_eyebrow'=>'Nhãn xác nhận','ticket_title'=>'Tiêu đề tổng quan','ticket_intro'=>'Lời chào','ticket_email_note'=>'Thông báo email',
            'ticket_event_label'=>'Tên sự kiện dự phòng','ticket_instruction'=>'Hướng dẫn check-in',
            'ticket_schedule_label'=>'Nhãn nút lịch trình','ticket_schedule_url'=>'Liên kết lịch trình','ticket_contact_label'=>'Nhãn nút liên hệ',
            'ticket_contact_url'=>'Liên kết liên hệ','ticket_map_label'=>'Nhãn nút chỉ đường','ticket_map_url'=>'Google Maps URL',
            'ticket_home_label'=>'Nhãn nút trang chủ','ticket_home_url'=>'Liên kết trang chủ',
        );
        echo '<section><h2>Nội dung và nút</h2><p class="description">Có thể dùng <code>{customer_name}</code> và <code>{customer_email}</code>.</p>';
        foreach ( $fields as $key=>$label ) {
            $is_area = in_array( $key, array( 'ticket_intro','ticket_email_note','ticket_instruction' ), true );
            echo '<label>' . esc_html( $label );
            if ( $is_area ) {
                echo '<textarea name="' . esc_attr( $key ) . '" rows="3" data-vww-field="' . esc_attr( $key ) . '">' . esc_textarea( $s[ $key ] ) . '</textarea>';
            } else {
                echo '<input type="' . ( false !== strpos( $key, '_url' ) ? 'url' : 'text' ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $s[ $key ] ) . '" data-vww-field="' . esc_attr( $key ) . '">';
            }
            echo '</label>';
        }
        echo '</section><section><h2>Màu sắc</h2><div class="vww-color-grid">';
        foreach ( array( 'ticket_primary_color'=>'Màu chủ đạo','ticket_accent_color'=>'Màu nhấn','ticket_background_color'=>'Nền trang','ticket_card_color'=>'Nền vé','ticket_text_color'=>'Màu chữ' ) as $key=>$label ) {
            echo '<label>' . esc_html( $label ) . '<input type="color" name="' . esc_attr( $key ) . '" value="' . esc_attr( $s[ $key ] ) . '" data-vww-color="' . esc_attr( $key ) . '"></label>';
        }
        echo '</div></section><section><h2>CSS tùy chỉnh</h2><p class="description">Chỉ áp dụng trên trang Vé mời. Không nhập HTML hoặc JavaScript.</p><textarea id="vww-ticket-custom-css" class="vww-code-editor" name="ticket_custom_css" rows="16" spellcheck="false" data-vww-custom-css>' . esc_textarea( $s['ticket_custom_css'] ) . '</textarea><details class="vww-css-help"><summary>Các class thường dùng</summary><code>.vww-ticket-page<br>.vww-ticket-shell<br>.vww-overview<br>.vww-invitation-wrap<br>.vww-invitation<br>.vww-ticket-stub<br>.vww-actions</code></details></section><div class="vww-design-save"><button class="button button-primary button-hero">Lưu &amp; xuất bản</button></div></form>';
        echo '<div class="vww-design-preview"><div class="vww-preview-toolbar"><strong>Xem trước trực tiếp</strong><div><button type="button" class="button is-active" data-vww-view="desktop">Desktop</button><button type="button" class="button" data-vww-view="mobile">Mobile</button></div></div><iframe id="vww-ticket-preview" title="Xem trước trang vé"></iframe></div></div></div>';
    }

    private function admin_head( $title, $button = '' ) {
        echo '<div class="wrap vww-admin"><div class="vww-head"><div><span>VIETNAM WEDDING WEEK 2026</span><h1>' . esc_html( $title ) . '</h1></div><div class="vww-head-actions">' . $button . '</div></div>';
    }

    private function checkin_stats() {
        global $wpdb;
        $table   = $this->table();
        $active  = 'trashed_at IS NULL';
        $total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE $active" );
        $checked = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE $active AND status='checked_in'" );
        $waiting = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE $active AND status='emailed'" );
        $today   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE $active AND status='checked_in' AND DATE(checked_in_at)=%s", current_time( 'Y-m-d' ) ) );
        return compact( 'total', 'checked', 'waiting', 'today' );
    }

    public function admin_dashboard() {
        if ( ! current_user_can( 'vww_checkin' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $stats  = $this->checkin_stats();
        $manage = current_user_can( 'manage_options' );
        $buttons = '';
        if ( $manage ) {
            $buttons = '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=vww-import' ) ) . '">Import Excel</a> '
                . '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=vww-email-template' ) ) . '">Mẫu email</a> '
                . '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=vww-settings' ) ) . '">Cấu hình</a> '
                . '<button type="button" id="vww-export-xlsx" class="button">Xuất Excel</button> '
                . '<button type="button" id="vww-export-csv" class="button">CSV</button> '
                . '<a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=vww-create-ticket' ) ) . '">+ Tạo vé mới</a>';
        }
        $this->admin_head( 'Vé mời & Khách đăng ký', $buttons );
        echo '<div class="vww-stats vww-checkin-stats">'
            . '<article><small>TỔNG VÉ</small><b id="vww-stat-total">' . absint( $stats['total'] ) . '</b></article>'
            . '<article><small>ĐÃ CHECK-IN</small><b id="vww-stat-checked">' . absint( $stats['checked'] ) . '</b></article>'
            . '<article><small>CHỜ CHECK-IN</small><b id="vww-stat-waiting">' . absint( $stats['waiting'] ) . '</b></article>'
            . '<article><small>CHECK-IN HÔM NAY</small><b id="vww-stat-today">' . absint( $stats['today'] ) . '</b></article></div>';
        echo '<section class="vww-checkin-manager">'
            . '<div class="vww-manager-head"><div><small>QUẢN LÝ VÉ TRỰC TIẾP</small><h2>Danh sách khách mời</h2></div><button type="button" id="vww-dashboard-refresh" class="button" title="Tải lại danh sách">↻ Làm mới</button></div>'
            . '<nav class="vww-quick-tabs" aria-label="Lọc nhanh">'
            . '<button type="button" class="is-active" data-view="">Tất cả <b id="vww-count-all">0</b></button>'
            . '<button type="button" data-status="registered">Đăng ký <b id="vww-count-registered">0</b></button>'
            . '<button type="button" data-status="emailed">Đã gửi vé <b id="vww-count-emailed">0</b></button>'
            . '<button type="button" data-status="checked_in">Đã check-in <b id="vww-count-checked_in">0</b></button>'
            . '<button type="button" data-status="cancelled">Đã hủy <b id="vww-count-cancelled">0</b></button>'
            . ( $manage ? '<button type="button" data-view="trash">Thùng rác <b id="vww-count-trash">0</b></button>' : '' )
            . '</nav>'
            . '<div class="vww-dashboard-filters vww-filters-primary">'
            . '<input id="vww-dashboard-search" type="search" placeholder="Tìm tên, SĐT, email hoặc mã vé">'
            . '<select id="vww-dashboard-status"><option value="">Tất cả trạng thái</option><option value="registered">Đăng ký, chưa gửi vé</option><option value="issued">Chưa gửi vé</option><option value="emailed">Đã gửi vé</option><option value="checked_in">Đã check-in</option><option value="cancelled">Đã hủy</option></select>'
            . '<select id="vww-dashboard-event"><option value="">Tất cả sự kiện</option></select>'
            . '<button type="button" id="vww-toggle-advanced" class="button" aria-expanded="false">Bộ lọc nâng cao</button>'
            . '</div><div id="vww-advanced-filters" class="vww-dashboard-filters vww-filters-advanced" hidden>'
            . '<select id="vww-dashboard-interest"><option value="">Tất cả nội dung sự kiện</option></select>'
            . '<select id="vww-dashboard-source"><option value="">Tất cả nguồn</option></select>'
            . '<select id="vww-dashboard-registration-url"><option value="">Tất cả trang đăng ký</option></select>'
            . '<select id="vww-dashboard-batch"><option value="">Tất cả đợt import</option></select>'
            . '<select id="vww-dashboard-date-type"><option value="created">Ngày đăng ký</option><option value="emailed">Ngày gửi vé</option><option value="checked">Ngày check-in</option></select>'
            . '<input id="vww-dashboard-date-from" type="date" aria-label="Từ ngày"><input id="vww-dashboard-date-to" type="date" aria-label="Đến ngày">'
            . '</div>';
        if ( $manage ) {
            echo '<div class="vww-bulk-bar" hidden>'
                . '<label><input type="checkbox" id="vww-select-page"> Chọn trang này</label>'
                . '<button type="button" id="vww-select-filtered" class="button-link">Chọn toàn bộ kết quả lọc</button>'
                . '<span id="vww-selected-count">0 vé đã chọn</span>'
                . '<select id="vww-bulk-action"><option value="">Thao tác hàng loạt</option></select>'
                . '<button type="button" id="vww-apply-bulk" class="button">Áp dụng</button></div>';
        }
        echo '<div class="vww-dashboard-meta"><span id="vww-dashboard-count">Đang tải danh sách…</span><span id="vww-dashboard-sync">Cập nhật sau khi check-in hoặc bấm ↻</span></div>'
            . '<div id="vww-dashboard-notice" class="vww-dashboard-notice" hidden></div>'
            . '<div class="vww-dashboard-table-wrap"><table class="widefat striped vww-table vww-checkin-table"><thead><tr>'
            . ( $manage ? '<th class="check-column"><input type="checkbox" id="vww-select-page-head"></th>' : '' )
            . '<th>Mã vé / Khách</th><th>Liên hệ</th><th>Sự kiện / Nội dung</th><th>Nguồn</th><th>Trạng thái</th><th>Thao tác</th>'
            . '</tr></thead><tbody id="vww-dashboard-rows"><tr><td colspan="' . ( $manage ? 7 : 6 ) . '">Đang tải dữ liệu…</td></tr></tbody></table></div>'
            . '<div class="vww-pagination"><button type="button" id="vww-page-prev" class="button">← Trước</button><span id="vww-page-label">Trang 1</span><button type="button" id="vww-page-next" class="button">Sau →</button></div>'
            . '</section></div>';
    }

    public function admin_create() {
        $this->admin_head( 'Tạo vé mời thủ công' );
        if ( isset( $_GET['vww_notice'] ) ) {
            $notice = sanitize_key( wp_unslash( $_GET['vww_notice'] ) );
            if ( 'created' === $notice ) {
                echo '<div class="notice notice-success"><p>Đã tạo và gửi Vé Mời.</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Không thể tạo vé. Hãy kiểm tra email bắt buộc, dữ liệu trùng và cấu hình SMTP.</p></div>';
            }
        }
        $settings = $this->settings();
        echo '<form class="vww-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
            . '<input type="hidden" name="action" value="vww_im_create_ticket">'
            . wp_nonce_field( 'vww_create_ticket', 'vww_nonce', true, false )
            . '<p><label>Họ & Tên *</label><input required name="full_name"></p>'
            . '<p><label>Số điện thoại</label><input name="phone"></p>'
            . '<p><label>Email *</label><input required type="email" name="email"></p>'
            . '<p><label>Ngày cưới dự kiến</label><input type="date" name="wedding_date"></p>'
            . '<p><label>Vai trò</label><select name="customer_role"><option>Cô dâu / Chú rể tương lai</option><option>Người thân / bạn bè hỗ trợ chuẩn bị cưới</option><option>Khách quan tâm đến Wedding Lifestyle</option></select></p>'
            . '<p><label>Nội dung sự kiện</label><input name="interest" placeholder="Nhập nội dung sự kiện khách đăng ký"></p>'
            . '<p><label>Nguồn khách</label><select name="source"><option value="zalo">Zalo</option><option value="facebook">Facebook</option><option value="hotline">Hotline</option><option value="partner">Đối tác</option><option value="admin">Khác</option></select></p>'
            . '<p><label>Mã ngoài (nếu có)</label><input name="external_id"></p>'
            . '<p><label>Sự kiện</label><input name="event_name" value="' . esc_attr( $settings['event_name'] ) . '"></p>'
            . '<p class="vww-full"><button class="button button-primary button-large">Tạo vé & Gửi email</button></p></form></div>';
    }

    public function admin_edit_ticket() {
        $ticket = $this->get_ticket( absint( $_GET['id'] ?? 0 ) );
        if ( ! $ticket ) {
            wp_die( 'Không tìm thấy vé.' );
        }
        $this->admin_head( 'Sửa vé: ' . $ticket->ticket_code );
        if ( isset( $_GET['vww_notice'] ) ) {
            $notice = sanitize_key( wp_unslash( $_GET['vww_notice'] ) );
            echo 'updated' === $notice
                ? '<div class="notice notice-success"><p>Đã lưu thay đổi.</p></div>'
                : '<div class="notice notice-error"><p>Không thể lưu do email/sự kiện trùng với vé khác.</p></div>';
        }
        $fields = array(
            'full_name'     => 'Họ & Tên',
            'phone'         => 'Số điện thoại',
            'email'         => 'Email',
            'wedding_date'  => 'Ngày cưới dự kiến',
            'customer_role' => 'Vai trò',
            'interest'      => 'Nội dung sự kiện',
            'event_name'    => 'Sự kiện',
            'external_id'   => 'Mã ngoài',
            'source'        => 'Nguồn',
            'registration_url' => 'URL trang đăng ký',
            'referrer_url'     => 'Referrer URL',
        );
        echo '<div class="vww-ticket-created"><strong>Thời gian đăng ký:</strong> ' . esc_html( $this->format_site_datetime( $ticket->created_at, 'd/m/Y H:i', '—' ) ) . ' <small>(' . esc_html( $this->site_timezone_label() ) . ')</small></div>';
        echo '<div class="vww-setting-card vww-full"><h2>Nguồn giới thiệu</h2><p><strong>Nguồn:</strong> ' . esc_html( $ticket->attribution_source ?: 'Chưa ghi nhận' ) . ' &nbsp; <strong>Loại:</strong> ' . esc_html( $ticket->attribution_type ?: '—' ) . '</p>'
            . '<p><strong>Website/ứng dụng:</strong> ' . esc_html( $ticket->referrer_domain ?: '—' ) . '<br><strong>Landing page đầu tiên:</strong> ' . ( $ticket->landing_page ? '<a href="' . esc_url( $ticket->landing_page ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $ticket->landing_page ) . '</a>' : '—' ) . '<br><strong>Referrer đầu tiên:</strong> ' . ( $ticket->first_referrer ? '<a href="' . esc_url( $ticket->first_referrer ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $ticket->first_referrer ) . '</a>' : '—' ) . '</p>'
            . '<p><strong>UTM:</strong> source=' . esc_html( $ticket->utm_source ?: '—' ) . ' · medium=' . esc_html( $ticket->utm_medium ?: '—' ) . ' · campaign=' . esc_html( $ticket->utm_campaign ?: '—' ) . ' · content=' . esc_html( $ticket->utm_content ?: '—' ) . ' · term=' . esc_html( $ticket->utm_term ?: '—' ) . '</p></div>';
        echo '<form class="vww-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_update_ticket"><input type="hidden" name="id" value="' . absint( $ticket->id ) . '">' . wp_nonce_field( 'vww_update_ticket_' . $ticket->id, 'vww_nonce', true, false );
        foreach ( $fields as $key => $label ) {
            echo '<p><label>' . esc_html( $label ) . '</label><input ' . ( 'wedding_date' === $key ? 'type="date"' : '' ) . ' name="' . esc_attr( $key ) . '" value="' . esc_attr( $ticket->$key ) . '"></p>';
        }
        echo '<p class="vww-note">Trạng thái vé được thay đổi bằng các thao tác Xác nhận, Check-in, Hủy hoặc Khôi phục trong danh sách để luôn có nhật ký.</p>'
            . '<p class="vww-full"><button class="button button-primary button-large">Lưu thay đổi</button> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=vww-invitations' ) ) . '">Quay lại</a></p></form></div>';
    }

    public function admin_email_template() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $type = isset( $_GET['email_type'] ) && 'registration' === sanitize_key( wp_unslash( $_GET['email_type'] ) ) ? 'registration' : 'invitation';
        if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['vww_email_template_nonce'] ) ) {
            check_admin_referer( 'vww_email_template', 'vww_email_template_nonce' );
            $settings = $this->settings();
            if ( isset( $_POST['vww_email_template_reset'] ) ) {
                $settings = array_merge( $settings, $this->template_defaults( $type ) );
                update_option( self::OPTION, $settings );
                add_settings_error( 'vww_email_template', 'reset', 'Đã khôi phục mẫu email mặc định.', 'updated' );
            } else {
                $settings = array_merge( $settings, $this->sanitize_template( $type, wp_unslash( $_POST ) ) );
                update_option( self::OPTION, $settings );
                add_settings_error( 'vww_email_template', 'saved', 'Đã lưu mẫu email.', 'updated' );
            }
        }
        $settings  = $this->settings();
        $prefix    = 'registration' === $type ? 'registration_' : 'invitation_';
        $subject   = 'registration' === $type ? 'registration_subject' : 'email_subject';
        $body_key  = $prefix . 'body';
        $title     = 'registration' === $type ? 'Email đăng ký thành công' : 'Email Vé Mời';
        $variables = 'registration' === $type
            ? array( '{customer_name}', '{customer_email}', '{customer_phone}', '{event_name}', '{event_content}', '{customer_role}', '{wedding_date}', '{registration_date}' )
            : array( '{customer_name}', '{customer_email}', '{customer_phone}', '{ticket_code}', '{event_name}', '{event_content}', '{customer_role}', '{wedding_date}', '{qr_code}', '{ticket_details}', '{ticket_button}', '{ticket_url}' );

        $this->admin_head( 'Trình soạn thảo email trực quan' );
        settings_errors( 'vww_email_template' );
        echo '<nav class="nav-tab-wrapper vww-email-tabs"><a class="nav-tab ' . ( 'registration' === $type ? 'nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vww-email-template&email_type=registration' ) ) . '">Email đăng ký thành công</a><a class="nav-tab ' . ( 'invitation' === $type ? 'nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vww-email-template&email_type=invitation' ) ) . '">Email Vé Mời</a></nav>';
        echo '<form method="post" id="vww-email-template-form" class="vww-email-builder">';
        wp_nonce_field( 'vww_email_template', 'vww_email_template_nonce' );
        echo '<input type="hidden" name="email_type" value="' . esc_attr( $type ) . '"><div class="vww-email-builder__main"><section class="vww-email-panel"><small>NỘI DUNG</small><h2>' . esc_html( $title ) . '</h2>'
            . '<label class="vww-email-field"><span>Tiêu đề email</span><input name="' . esc_attr( $subject ) . '" value="' . esc_attr( $settings[ $subject ] ) . '"></label>'
            . '<label class="vww-email-field"><span>Dòng xem trước</span><input name="' . esc_attr( $prefix . 'preheader' ) . '" value="' . esc_attr( $settings[ $prefix . 'preheader' ] ) . '"></label>'
            . '<div class="vww-email-two"><label class="vww-email-field"><span>Tên thương hiệu</span><input name="' . esc_attr( $prefix . 'brand_name' ) . '" value="' . esc_attr( $settings[ $prefix . 'brand_name' ] ) . '"></label>'
            . '<label class="vww-email-field"><span>Tiêu đề lớn</span><input name="' . esc_attr( $prefix . 'heading' ) . '" value="' . esc_attr( $settings[ $prefix . 'heading' ] ) . '"></label></div>'
            . '<div class="vww-email-field"><span>Biến dữ liệu</span><div class="vww-email-variables">';
        foreach ( $variables as $variable ) {
            echo '<button type="button" class="button vww-insert-variable" data-token="' . esc_attr( $variable ) . '">' . esc_html( $variable ) . '</button>';
        }
        echo '</div></div><div class="vww-email-field"><span>Nội dung email</span>';
        wp_editor(
            $settings[ $body_key ],
            'vww_' . $body_key,
            array(
                'textarea_name' => $body_key,
                'textarea_rows' => 16,
                'media_buttons' => true,
                'teeny'         => false,
            )
        );
        echo '</div>';
        if ( 'invitation' === $type ) {
            echo '<label class="vww-email-field"><span>Nhãn nút mở vé</span><input name="invitation_button_text" value="' . esc_attr( $settings['invitation_button_text'] ) . '"></label>';
        }
        echo '<label class="vww-email-field"><span>Chân email</span><textarea name="' . esc_attr( $prefix . 'footer' ) . '" rows="3">' . esc_textarea( $settings[ $prefix . 'footer' ] ) . '</textarea></label></section>'
            . '<aside class="vww-email-builder__side"><section class="vww-email-panel"><small>NHẬN DIỆN</small><h2>Logo & màu sắc</h2>'
            . '<label class="vww-email-field"><span>Logo</span><div class="vww-logo-picker"><input id="vww-template-logo-url" name="' . esc_attr( $prefix . 'logo_url' ) . '" value="' . esc_attr( $settings[ $prefix . 'logo_url' ] ) . '"><button type="button" id="vww-select-email-logo" class="button">Chọn ảnh</button></div></label>'
            . '<div class="vww-color-grid">';
        foreach ( array( 'bg_color'=>'Nền ngoài', 'card_color'=>'Nền thẻ', 'primary_color'=>'Màu chính', 'accent_color'=>'Màu nhấn', 'text_color'=>'Màu chữ' ) as $suffix => $label ) {
            $key = $prefix . $suffix;
            echo '<label><span>' . esc_html( $label ) . '</span><input type="color" name="' . esc_attr( $key ) . '" value="' . esc_attr( $settings[ $key ] ) . '"></label>';
        }
        echo '</div></section><section class="vww-email-panel"><small>KIỂM TRA</small><h2>Xem trước & gửi thử</h2>'
            . '<button type="button" id="vww-email-preview" class="button button-large">Xem trước</button>'
            . '<label class="vww-email-field"><span>Email nhận bản thử</span><input id="vww-test-email-address" type="email" value="' . esc_attr( wp_get_current_user()->user_email ) . '"></label>'
            . '<button type="button" id="vww-send-test-email" class="button">Gửi email thử</button><div id="vww-email-test-result" class="vww-email-result" hidden></div></section></aside></div>'
            . '<div class="vww-email-actions"><button type="submit" name="vww_email_template_save" class="button button-primary button-large">Lưu mẫu email</button><button type="submit" name="vww_email_template_reset" id="vww-reset-email-template" class="button button-large">Khôi phục mặc định</button><span>Email thử không tạo vé và không đổi trạng thái vé.</span></div></form>'
            . '<div id="vww-email-preview-modal" class="vww-email-modal" hidden><div class="vww-email-modal__dialog"><div class="vww-email-modal__head"><div><small>BẢN XEM TRƯỚC</small><strong id="vww-email-preview-subject"></strong></div><button type="button" id="vww-close-email-preview" aria-label="Đóng">×</button></div><iframe id="vww-email-preview-frame" title="Xem trước email"></iframe></div></div></div>';
    }

    private function turnstile_detected() {
        return class_exists( 'WPCF7_Turnstile' )
            || class_exists( 'Simple_Cloudflare_Turnstile' )
            || defined( 'CF7_TURNSTILE_VERSION' )
            || defined( 'SIMPLE_CLOUDFLARE_TURNSTILE_VERSION' );
    }

    public function admin_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Không có quyền.' );
        }
        if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['vww_settings_nonce'] ) ) {
            check_admin_referer( 'vww_settings', 'vww_settings_nonce' );
            $old = $this->settings();
            $new = array_merge(
                $old,
                array(
                    'event_name'             => sanitize_text_field( wp_unslash( $_POST['event_name'] ?? '' ) ),
                    'cf7_form_id'             => sanitize_text_field( wp_unslash( $_POST['cf7_form_id'] ?? '' ) ),
                    'cf7_event_content_field' => $this->cf7_field_name( wp_unslash( $_POST['cf7_event_content_field'] ?? '' ) ),
                    'from_name'               => sanitize_text_field( wp_unslash( $_POST['from_name'] ?? '' ) ),
                    'from_email'              => sanitize_email( wp_unslash( $_POST['from_email'] ?? '' ) ),
                    'auto_send_invitation'    => empty( $_POST['auto_send_invitation'] ) ? 0 : 1,
                    'rate_limit_enabled'      => empty( $_POST['rate_limit_enabled'] ) ? 0 : 1,
                    'duplicate_email_enabled' => empty( $_POST['duplicate_email_enabled'] ) ? 0 : 1,
                    'duplicate_phone_enabled' => empty( $_POST['duplicate_phone_enabled'] ) ? 0 : 1,
                    'rate_email_enabled'      => empty( $_POST['rate_email_enabled'] ) ? 0 : 1,
                    'rate_email_limit'        => max( 1, absint( $_POST['rate_email_limit'] ?? 3 ) ),
                    'rate_email_minutes'      => max( 1, absint( $_POST['rate_email_minutes'] ?? 60 ) ),
                    'rate_phone_enabled'      => empty( $_POST['rate_phone_enabled'] ) ? 0 : 1,
                    'rate_phone_limit'        => max( 1, absint( $_POST['rate_phone_limit'] ?? 3 ) ),
                    'rate_phone_minutes'      => max( 1, absint( $_POST['rate_phone_minutes'] ?? 60 ) ),
                    'rate_ip_short_enabled'   => empty( $_POST['rate_ip_short_enabled'] ) ? 0 : 1,
                    'rate_ip_short_limit'     => max( 1, absint( $_POST['rate_ip_short_limit'] ?? 10 ) ),
                    'rate_ip_short_minutes'   => max( 1, absint( $_POST['rate_ip_short_minutes'] ?? 15 ) ),
                    'rate_ip_day_enabled'     => empty( $_POST['rate_ip_day_enabled'] ) ? 0 : 1,
                    'rate_ip_day_limit'       => max( 1, absint( $_POST['rate_ip_day_limit'] ?? 30 ) ),
                    'rate_ip_day_hours'       => max( 1, absint( $_POST['rate_ip_day_hours'] ?? 24 ) ),
                    'turnstile_confirmed'     => empty( $_POST['turnstile_confirmed'] ) ? 0 : 1,
                )
            );
            if ( empty( $new['event_name'] ) ) {
                $new['event_name'] = self::default_settings()['event_name'];
            }
            if ( empty( $new['cf7_event_content_field'] ) ) {
                $new['cf7_event_content_field'] = 'your-interest';
            }
            if ( ! empty( $_POST['vww_reset_spam_defaults'] ) ) {
                $defaults = self::default_settings();
                foreach ( array(
                    'rate_limit_enabled', 'duplicate_email_enabled', 'duplicate_phone_enabled',
                    'rate_email_enabled', 'rate_email_limit', 'rate_email_minutes',
                    'rate_phone_enabled', 'rate_phone_limit', 'rate_phone_minutes',
                    'rate_ip_short_enabled', 'rate_ip_short_limit', 'rate_ip_short_minutes',
                    'rate_ip_day_enabled', 'rate_ip_day_limit', 'rate_ip_day_hours',
                ) as $key ) {
                    $new[ $key ] = $defaults[ $key ];
                }
                add_settings_error( 'vww_settings', 'spam_reset', 'Đã khôi phục cấu hình chống spam mặc định.', 'updated' );
            }
            if ( $new['auto_send_invitation'] && ! $new['turnstile_confirmed'] ) {
                $new['auto_send_invitation'] = 0;
                add_settings_error( 'vww_settings', 'turnstile', 'Chưa bật gửi vé tự động vì bạn chưa xác nhận Cloudflare Turnstile đang hoạt động.', 'error' );
            }
            update_option( self::OPTION, $new );
            add_settings_error( 'vww_settings', 'saved', 'Đã lưu cấu hình.', 'updated' );
        }
        $settings = $this->settings();
        $this->admin_head( 'Cấu hình plugin' );
        settings_errors( 'vww_settings' );
        $cf7_options = '<option value="">— Chưa chọn: không xử lý form nào —</option>';
        foreach ( $this->cf7_forms_for_settings() as $cf7_form ) {
            $form_id = method_exists( $cf7_form, 'id' ) ? (string) $cf7_form->id() : '';
            if ( '' === $form_id ) continue;
            $title = method_exists( $cf7_form, 'title' ) ? $cf7_form->title() : 'Contact Form 7';
            $cf7_options .= '<option value="' . esc_attr( $form_id ) . '" ' . selected( (string) $settings['cf7_form_id'], $form_id, false ) . '>' . esc_html( $title . ' — ID: ' . $form_id ) . '</option>';
        }
        echo '<form class="vww-form vww-settings" method="post">' . wp_nonce_field( 'vww_settings', 'vww_settings_nonce', true, false )
            . '<p><label>Tên sự kiện mặc định</label><input name="event_name" value="' . esc_attr( $settings['event_name'] ) . '"></p>'
            . '<p><label>Contact Form 7 áp dụng</label><select name="cf7_form_id">' . $cf7_options . '</select><small>Plugin chỉ tạo vé, kiểm tra trùng, ghi nguồn và chuyển trang cho đúng form này. Chưa chọn thì plugin không tác động Contact Form 7.</small></p>'
            . '<p><label>Field “Nội dung sự kiện”</label><input name="cf7_event_content_field" value="' . esc_attr( $settings['cf7_event_content_field'] ) . '" placeholder="your-interest"></p>'
            . '<p><label>Tên người gửi email</label><input name="from_name" value="' . esc_attr( $settings['from_name'] ) . '"></p>'
            . '<p><label>Email người gửi</label><input type="email" name="from_email" value="' . esc_attr( $settings['from_email'] ) . '"></p>'
            . '<div class="vww-full vww-setting-card"><h2>Luồng gửi email từ Contact Form 7</h2>'
            . '<label class="vww-toggle"><input type="checkbox" name="auto_send_invitation" value="1" ' . checked( ! empty( $settings['auto_send_invitation'] ), true, false ) . '> <span>Bỏ qua email đăng ký thành công và gửi Vé Mời ngay</span></label>'
            . '<p>Khi tắt: khách nhận email đăng ký thành công, Administrator duyệt rồi gửi Vé Mời. Khi bật: riêng đăng ký CF7 hợp lệ sẽ nhận Vé Mời ngay; vé import và vé thủ công không bị thay đổi.</p>'
            . '<label class="vww-toggle"><input type="checkbox" name="turnstile_confirmed" value="1" ' . checked( ! empty( $settings['turnstile_confirmed'] ), true, false ) . '> <span>Tôi xác nhận Cloudflare Turnstile đã được cấu hình và đang bảo vệ form</span></label>'
            . '<p class="vww-turnstile-status ' . ( $this->turnstile_detected() ? 'ok' : 'warning' ) . '">' . ( $this->turnstile_detected() ? '✓ Plugin nhận diện được thành phần Turnstile trên website.' : 'Không thể xác định tự động. Hãy kiểm tra Contact → Tích hợp và thử form ở cửa sổ ẩn danh.' ) . '</p></div>'
            . '<div class="vww-full vww-setting-card"><h2>Chống spam và đăng ký trùng</h2><h3>Chống đăng ký trùng</h3>'
            . '<label class="vww-toggle"><input type="checkbox" name="duplicate_email_enabled" value="1" ' . checked( ! empty( $settings['duplicate_email_enabled'] ), true, false ) . '> <span>Cùng email — báo “Email đã được đăng ký.”</span></label>'
            . '<label class="vww-toggle"><input type="checkbox" name="duplicate_phone_enabled" value="1" ' . checked( ! empty( $settings['duplicate_phone_enabled'] ), true, false ) . '> <span>Cùng số điện thoại — báo “Số điện thoại đã được đăng ký.”</span></label>'
            . '<h3>Giới hạn tần suất</h3>'
            . '<label class="vww-toggle"><input type="checkbox" name="rate_limit_enabled" value="1" ' . checked( ! empty( $settings['rate_limit_enabled'] ), true, false ) . '> <span>Bật lớp giới hạn tần suất</span></label>'
            . '<p class="vww-rate-row"><label><input type="checkbox" name="rate_email_enabled" value="1" ' . checked( ! empty( $settings['rate_email_enabled'] ), true, false ) . '> Cùng email</label><input type="number" min="1" name="rate_email_limit" value="' . absint( $settings['rate_email_limit'] ) . '"> lần / <input type="number" min="1" name="rate_email_minutes" value="' . absint( $settings['rate_email_minutes'] ) . '"> phút</p>'
            . '<p class="vww-rate-row"><label><input type="checkbox" name="rate_phone_enabled" value="1" ' . checked( ! empty( $settings['rate_phone_enabled'] ), true, false ) . '> Cùng số điện thoại</label><input type="number" min="1" name="rate_phone_limit" value="' . absint( $settings['rate_phone_limit'] ) . '"> lần / <input type="number" min="1" name="rate_phone_minutes" value="' . absint( $settings['rate_phone_minutes'] ) . '"> phút</p>'
            . '<p class="vww-rate-row"><label><input type="checkbox" name="rate_ip_short_enabled" value="1" ' . checked( ! empty( $settings['rate_ip_short_enabled'] ), true, false ) . '> Cùng IP ngắn hạn</label><input type="number" min="1" name="rate_ip_short_limit" value="' . absint( $settings['rate_ip_short_limit'] ) . '"> lần / <input type="number" min="1" name="rate_ip_short_minutes" value="' . absint( $settings['rate_ip_short_minutes'] ) . '"> phút</p>'
            . '<p class="vww-rate-row"><label><input type="checkbox" name="rate_ip_day_enabled" value="1" ' . checked( ! empty( $settings['rate_ip_day_enabled'] ), true, false ) . '> Cùng IP dài hạn</label><input type="number" min="1" name="rate_ip_day_limit" value="' . absint( $settings['rate_ip_day_limit'] ) . '"> lần / <input type="number" min="1" name="rate_ip_day_hours" value="' . absint( $settings['rate_ip_day_hours'] ) . '"> giờ</p>'
            . '<p>Email/số điện thoại trùng được báo ngay tại đúng trường CF7. IP chỉ được lưu dưới dạng hash trong nhật ký.</p>'
            . '<p><button class="button" type="submit" name="vww_reset_spam_defaults" value="1">Khôi phục cấu hình chống spam mặc định</button></p></div>'
            . '<p class="vww-full"><button class="button button-primary button-large">Lưu cấu hình</button></p></form></div>';
    }

    private function import_fields() {
        return array(
            'registration_time' => 'time *',
            'registration_date' => 'date *',
            'full_name'         => 'your-name *',
            'email'             => 'your-email *',
            'phone'             => 'your-phone',
            'wedding_date'      => 'wedding-date',
            'customer_role'     => 'your-role',
            'interest'          => 'your-interest',
        );
    }

    private function header_slug( $value ) {
        $value = preg_replace( '/^\xEF\xBB\xBF/', '', trim( (string) $value ) );
        $value = remove_accents( strtolower( $value ) );
        return trim( preg_replace( '/[^a-z0-9]+/', '_', $value ), '_' );
    }

    private function suggest_mapping( $headers ) {
        $aliases = array(
            'registration_time' => array( 'time', 'registration_time', 'gio', 'thoi_gian' ),
            'registration_date' => array( 'date', 'registration_date', 'ngay', 'ngay_dang_ky' ),
            'full_name'         => array( 'your_name', 'full_name', 'ho_ten', 'ho_va_ten', 'name' ),
            'email'             => array( 'your_email', 'email', 'email_address' ),
            'phone'             => array( 'your_phone', 'phone', 'so_dien_thoai', 'sdt', 'dien_thoai' ),
            'wedding_date'      => array( 'wedding_date', 'ngay_cuoi', 'ngay_cuoi_du_kien' ),
            'customer_role'     => array( 'your_role', 'customer_role', 'vai_tro' ),
            'interest'          => array( 'your_interest', 'event_content', 'interest', 'noi_dung_su_kien', 'hang_muc' ),
        );
        $slugs   = array_map( array( $this, 'header_slug' ), $headers );
        $mapping = array();
        foreach ( $aliases as $field => $names ) {
            $mapping[ $field ] = '';
            foreach ( $names as $name ) {
                $index = array_search( $name, $slugs, true );
                if ( false !== $index ) {
                    $mapping[ $field ] = (string) $index;
                    break;
                }
            }
        }
        return $mapping;
    }

    private function read_csv( $path, $limit = 10001 ) {
        $handle = fopen( $path, 'r' );
        if ( ! $handle ) {
            return new WP_Error( 'vww_csv_open', 'Không thể mở file CSV.' );
        }
        $first = fgets( $handle );
        rewind( $handle );
        $delimiter = substr_count( (string) $first, ';' ) > substr_count( (string) $first, ',' ) ? ';' : ',';
        $rows = array();
        while ( ( $row = fgetcsv( $handle, 0, $delimiter ) ) !== false && count( $rows ) < $limit ) {
            $rows[] = array_map( 'trim', $row );
        }
        fclose( $handle );
        return $rows;
    }

    private function parse_import_date( $value ) {
        $value = trim( (string) $value );
        if ( '' === $value ) {
            return null;
        }
        if ( is_numeric( $value ) && (float) $value > 20000 && (float) $value < 80000 ) {
            return gmdate( 'Y-m-d', ( (int) $value - 25569 ) * DAY_IN_SECONDS );
        }
        foreach ( array( 'Y-m-d', 'd/m/Y', 'd-m-Y', 'm/d/Y' ) as $format ) {
            $date = DateTime::createFromFormat( '!' . $format, $value );
            if ( $date && $date->format( $format ) === $value ) {
                return $date->format( 'Y-m-d' );
            }
        }
        return false;
    }

    private function mapped_import_data( $row, $mapping ) {
        $settings = $this->settings();
        $data     = array();
        foreach ( $this->import_fields() as $field => $label ) {
            $index = isset( $mapping[ $field ] ) && '' !== (string) $mapping[ $field ] ? (int) $mapping[ $field ] : -1;
            $data[ $field ] = $index >= 0 && isset( $row[ $index ] ) ? sanitize_text_field( $row[ $index ] ) : '';
        }
        $data['email']        = $this->normalize_email( $data['email'] );
        $data['external_id']  = '';
        $data['ticket_code']  = '';
        $data['source']       = 'excel';
        $data['event_name']   = $settings['event_name'];
        $data['wedding_date'] = $this->parse_import_date( $data['wedding_date'] );
        $data['created_at']   = $this->parse_import_datetime( $data['registration_date'], $data['registration_time'] );
        return $data;
    }

    private function parse_import_datetime( $date_value, $time_value ) {
        $date_value = trim( (string) $date_value );
        $time_value = trim( (string) $time_value );
        if ( '' === $date_value || '' === $time_value ) {
            return false;
        }
        if ( is_numeric( $date_value ) && (float) $date_value > 20000 && (float) $date_value < 80000 ) {
            $date_value = gmdate( 'Y-m-d', ( (int) $date_value - 25569 ) * DAY_IN_SECONDS );
        }
        if ( is_numeric( $time_value ) && (float) $time_value >= 0 && (float) $time_value < 1 ) {
            $seconds    = (int) round( (float) $time_value * DAY_IN_SECONDS );
            $time_value = gmdate( 'H:i:s', min( $seconds, DAY_IN_SECONDS - 1 ) );
        }
        foreach ( array( 'Y-m-d', 'd/m/Y', 'd-m-Y', 'm/d/Y' ) as $date_format ) {
            foreach ( array( 'H:i:s', 'H:i', 'G:i:s', 'G:i' ) as $time_format ) {
                $format = '!' . $date_format . ' ' . $time_format;
                $value  = $date_value . ' ' . $time_value;
                $date   = DateTimeImmutable::createFromFormat( $format, $value, wp_timezone() );
                if ( $date && $date->format( $date_format . ' ' . $time_format ) === $value ) {
                    return $date->format( 'Y-m-d H:i:s' );
                }
            }
        }
        return false;
    }

    private function find_import_match( $data ) {
        global $wpdb;
        $table = $this->table();
        $by_code = null;
        $by_external = null;
        $by_email = null;
        $by_phone = null;
        if ( ! empty( $data['ticket_code'] ) ) {
            $by_code = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE ticket_code=%s", strtoupper( $data['ticket_code'] ) ) );
        }
        if ( ! empty( $data['external_id'] ) ) {
            $by_external = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE external_id=%s AND source=%s ORDER BY id ASC LIMIT 1", $data['external_id'], $data['source'] ) );
        }
        if ( ! empty( $data['email'] ) ) {
            $by_email = $this->find_email_event( $data['email'], $data['event_name'] );
        }
        if ( ! empty( $data['phone'] ) ) {
            $by_phone = $this->find_phone_event( $data['phone'], $data['event_name'] );
        }
        $matches = array_filter( array( $by_code, $by_external, $by_email, $by_phone ) );
        $ids     = array_unique( array_map( function( $ticket ) { return (int) $ticket->id; }, $matches ) );
        if ( count( $ids ) > 1 ) {
            return array( 'conflict' => true, 'ticket' => null, 'message' => 'Các khóa nhận diện đang trỏ tới nhiều vé khác nhau.' );
        }
        $ticket = $by_code ?: ( $by_external ?: ( $by_email ?: $by_phone ) );
        return array( 'conflict' => false, 'ticket' => $ticket, 'message' => '' );
    }

    private function analyze_import_row( $row, $mapping, $mode ) {
        $data = $this->mapped_import_data( $row, $mapping );
        if ( empty( $data['full_name'] ) ) {
            return array( 'action'=>'error', 'message'=>'Thiếu Họ & Tên.', 'data'=>$data, 'ticket_id'=>0 );
        }
        if ( ! is_email( $data['email'] ) ) {
            return array( 'action'=>'error', 'message'=>'Email thiếu hoặc không hợp lệ.', 'data'=>$data, 'ticket_id'=>0 );
        }
        if ( false === $data['created_at'] ) {
            return array( 'action'=>'error', 'message'=>'date hoặc time thiếu/không hợp lệ.', 'data'=>$data, 'ticket_id'=>0 );
        }
        if ( false === $data['wedding_date'] ) {
            return array( 'action'=>'error', 'message'=>'Ngày cưới không hợp lệ.', 'data'=>$data, 'ticket_id'=>0 );
        }
        $match = $this->find_import_match( $data );
        if ( $match['conflict'] ) {
            return array( 'action'=>'conflict', 'message'=>$match['message'], 'data'=>$data, 'ticket_id'=>0 );
        }
        $ticket = $match['ticket'];
        if ( ! $ticket ) {
            return array( 'action'=>'create', 'message'=>'Tạo vé mới ở trạng thái chờ duyệt.', 'data'=>$data, 'ticket_id'=>0 );
        }
        if ( ! empty( $ticket->trashed_at ) || 'cancelled' === $ticket->status ) {
            return array( 'action'=>'conflict', 'message'=>'Vé khớp đang bị hủy hoặc nằm trong thùng rác; không tự khôi phục.', 'data'=>$data, 'ticket_id'=>(int)$ticket->id );
        }
        if ( 'update' !== $mode ) {
            return array( 'action'=>'unchanged', 'message'=>'Đã tồn tại; chế độ chỉ thêm mới.', 'data'=>$data, 'ticket_id'=>(int)$ticket->id );
        }
        $changed = false;
        foreach ( array( 'full_name','phone','email','wedding_date','customer_role','interest','event_name','source','external_id','registration_url','referrer_url' ) as $field ) {
            if ( (string) $ticket->$field !== (string) $data[ $field ] && '' !== (string) $data[ $field ] ) {
                $changed = true;
                break;
            }
        }
        return array(
            'action'    => $changed ? 'update' : 'unchanged',
            'message'   => $changed ? 'Cập nhật các trường thông tin an toàn.' : 'Dữ liệu không thay đổi.',
            'data'      => $data,
            'ticket_id' => (int) $ticket->id,
        );
    }

    private function analyze_import_state( $state ) {
        $counts = array( 'create'=>0, 'update'=>0, 'unchanged'=>0, 'conflict'=>0, 'error'=>0 );
        $items  = array();
        foreach ( array_slice( $state['rows'], 1 ) as $offset => $row ) {
            if ( ! array_filter( $row, 'strlen' ) ) {
                continue;
            }
            $analysis = $this->analyze_import_row( $row, $state['mapping'], $state['mode'] );
            $analysis['row_number'] = $offset + 2;
            $counts[ $analysis['action'] ]++;
            $items[] = $analysis;
        }
        $state['counts']   = $counts;
        $state['analysis'] = $items;
        return $state;
    }

    private function import_transient_key() {
        return 'vww_import_preview_' . get_current_user_id();
    }

    private function flamingo_value( $data, $keys ) {
        foreach ( (array) $keys as $key ) {
            if ( isset( $data[ $key ] ) && ! is_array( $data[ $key ] ) && '' !== trim( (string) $data[ $key ] ) ) {
                return trim( (string) $data[ $key ] );
            }
        }
        return '';
    }

    private function flamingo_key_signature( $key ) {
        $key = strtolower( trim( (string) $key ) );
        $key = preg_replace( '/^(?:_?field[_-]?|_?wpcf7[_-]?)/', '', $key );
        return preg_replace( '/[^a-z0-9]+/', '', $key );
    }

    /** Match Flamingo meta keys even when a release adds prefixes or swaps -/_ separators. */
    private function flamingo_value_flexible( $data, $keys ) {
        $value = $this->flamingo_value( $data, $keys );
        if ( '' !== $value ) return $value;

        $wanted = array_filter( array_map( array( $this, 'flamingo_key_signature' ), (array) $keys ) );
        foreach ( (array) $data as $key => $item ) {
            if ( is_array( $item ) || ! is_scalar( $item ) || '' === trim( (string) $item ) ) continue;
            if ( in_array( $this->flamingo_key_signature( $key ), $wanted, true ) ) return trim( (string) $item );
        }
        return '';
    }

    private function flatten_flamingo_meta( $value, &$flat ) {
        if ( ! is_array( $value ) ) return;
        foreach ( $value as $key => $item ) {
            if ( is_array( $item ) ) {
                $this->flatten_flamingo_meta( $item, $flat );
            } elseif ( is_scalar( $item ) && '' !== trim( (string) $item ) ) {
                $flat[ (string) $key ] = (string) $item;
            }
        }
    }

    private function flamingo_field_key( $key ) {
        $key = trim( (string) $key );
        $key = preg_replace( '/^\[|\]$/', '', $key );
        return sanitize_key( $key );
    }

    /**
     * Read the different field payloads used by Flamingo releases.
     * Besides associative arrays (field-name => value), some releases/plugins
     * store rows as arrays containing name/key and value/values members.
     */
    private function extract_flamingo_fields( $value, &$fields ) {
        if ( ! is_array( $value ) ) return;

        $name = '';
        foreach ( array( 'name', 'key', 'field_name', 'field', 'tag' ) as $name_key ) {
            if ( isset( $value[ $name_key ] ) && is_scalar( $value[ $name_key ] ) ) {
                $name = $this->flamingo_field_key( $value[ $name_key ] );
                if ( $name ) break;
            }
        }
        if ( $name ) {
            foreach ( array( 'value', 'values', 'data' ) as $value_key ) {
                if ( ! isset( $value[ $value_key ] ) ) continue;
                $field_value = $value[ $value_key ];
                if ( is_array( $field_value ) ) {
                    $field_value = implode( ', ', array_filter( array_map( 'strval', $field_value ) ) );
                }
                if ( is_scalar( $field_value ) && '' !== trim( (string) $field_value ) ) {
                    $fields[ $name ] = trim( (string) $field_value );
                    break;
                }
            }
        }

        foreach ( $value as $key => $item ) {
            if ( is_array( $item ) ) {
                $field_key = is_string( $key ) ? $this->flamingo_field_key( $key ) : '';
                $is_list = empty( $item ) || array_keys( $item ) === range( 0, count( $item ) - 1 );
                if ( $field_key && $is_list ) {
                    $scalar_items = array_filter( $item, 'is_scalar' );
                    if ( count( $scalar_items ) === count( $item ) ) {
                        $joined = implode( ', ', array_map( 'strval', $scalar_items ) );
                        if ( '' !== trim( $joined ) ) $fields[ $field_key ] = trim( $joined );
                    }
                }
                $this->extract_flamingo_fields( $item, $fields );
            } elseif ( is_string( $key ) && is_scalar( $item ) ) {
                $field_key = $this->flamingo_field_key( $key );
                if ( $field_key && ! in_array( $field_key, array( 'name', 'key', 'field-name', 'field', 'tag', 'value', 'values', 'data' ), true ) && '' !== trim( (string) $item ) ) {
                    $fields[ $field_key ] = trim( (string) $item );
                }
            }
        }
    }

    private function flamingo_is_placeholder( $value ) {
        return (bool) preg_match( '/^\s*\[[A-Za-z0-9_-]+\]\s*$/', (string) $value );
    }

    private function flamingo_channel_tokens( $post_id ) {
        $tokens = array();
        foreach ( array( 'flamingo_inbound_channel', 'flamingo_channel' ) as $taxonomy ) {
            if ( ! taxonomy_exists( $taxonomy ) ) continue;
            $terms = wp_get_post_terms( $post_id, $taxonomy );
            if ( is_wp_error( $terms ) ) continue;
            foreach ( $terms as $term ) {
                $tokens[] = (string) $term->name;
                $tokens[] = (string) $term->slug;
                $tokens[] = (string) $term->description;
            }
        }
        return array_values( array_unique( array_filter( $tokens ) ) );
    }

    private function flamingo_record_matches_form( $record, $post, $form_id ) {
        $form_id = absint( $form_id );
        if ( ! $form_id ) return false;
        if ( (string) ( $record['form_id'] ?? '' ) === (string) $form_id ) return true;

        $form = get_post( $form_id );
        if ( ! $form || 'wpcf7_contact_form' !== $form->post_type ) return false;
        $title = trim( wp_strip_all_tags( get_the_title( $form ) ) );
        $tokens = $this->flamingo_channel_tokens( $post->ID );
        foreach ( $tokens as $token ) {
            if ( preg_match( '/(?:^|[^0-9])' . preg_quote( (string) $form_id, '/' ) . '(?:[^0-9]|$)/', $token ) ) return true;
            if ( $title && 0 === strcasecmp( trim( wp_strip_all_tags( $token ) ), $title ) ) return true;
        }

        // Some Flamingo releases store the CF7 form title as the inbound channel only.
        $channel = trim( (string) ( $record['channel'] ?? '' ) );
        return $title && $channel && 0 === strcasecmp( $channel, $title );
    }

    private function attribution_label_from_host( $host ) {
        $host = strtolower( (string) $host );
        foreach ( array( 'facebook'=>'Facebook', 'fb.com'=>'Facebook', 'google'=>'Google', 'tiktok'=>'TikTok', 'instagram'=>'Instagram', 'zalo'=>'Zalo', 'youtube'=>'YouTube', 'bing'=>'Bing' ) as $needle=>$label ) {
            if ( false !== strpos( $host, $needle ) ) return $label;
        }
        return $host ? 'Website giới thiệu' : '';
    }

    private function flamingo_record( $post, $mapping = array() ) {
        $meta = get_post_meta( $post->ID );
        $flat = array();
        $fields = array();
        foreach ( $meta as $key => $values ) {
            $value = maybe_unserialize( $values[0] ?? '' );
            if ( is_array( $value ) ) {
                $this->flatten_flamingo_meta( $value, $flat );
                $this->extract_flamingo_fields( $value, $fields );
                $scalar_values = array_filter( $value, 'is_scalar' );
                if ( count( $scalar_values ) === count( $value ) && ! empty( $scalar_values ) ) {
                    $flat[ $key ] = implode( ', ', array_map( 'strval', $scalar_values ) );
                }
            } else {
                $flat[ $key ] = $value;
            }
        }
        // Explicit form fields must win over generic flattened metadata.
        $flat = array_merge( $flat, $fields );
        $raw_form_id = $this->flamingo_value( $flat, array( '_form_id', 'form_id', '_contact_form_id', 'contact_form_id', 'contact_form' ) );
        $form_id = preg_match( '/\d+/', (string) $raw_form_id, $form_match ) ? (string) absint( $form_match[0] ) : '';
        $channels = $this->flamingo_channel_tokens( $post->ID );
        $url = $this->flamingo_value_flexible( $flat, array( '_url', 'url', '_post_url', 'registration_url', 'vww_landing_page', 'landing_page' ) );
        $ref = $this->flamingo_value_flexible( $flat, array( '_referrer', 'referrer', 'referer', 'referrer_url', 'vww_first_referrer', 'first_referrer' ) );
        $utm_source = $this->flamingo_value_flexible( $flat, array( 'vww_utm_source', 'utm_source' ) );
        if ( ! $utm_source && $url ) {
            $query = (string) wp_parse_url( $url, PHP_URL_QUERY );
            parse_str( $query, $query_args );
            $utm_source = sanitize_text_field( (string) ( $query_args['utm_source'] ?? '' ) );
        }
        $raw_source = $this->flamingo_value_flexible( $flat, array( 'vww_first_source', 'first_source', 'traffic_source', 'your-source', 'your_source', 'source' ) );
        $host = $ref ? (string) wp_parse_url( $ref, PHP_URL_HOST ) : '';
        $attribution = $utm_source ?: $raw_source;
        if ( ! $attribution ) $attribution = $this->attribution_label_from_host( $host );
        if ( ! $attribution ) $attribution = 'Chưa ghi nhận';
        $field = function( $target, $fallbacks ) use ( $flat, $mapping ) {
            $custom = sanitize_key( (string) ( $mapping[ $target ] ?? '' ) );
            $value = $this->flamingo_value_flexible( $flat, $custom ? array_merge( array( $custom ), $fallbacks ) : $fallbacks );
            return $this->flamingo_is_placeholder( $value ) ? '' : $value;
        };
        $full_name = $field( 'full_name', array( 'your-name', 'your_name', 'full_name', 'name', 'ho-ten', 'hoten', '_from_name', 'from_name' ) );
        $post_title = trim( (string) $post->post_title );
        if ( ! $full_name && ! $this->flamingo_is_placeholder( $post_title ) ) $full_name = $post_title;
        return array(
            'post_id' => (int) $post->ID,
            'form_id' => $form_id,
            'channel' => (string) ( $channels[0] ?? '' ),
            'full_name' => $full_name,
            'email' => $field( 'email', array( 'your-email', 'your_email', 'email', 'email-address', '_from_email', 'from_email' ) ),
            'phone' => $field( 'phone', array( 'your-phone', 'your_phone', 'your-tel', 'your_tel', 'phone', 'phone-number', 'telephone', 'mobile', 'tel', 'so-dien-thoai', 'so_dien_thoai', 'sdt' ) ),
            'wedding_date' => $field( 'wedding_date', array( 'wedding-date', 'wedding_date', 'ngay-cuoi' ) ),
            'customer_role' => $field( 'customer_role', array( 'your-role', 'customer_role', 'role', 'vai-tro' ) ),
            'interest' => $field( 'interest', array( 'your-interest', 'event-content', 'interest', 'noi-dung-su-kien' ) ),
            'registration_url' => $url,
            'referrer_url' => $ref,
            'landing_page' => $this->flamingo_value( $flat, array( 'vww_landing_page', 'landing_page' ) ) ?: $url,
            'first_referrer' => $this->flamingo_value( $flat, array( 'vww_first_referrer', 'first_referrer' ) ) ?: $ref,
            'referrer_domain' => $host,
            'attribution_source' => $attribution,
            'attribution_type' => $utm_source ? 'campaign' : ( $ref ? 'referral' : 'unknown' ),
            'utm_source' => $utm_source,
            'utm_medium' => $this->flamingo_value( $flat, array( 'vww_utm_medium', 'utm_medium' ) ),
            'utm_campaign' => $this->flamingo_value( $flat, array( 'vww_utm_campaign', 'utm_campaign' ) ),
            'utm_content' => $this->flamingo_value( $flat, array( 'vww_utm_content', 'utm_content' ) ),
            'utm_term' => $this->flamingo_value( $flat, array( 'vww_utm_term', 'utm_term' ) ),
            'visitor_ip' => $this->flamingo_value( $flat, array( '_remote_ip', 'remote_ip', 'ip' ) ),
            'user_agent' => $this->flamingo_value( $flat, array( '_user_agent', 'user_agent' ) ),
            'source_page_title' => $this->flamingo_value( $flat, array( '_post_title', 'post_title', 'page_title' ) ),
            'created_at' => $post->post_date,
            'source_raw' => $flat,
        );
    }

    private function flamingo_query( $from, $to, $limit = 5000 ) {
        $args = array( 'post_type'=>'flamingo_inbound', 'post_status'=>'any', 'posts_per_page'=>min( 5000, absint( $limit ) ), 'orderby'=>'date', 'order'=>'ASC' );
        if ( $from || $to ) {
            $range = array( 'inclusive'=>true, 'column'=>'post_date' );
            if ( $from ) $range['after'] = $from;
            if ( $to ) $range['before'] = $to;
            $args['date_query'] = array( $range );
        }
        return get_posts( $args );
    }

    private function flamingo_forms() {
        if ( ! post_type_exists( 'wpcf7_contact_form' ) ) return array();
        return get_posts( array( 'post_type'=>'wpcf7_contact_form', 'post_status'=>'any', 'posts_per_page'=>-1, 'orderby'=>'title', 'order'=>'ASC' ) );
    }

    private function flamingo_mapping( $input ) {
        $defaults = array( 'full_name'=>'your-name', 'email'=>'your-email', 'phone'=>'your-phone', 'wedding_date'=>'wedding-date', 'customer_role'=>'your-role', 'interest'=>'your-interest' );
        $result = array();
        foreach ( $defaults as $key=>$default ) $result[ $key ] = sanitize_key( (string) ( $input[ $key ] ?? $default ) );
        return $result;
    }

    private function flamingo_phone_key( $phone ) {
        $digits = preg_replace( '/\D+/', '', (string) $phone );
        if ( 0 === strpos( $digits, '84' ) ) $digits = '0' . substr( $digits, 2 );
        return $digits;
    }

    private function flamingo_row_state( $record ) {
        global $wpdb;
        if ( empty( $record['full_name'] ) ) return array( 'invalid', 'Thiếu họ tên' );
        if ( ! is_email( $record['email'] ) ) return array( 'invalid', 'Email thiếu hoặc không hợp lệ' );
        $external = 'flamingo:' . absint( $record['post_id'] );
        if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE external_id=%s AND source='flamingo' LIMIT 1", $external ) ) ) return array( 'duplicate', 'Đã nhập bản ghi Flamingo này' );
        $email = $this->normalize_email( $record['email'] );
        if ( $email && $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE normalized_email=%s LIMIT 1", $email ) ) ) return array( 'duplicate', 'Trùng email với vé hiện có' );
        $phone = $this->flamingo_phone_key( $record['phone'] );
        if ( $phone ) {
            $phones = $wpdb->get_col( "SELECT normalized_phone FROM {$this->table()} WHERE normalized_phone<>''" );
            foreach ( $phones as $existing ) if ( $phone === $this->flamingo_phone_key( $existing ) ) return array( 'duplicate', 'Trùng số điện thoại với vé hiện có' );
        }
        return array( 'valid', 'Có thể tạo mới' );
    }

    public function admin_flamingo() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Không có quyền.' );
        $this->admin_head( 'Đồng bộ dữ liệu từ Flamingo' );
        if ( ! post_type_exists( 'flamingo_inbound' ) ) {
            echo '<div class="notice notice-warning"><p>Chưa phát hiện plugin Flamingo đang hoạt động. Hãy kích hoạt Flamingo trước khi đồng bộ.</p></div></div>';
            return;
        }
        $forms = $this->flamingo_forms();
        if ( empty( $forms ) ) {
            echo '<div class="notice notice-error"><p>Không tìm thấy Contact Form 7 nào để chọn.</p></div></div>';
            return;
        }
        $preview = get_transient( 'vww_flamingo_preview_' . get_current_user_id() );
        if ( isset( $_GET['created'] ) ) {
            echo '<div class="notice notice-success"><p>Import Flamingo hoàn tất: tạo mới <strong>' . absint( $_GET['created'] ) . '</strong>; bỏ qua trùng <strong>' . absint( $_GET['duplicate'] ?? 0 ) . '</strong>; không hợp lệ <strong>' . absint( $_GET['invalid'] ?? 0 ) . '</strong>; lỗi <strong>' . absint( $_GET['errors'] ?? 0 ) . '</strong>. Không có email nào được tự động gửi.</p></div>';
        }
        $selected_form = (string) ( $preview['form_id'] ?? get_user_meta( get_current_user_id(), 'vww_flamingo_last_form', true ) );
        if ( '' === $selected_form ) $selected_form = (string) $this->configured_cf7_form_id();
        $mapping = $preview['mapping'] ?? $this->flamingo_mapping( array() );
        echo '<section class="vww-panel"><h2>Chọn dữ liệu cần đồng bộ</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_flamingo_preview">';
        wp_nonce_field( 'vww_flamingo_preview', 'vww_nonce' );
        echo '<p class="vww-note"><strong>Múi giờ website:</strong> ' . esc_html( $this->site_timezone_label() ) . '. Khoảng thời gian bên dưới và thời gian đăng ký gốc từ Flamingo đều được hiểu theo múi giờ này.</p>';
        echo '<div class="vww-form-grid"><label>Form Contact Form 7 cần import<select name="form_id" required><option value="">— Chọn một form —</option>';
        foreach ( $forms as $form ) echo '<option value="' . absint( $form->ID ) . '" ' . selected( $selected_form, (string) $form->ID, false ) . '>' . esc_html( get_the_title( $form ) . ' — ID: ' . $form->ID ) . '</option>';
        echo '</select></label><label>Từ ngày/giờ<input type="datetime-local" name="from" value="' . esc_attr( $preview['from_input'] ?? '' ) . '" required></label><label>Đến ngày/giờ<input type="datetime-local" name="to" value="' . esc_attr( $preview['to_input'] ?? '' ) . '" required></label></div>';
        echo '<details><summary><strong>Mapping trường Flamingo</strong></summary><div class="vww-form-grid">';
        foreach ( array( 'full_name'=>'Họ tên', 'email'=>'Email', 'phone'=>'Điện thoại', 'wedding_date'=>'Ngày cưới', 'customer_role'=>'Vai trò', 'interest'=>'Nội dung sự kiện' ) as $key=>$label ) echo '<label>' . esc_html( $label ) . '<input name="mapping[' . esc_attr( $key ) . ']" value="' . esc_attr( $mapping[ $key ] ) . '"></label>';
        echo '</div><p class="description">Plugin ưu tiên trường đã mapping và vẫn tự dò các tên trường phổ biến khi trường đó trống.</p></details><p><button class="button button-primary">Kiểm tra dữ liệu</button></p></form></section>';
        if ( is_array( $preview ) ) {
            echo '<section class="vww-panel"><h2>Kết quả kiểm tra</h2><p>Đã quét <strong>' . absint( $preview['scanned'] ?? $preview['total'] ) . '</strong> bản ghi trong khoảng thời gian; khớp Form đã chọn <strong>' . absint( $preview['total'] ) . '</strong>; tạo mới <strong>' . absint( $preview['valid'] ) . '</strong>; trùng <strong>' . absint( $preview['duplicate'] ) . '</strong>; không hợp lệ <strong>' . absint( $preview['invalid'] ) . '</strong>.</p>';
            if ( empty( $preview['total'] ) && ! empty( $preview['scanned'] ) ) {
                echo '<div class="notice notice-warning inline"><p>Flamingo có dữ liệu trong khoảng thời gian nhưng không nhận diện được bản ghi thuộc Form đã chọn. Hãy kiểm tra lại Form nguồn; nếu đúng Form, mở một bản ghi Flamingo và đối chiếu tên Channel với tên Contact Form 7.</p></div>';
            } elseif ( empty( $preview['scanned'] ) ) {
                echo '<div class="notice notice-info inline"><p>Không có bản ghi Flamingo nào trong khoảng thời gian đã chọn. Hãy mở rộng mốc Từ ngày/giờ và Đến ngày/giờ.</p></div>';
            }
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_flamingo_commit">'; wp_nonce_field( 'vww_flamingo_commit', 'vww_nonce' );
            if ( ! empty( $preview['rows'] ) ) {
                echo '<div class="vww-table-wrap"><table class="widefat striped"><thead><tr><th><input type="checkbox" checked onclick="var checked=this.checked;document.querySelectorAll(\'.vww-flamingo-row\').forEach(function(x){x.checked=checked})"></th><th>Thời gian đăng ký</th><th>Họ tên</th><th>Email</th><th>SĐT</th><th>Nguồn</th><th>Kết quả</th></tr></thead><tbody>';
                foreach ( $preview['rows'] as $r ) { $ok = 'valid' === $r['_state']; echo '<tr><td>' . ( $ok ? '<input class="vww-flamingo-row" type="checkbox" name="record_ids[]" value="' . absint( $r['post_id'] ) . '" checked>' : '—' ) . '</td><td>' . esc_html( $this->format_site_datetime( $r['created_at'], 'd/m/Y H:i', '—' ) ) . '</td><td>' . esc_html( $r['full_name'] ) . '</td><td>' . esc_html( $r['email'] ) . '</td><td>' . esc_html( $r['phone'] ) . '</td><td>' . esc_html( $r['attribution_source'] ) . '</td><td><strong>' . esc_html( $r['_reason'] ) . '</strong></td></tr>'; }
                echo '</tbody></table></div>';
            }
            echo '<p><button class="button button-primary button-hero" onclick="return confirm(\'Import các bản ghi đã chọn? Vé sẽ ở trạng thái Đăng ký và không tự gửi email.\')">Import bản ghi đã chọn</button></p></form></section>';
        }
        echo '</div>';
    }

    public function handle_flamingo_preview() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_flamingo_preview', 'vww_nonce' ) ) wp_die( 'Không có quyền.' );
        $from = sanitize_text_field( wp_unslash( $_POST['from'] ?? '' ) ); $to = sanitize_text_field( wp_unslash( $_POST['to'] ?? '' ) ); $form_id = absint( $_POST['form_id'] ?? 0 );
        $valid_forms = wp_list_pluck( $this->flamingo_forms(), 'ID' );
        if ( ! $form_id || ! in_array( $form_id, array_map( 'intval', $valid_forms ), true ) ) wp_die( 'Form Contact Form 7 không hợp lệ.' );
        $mapping = $this->flamingo_mapping( (array) ( $_POST['mapping'] ?? array() ) );
        $from_mysql = str_replace( 'T', ' ', $from ) . ( 16 === strlen( $from ) ? ':00' : '' ); $to_mysql = str_replace( 'T', ' ', $to ) . ( 16 === strlen( $to ) ? ':59' : '' );
        $from_date = $this->site_datetime( $from_mysql ); $to_date = $this->site_datetime( $to_mysql );
        if ( ! $from_date || ! $to_date || $from_date > $to_date ) wp_die( 'Khoảng thời gian không hợp lệ.' );
        $summary = array( 'from'=>$from_mysql, 'to'=>$to_mysql, 'from_input'=>$from, 'to_input'=>$to, 'form_id'=>$form_id, 'mapping'=>$mapping, 'scanned'=>0, 'unmatched'=>0, 'total'=>0, 'valid'=>0, 'duplicate'=>0, 'invalid'=>0, 'rows'=>array() );
        foreach ( $this->flamingo_query( $from_mysql, $to_mysql ) as $post ) {
            $summary['scanned']++;
            $r = $this->flamingo_record( $post, $mapping );
            if ( ! $this->flamingo_record_matches_form( $r, $post, $form_id ) ) { $summary['unmatched']++; continue; }
            $r['form_id'] = (string) $form_id; $summary['total']++;
            list( $state, $reason ) = $this->flamingo_row_state( $r ); $summary[ $state ]++; $r['_state']=$state; $r['_reason']=$reason; $summary['rows'][]=$r;
        }
        update_user_meta( get_current_user_id(), 'vww_flamingo_last_form', $form_id );
        set_transient( 'vww_flamingo_preview_' . get_current_user_id(), $summary, HOUR_IN_SECONDS );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-flamingo' ) ); exit;
    }

    public function handle_flamingo_commit() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_flamingo_commit', 'vww_nonce' ) ) wp_die( 'Không có quyền.' );
        $preview = get_transient( 'vww_flamingo_preview_' . get_current_user_id() ); if ( ! is_array( $preview ) ) wp_die( 'Phiên xem trước đã hết hạn.' );
        $form_id = absint( $preview['form_id'] ?? 0 );
        if ( ! $form_id || ! in_array( $form_id, array_map( 'intval', wp_list_pluck( $this->flamingo_forms(), 'ID' ) ), true ) ) wp_die( 'Form không còn tồn tại. Hãy kiểm tra lại.' );
        $selected = array_values( array_unique( array_map( 'absint', (array) ( $_POST['record_ids'] ?? array() ) ) ) );
        if ( empty( $selected ) ) wp_die( 'Bạn chưa chọn bản ghi hợp lệ nào.' );
        global $wpdb; $created = $duplicate = $invalid = $errors = 0;
        foreach ( $selected as $post_id ) {
            $post = get_post( $post_id ); if ( ! $post || 'flamingo_inbound' !== $post->post_type ) { $invalid++; continue; }
            $r = $this->flamingo_record( $post, $preview['mapping'] ?? array() );
            if ( ! $this->flamingo_record_matches_form( $r, $post, $form_id ) || $r['created_at'] < $preview['from'] || $r['created_at'] > $preview['to'] ) { $invalid++; continue; }
            $r['form_id'] = (string) $form_id;
            list( $state ) = $this->flamingo_row_state( $r ); if ( 'valid' !== $state ) { 'duplicate' === $state ? $duplicate++ : $invalid++; continue; }
            $external = 'flamingo:' . $r['post_id'];
            if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE external_id=%s AND source='flamingo'", $external ) ) ) { $duplicate++; continue; }
            if ( ! $r['full_name'] || ! is_email( $r['email'] ) ) { $invalid++; continue; }
            $r['external_id'] = $external; $r['source'] = 'flamingo'; $r['source_form_id'] = $r['form_id']; $r['status'] = 'registered'; $r['attributed_at'] = $r['created_at'];
            $ticket = $this->create_ticket( $r, false ); if ( is_wp_error( $ticket ) ) { 'vww_duplicate' === $ticket->get_error_code() ? $duplicate++ : $errors++; } else { $created++; }
        }
        delete_transient( 'vww_flamingo_preview_' . get_current_user_id() );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-flamingo&created=' . $created . '&duplicate=' . $duplicate . '&invalid=' . $invalid . '&errors=' . $errors ) ); exit;
    }

    public function admin_import() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $template_url = wp_nonce_url( admin_url( 'admin-post.php?action=vww_im_download_template' ), 'vww_download_template' );
        $this->admin_head( 'Import vé mời từ Excel', '<a class="button button-primary" href="' . esc_url( $template_url ) . '">↓ Tải file Excel mẫu (.xlsx)</a>' );
        if ( isset( $_GET['vww_notice'] ) ) {
            $notice = sanitize_key( wp_unslash( $_GET['vww_notice'] ) );
            if ( 'imported' === $notice ) {
                echo '<div class="notice notice-success"><p>Đã hoàn tất import. Các vé mới đang ở trạng thái “Đăng ký, chưa gửi vé” và chưa tự gửi email.</p></div>';
            } elseif ( 'error' === $notice ) {
                echo '<div class="notice notice-error"><p>Không thể xử lý file. Hãy kiểm tra định dạng và thử lại.</p></div>';
            }
        }
        echo '<div class="vww-import-layout"><section class="vww-import-card"><small>BƯỚC 1</small><h2>Chọn file dữ liệu</h2>'
            . '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_import_preview">' . wp_nonce_field( 'vww_import_preview', 'vww_nonce', true, false )
            . '<input type="file" name="import_file" accept=".xlsx,.csv" required><p>Hỗ trợ `.xlsx` và `.csv`, tối đa 10.000 dòng. Mặc định plugin chỉ thêm mới và không gửi email.</p>'
            . '<button class="button button-primary">Đọc file & Xem trước</button></form></section>';

        $state = get_transient( $this->import_transient_key() );
        if ( is_array( $state ) && ! empty( $state['headers'] ) ) {
            echo '<section class="vww-import-card"><small>BƯỚC 2</small><h2>Ghép cột dữ liệu</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_import_map">' . wp_nonce_field( 'vww_import_map', 'vww_nonce', true, false )
                . '<div class="vww-mapping-grid">';
            foreach ( $this->import_fields() as $field => $label ) {
                echo '<label><span>' . esc_html( $label ) . '</span><select name="mapping[' . esc_attr( $field ) . ']"><option value="">— Không dùng —</option>';
                foreach ( $state['headers'] as $index => $header ) {
                    echo '<option value="' . absint( $index ) . '" ' . selected( (string) ( $state['mapping'][ $field ] ?? '' ), (string) $index, false ) . '>' . esc_html( $header ) . '</option>';
                }
                echo '</select></label>';
            }
            echo '</div><label class="vww-import-mode"><span>Chế độ xử lý</span><select name="mode"><option value="add_only" ' . selected( $state['mode'], 'add_only', false ) . '>Chỉ thêm vé mới (khuyến nghị)</option><option value="update" ' . selected( $state['mode'], 'update', false ) . '>Thêm mới + cập nhật trường an toàn</option></select></label><button class="button">Phân tích lại dữ liệu</button></form></section>';
            if ( isset( $state['analysis'] ) ) {
                $c = $state['counts'];
                echo '<section class="vww-import-card vww-import-preview"><small>BƯỚC 3</small><h2>Xác nhận import</h2><div class="vww-import-summary">'
                    . '<span class="create">Tạo mới <b>' . absint( $c['create'] ) . '</b></span><span class="update">Cập nhật <b>' . absint( $c['update'] ) . '</b></span><span>Không đổi <b>' . absint( $c['unchanged'] ) . '</b></span><span class="conflict">Xung đột <b>' . absint( $c['conflict'] ) . '</b></span><span class="error">Lỗi <b>' . absint( $c['error'] ) . '</b></span></div>'
                    . '<div class="vww-import-table"><table class="widefat striped"><thead><tr><th>Dòng</th><th>Kết quả</th><th>Khách</th><th>Email</th><th>Ghi chú</th></tr></thead><tbody>';
                foreach ( array_slice( $state['analysis'], 0, 100 ) as $item ) {
                    echo '<tr><td>' . absint( $item['row_number'] ) . '</td><td><span class="vww-import-action ' . esc_attr( $item['action'] ) . '">' . esc_html( strtoupper( $item['action'] ) ) . '</span></td><td>' . esc_html( $item['data']['full_name'] ) . '</td><td>' . esc_html( $item['data']['email'] ) . '</td><td>' . esc_html( $item['message'] ) . '</td></tr>';
                }
                echo '</tbody></table></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="vww_im_import_commit">' . wp_nonce_field( 'vww_import_commit', 'vww_nonce', true, false )
                    . '<button class="button button-primary button-large" ' . disabled( 0 === $c['create'] + $c['update'], true, false ) . '>Import ' . absint( $c['create'] + $c['update'] ) . ' vé</button></form></section>';
            }
        }
        echo '</div>';
        $this->render_import_history();
        echo '</div>';
    }

    private function render_import_history() {
        global $wpdb;
        $batches = $wpdb->get_results( "SELECT * FROM {$this->batches()} ORDER BY id DESC LIMIT 20" );
        echo '<section class="vww-import-card vww-import-history"><small>LỊCH SỬ</small><h2>Các đợt import gần đây</h2><table class="widefat striped"><thead><tr><th>Mã đợt</th><th>File</th><th>Kết quả</th><th>Thời gian</th><th></th></tr></thead><tbody>';
        if ( ! $batches ) {
            echo '<tr><td colspan="5">Chưa có đợt import.</td></tr>';
        }
        foreach ( $batches as $batch ) {
            $error_url = wp_nonce_url( admin_url( 'admin-post.php?action=vww_im_import_errors&batch_id=' . $batch->id ), 'vww_import_errors_' . $batch->id );
            echo '<tr><td><strong>' . esc_html( $batch->batch_code ) . '</strong></td><td>' . esc_html( $batch->file_name ) . '</td><td>+' . absint( $batch->created_count ) . ' / ↻' . absint( $batch->updated_count ) . ' / lỗi ' . absint( $batch->error_count + $batch->conflict_count ) . '</td><td>' . esc_html( $this->format_site_datetime( $batch->created_at, 'H:i d/m/Y', '—' ) ) . '</td><td>' . ( $batch->error_count + $batch->conflict_count ? '<a href="' . esc_url( $error_url ) . '">Tải dòng lỗi</a>' : '—' ) . '</td></tr>';
        }
        echo '</tbody></table></section>';
    }

    public function handle_manual_ticket() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_create_ticket', 'vww_nonce' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $ticket = $this->create_ticket( wp_unslash( $_POST ), true );
        $url    = admin_url( 'admin.php?page=vww-create-ticket' );
        wp_safe_redirect( add_query_arg( 'vww_notice', is_wp_error( $ticket ) ? $ticket->get_error_code() : 'created', $url ) );
        exit;
    }

    public function handle_update_ticket() {
        $id = absint( $_POST['id'] ?? 0 );
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_update_ticket_' . $id, 'vww_nonce' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $ticket = $this->get_ticket( $id );
        if ( ! $ticket ) {
            wp_die( 'Không tìm thấy vé.' );
        }
        global $wpdb;
        $data = array();
        foreach ( array( 'full_name','phone','email','wedding_date','customer_role','interest','event_name','external_id','source','registration_url','referrer_url' ) as $key ) {
            $value = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
            $data[ $key ] = in_array( $key, array( 'registration_url', 'referrer_url' ), true ) ? esc_url_raw( $value ) : sanitize_text_field( $value );
        }
        $data['email']            = $this->normalize_email( $data['email'] );
        $data['normalized_email'] = $data['email'];
        $data['normalized_phone'] = $this->normalize_phone( $data['phone'] );
        $data['dedupe_key']       = $this->dedupe_key( $data['email'], $data['event_name'] );
        $data['source']           = sanitize_key( $data['source'] ) ?: 'admin';
        $data['wedding_date']     = $data['wedding_date'] ?: null;
        $data['updated_at']       = current_time( 'mysql' );
        $updated = $wpdb->update( $this->table(), $data, array( 'id' => $id ) );
        if ( false === $updated && false !== stripos( (string) $wpdb->last_error, 'duplicate' ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-edit-ticket&id=' . $id . '&vww_notice=duplicate' ) );
            exit;
        }
        $this->log( $id, 'updated', 'Cập nhật thông tin vé trong admin.' );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-edit-ticket&id=' . $id . '&vww_notice=updated' ) );
        exit;
    }

    public function handle_import_preview() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_import_preview', 'vww_nonce' ) ) {
            wp_die( 'Không có quyền.' );
        }
        if ( empty( $_FILES['import_file']['tmp_name'] ) || UPLOAD_ERR_OK !== (int) $_FILES['import_file']['error'] ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=error' ) );
            exit;
        }
        $name      = sanitize_file_name( wp_unslash( $_FILES['import_file']['name'] ) );
        $extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
        if ( ! in_array( $extension, array( 'xlsx', 'csv' ), true ) || (int) $_FILES['import_file']['size'] > 10 * MB_IN_BYTES ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=error' ) );
            exit;
        }
        $path = $_FILES['import_file']['tmp_name'];
        $rows = 'xlsx' === $extension ? VWW_XLSX::read( $path, 10001 ) : $this->read_csv( $path, 10001 );
        if ( is_wp_error( $rows ) || count( $rows ) < 2 ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=error' ) );
            exit;
        }
        $state = array(
            'file_name' => $name,
            'headers'   => array_map( 'sanitize_text_field', $rows[0] ),
            'rows'      => $rows,
            'mapping'   => $this->suggest_mapping( $rows[0] ),
            'mode'      => 'add_only',
        );
        $state = $this->analyze_import_state( $state );
        set_transient( $this->import_transient_key(), $state, 30 * MINUTE_IN_SECONDS );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-import' ) );
        exit;
    }

    public function handle_import_map() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_import_map', 'vww_nonce' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $state = get_transient( $this->import_transient_key() );
        if ( ! is_array( $state ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=error' ) );
            exit;
        }
        $mapping = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] ) ? wp_unslash( $_POST['mapping'] ) : array();
        foreach ( $this->import_fields() as $field => $label ) {
            $state['mapping'][ $field ] = isset( $mapping[ $field ] ) && '' !== (string) $mapping[ $field ] ? (string) absint( $mapping[ $field ] ) : '';
        }
        $state['mode'] = isset( $_POST['mode'] ) && 'update' === sanitize_key( wp_unslash( $_POST['mode'] ) ) ? 'update' : 'add_only';
        $state = $this->analyze_import_state( $state );
        set_transient( $this->import_transient_key(), $state, 30 * MINUTE_IN_SECONDS );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-import' ) );
        exit;
    }

    private function insert_import_row( $batch_id, $item, $ticket_id = 0 ) {
        global $wpdb;
        $wpdb->insert(
            $this->import_rows(),
            array(
                'batch_id'   => $batch_id,
                'row_number' => $item['row_number'],
                'ticket_id'  => $ticket_id ?: null,
                'action'     => $item['action'],
                'message'    => $item['message'],
                'row_data'   => wp_json_encode( $item['data'], JSON_UNESCAPED_UNICODE ),
                'created_at' => current_time( 'mysql' ),
            )
        );
    }

    public function handle_import_commit() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_import_commit', 'vww_nonce' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $state = get_transient( $this->import_transient_key() );
        if ( ! is_array( $state ) || empty( $state['analysis'] ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=error' ) );
            exit;
        }
        global $wpdb;
        $batch_code = 'IMP-' . wp_date( 'ymd-His' ) . '-' . strtoupper( wp_generate_password( 4, false, false ) );
        $wpdb->insert(
            $this->batches(),
            array(
                'batch_code' => $batch_code,
                'file_name'  => $state['file_name'],
                'mode'       => $state['mode'],
                'total_rows' => count( $state['analysis'] ),
                'user_id'    => get_current_user_id(),
                'status'     => 'processing',
                'created_at' => current_time( 'mysql' ),
            )
        );
        $batch_id = (int) $wpdb->insert_id;
        $counts   = array( 'created_count'=>0, 'updated_count'=>0, 'unchanged_count'=>0, 'conflict_count'=>0, 'error_count'=>0 );
        foreach ( $state['analysis'] as $item ) {
            $ticket_id = (int) $item['ticket_id'];
            if ( 'create' === $item['action'] ) {
                $data = $item['data'];
                unset( $data['ticket_code'] );
                $data['status']          = 'registered';
                $data['import_batch_id'] = $batch_id;
                $ticket = $this->create_ticket( $data, false );
                if ( is_wp_error( $ticket ) ) {
                    $item['action']  = 'error';
                    $item['message'] = $ticket->get_error_message();
                    $counts['error_count']++;
                } else {
                    $ticket_id = (int) $ticket->id;
                    $counts['created_count']++;
                    $this->log( $ticket_id, 'import_created', $batch_code );
                }
            } elseif ( 'update' === $item['action'] ) {
                $ticket = $this->get_ticket( $ticket_id );
                if ( ! $ticket || ! empty( $ticket->trashed_at ) || 'cancelled' === $ticket->status ) {
                    $item['action']  = 'conflict';
                    $item['message'] = 'Vé đã đổi trạng thái trong lúc import.';
                    $counts['conflict_count']++;
                } else {
                    $data = array();
                    foreach ( array( 'full_name','phone','email','wedding_date','customer_role','interest','event_name','source','external_id','registration_url','referrer_url' ) as $field ) {
                        if ( '' !== (string) $item['data'][ $field ] ) {
                            $data[ $field ] = $item['data'][ $field ];
                        }
                    }
                    $data['normalized_email'] = $this->normalize_email( $data['email'] ?? $ticket->email );
                    $data['normalized_phone'] = $this->normalize_phone( $data['phone'] ?? $ticket->phone );
                    $data['dedupe_key']       = $this->dedupe_key( $data['email'] ?? $ticket->email, $data['event_name'] ?? $ticket->event_name );
                    $data['import_batch_id']  = $batch_id;
                    $data['updated_at']       = current_time( 'mysql' );
                    $result = $wpdb->update( $this->table(), $data, array( 'id' => $ticket_id ) );
                    if ( false === $result ) {
                        $item['action']  = 'conflict';
                        $item['message'] = 'Không cập nhật được, có thể trùng email/sự kiện.';
                        $counts['conflict_count']++;
                    } else {
                        $counts['updated_count']++;
                        $this->log( $ticket_id, 'import_updated', $batch_code );
                    }
                }
            } elseif ( 'unchanged' === $item['action'] ) {
                $counts['unchanged_count']++;
            } elseif ( 'conflict' === $item['action'] ) {
                $counts['conflict_count']++;
            } else {
                $counts['error_count']++;
            }
            $this->insert_import_row( $batch_id, $item, $ticket_id );
        }
        $counts['status']       = 'completed';
        $counts['completed_at'] = current_time( 'mysql' );
        $wpdb->update( $this->batches(), $counts, array( 'id' => $batch_id ) );
        delete_transient( $this->import_transient_key() );
        wp_safe_redirect( admin_url( 'admin.php?page=vww-import&vww_notice=imported&batch=' . rawurlencode( $batch_code ) ) );
        exit;
    }

    public function handle_import_errors() {
        $batch_id = absint( $_GET['batch_id'] ?? 0 );
        if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'vww_import_errors_' . $batch_id ) ) {
            wp_die( 'Không có quyền.' );
        }
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->import_rows()} WHERE batch_id=%d AND action IN ('error','conflict') ORDER BY row_number", $batch_id ) );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=vww-import-errors-' . $batch_id . '.csv' );
        $out = fopen( 'php://output', 'w' );
        fwrite( $out, "\xEF\xBB\xBF" );
        fputcsv( $out, array( 'Dòng', 'Kết quả', 'Thông báo', 'Dữ liệu' ) );
        foreach ( $rows as $row ) {
            fputcsv( $out, $this->csv_safe_row( array( $row->row_number, $row->action, $row->message, $row->row_data ) ) );
        }
        fclose( $out );
        exit;
    }

    public function handle_download_template() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_download_template' ) ) {
            wp_die( 'Không có quyền.' );
        }
        $path = VWW_IM_DIR . 'assets/templates/vww-import-template.xlsx';
        if ( ! file_exists( $path ) ) {
            wp_die( 'Không tìm thấy file mẫu. Vui lòng cài lại plugin.' );
        }
        nocache_headers();
        header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
        header( 'Content-Disposition: attachment; filename="vww-import-template.xlsx"' );
        header( 'Content-Length: ' . filesize( $path ) );
        readfile( $path );
        exit;
    }

    private function request_filters( $source ) {
        $source = is_array( $source ) ? $source : array();
        return array(
            'q'            => sanitize_text_field( $source['q'] ?? '' ),
            'status'       => sanitize_key( $source['status'] ?? '' ),
            'interest'     => sanitize_text_field( $source['interest'] ?? '' ),
            'event_name'   => sanitize_text_field( $source['event_name'] ?? '' ),
            'source'       => sanitize_text_field( $source['source'] ?? '' ),
            'registration_url' => esc_url_raw( $source['registration_url'] ?? '' ),
            'import_batch' => absint( $source['import_batch'] ?? 0 ),
            'date_type'    => sanitize_key( $source['date_type'] ?? 'created' ),
            'date_from'    => sanitize_text_field( $source['date_from'] ?? '' ),
            'date_to'      => sanitize_text_field( $source['date_to'] ?? '' ),
            'view'         => sanitize_key( $source['view'] ?? '' ),
        );
    }

    private function filter_sql( $filters, $alias = 't' ) {
        global $wpdb;
        $prefix = $alias ? $alias . '.' : '';
        $where  = array();
        $params = array();
        if ( 'trash' === $filters['view'] ) {
            $where[] = $prefix . 'trashed_at IS NOT NULL';
        } else {
            $where[] = $prefix . 'trashed_at IS NULL';
        }
        if ( $filters['q'] ) {
            $like = '%' . $wpdb->esc_like( $filters['q'] ) . '%';
            $where[] = '(' . $prefix . 'ticket_code LIKE %s OR ' . $prefix . 'full_name LIKE %s OR ' . $prefix . 'email LIKE %s OR ' . $prefix . 'phone LIKE %s)';
            array_push( $params, $like, $like, $like, $like );
        }
        if ( 'pending' === $filters['status'] ) {
            $where[] = $prefix . "status IN ('registered','issued')";
        } elseif ( in_array( $filters['status'], array( 'registered','issued','emailed','checked_in','cancelled' ), true ) ) {
            $where[]  = $prefix . 'status=%s';
            $params[] = $filters['status'];
        }
        foreach ( array( 'interest', 'event_name' ) as $field ) {
            if ( $filters[ $field ] ) {
                $where[]  = $prefix . $field . '=%s';
                $params[] = $filters[ $field ];
            }
        }
        if ( $filters['source'] ) {
            $where[]  = 'COALESCE(NULLIF(' . $prefix . "attribution_source,'')," . $prefix . 'source)=%s';
            $params[] = $filters['source'];
        }
        if ( $filters['registration_url'] ) {
            $where[]  = $prefix . 'registration_url=%s';
            $params[] = $filters['registration_url'];
        }
        if ( $filters['import_batch'] ) {
            $where[]  = $prefix . 'import_batch_id=%d';
            $params[] = $filters['import_batch'];
        }
        $date_columns = array( 'created'=>'created_at', 'emailed'=>'emailed_at', 'checked'=>'checked_in_at' );
        $date_column  = $date_columns[ $filters['date_type'] ] ?? 'created_at';
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $filters['date_from'] ) ) {
            $where[]  = $prefix . $date_column . ' >= %s';
            $params[] = $filters['date_from'] . ' 00:00:00';
        }
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $filters['date_to'] ) ) {
            $where[]  = $prefix . $date_column . ' <= %s';
            $params[] = $filters['date_to'] . ' 23:59:59';
        }
        return array( 'where'=>implode( ' AND ', $where ), 'params'=>$params );
    }

    private function export_rows( $filters, $ids = array() ) {
        global $wpdb;
        $parts = $this->filter_sql( $filters, 't' );
        $where = $parts['where'];
        $params= $parts['params'];
        $ids   = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
        if ( $ids ) {
            $ids = array_slice( $ids, 0, 5000 );
            $where .= ' AND t.id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
            $params = array_merge( $params, $ids );
        }
        $order = ( 'checked' === $filters['date_type'] && ( $filters['date_from'] || $filters['date_to'] ) ) ? 't.checked_in_at DESC, t.id DESC' : 't.id DESC';
        $sql = "SELECT t.ticket_code,t.external_id,t.full_name,t.phone,t.email,t.wedding_date,t.customer_role,t.interest AS event_content,t.event_name,t.source,t.attribution_source,t.attribution_type,t.landing_page,t.first_referrer,t.referrer_domain,t.utm_source,t.utm_medium,t.utm_campaign,t.utm_content,t.utm_term,t.attributed_at,t.registration_url,t.referrer_url,t.visitor_ip,t.user_agent,t.source_page_title,t.source_raw,t.status,t.created_at,t.emailed_at,t.checked_in_at,u.display_name AS checked_in_by,b.batch_code AS import_batch
            FROM {$this->table()} t
            LEFT JOIN {$wpdb->users} u ON u.ID=t.checked_in_by
            LEFT JOIN {$this->batches()} b ON b.id=t.import_batch_id
            WHERE $where ORDER BY $order";
        if ( $params ) {
            $sql = $wpdb->prepare( $sql, $params );
        }
        return $wpdb->get_results( $sql, ARRAY_A );
    }

    private function export_headers() {
        return array(
            'time', 'date', 'your-name', 'your-email', 'your-phone',
            'wedding-date', 'your-role', 'your-interest',
        );
    }

    private function synced_export_row( $row ) {
        $created = ! empty( $row['created_at'] ) ? $this->site_datetime( $row['created_at'] ) : false;
        return array(
            $created ? $created->format( 'H:i:s' ) : '',
            $created ? $created->format( 'Y-m-d' ) : '',
            $row['full_name'] ?? '',
            $row['email'] ?? '',
            $row['phone'] ?? '',
            $row['wedding_date'] ?? '',
            $row['customer_role'] ?? '',
            $row['event_content'] ?? '',
        );
    }

    private function csv_safe_row( $row ) {
        return array_map(
            function( $value ) {
                $value = (string) $value;
                return preg_match( '/^[=+\-@]/', $value ) ? "'" . $value : $value;
            },
            (array) $row
        );
    }

    private function export_request_data() {
        $filters = $this->request_filters( wp_unslash( $_GET ) );
        $ids     = array();
        if ( ! empty( $_GET['ids'] ) ) {
            $ids = explode( ',', sanitize_text_field( wp_unslash( $_GET['ids'] ) ) );
        }
        return array( $filters, $ids );
    }

    private function staff_export_field_map() {
        return array(
            'ticket_code'   => 'Mã vé',
            'full_name'     => 'Họ tên',
            'phone'         => 'Số điện thoại',
            'email'         => 'Email',
            'event_name'    => 'Sự kiện',
            'event_content' => 'Nội dung sự kiện',
            'customer_role' => 'Vai trò',
            'wedding_date'  => 'Ngày cưới dự kiến',
            'source'        => 'Nguồn',
            'status'        => 'Trạng thái vé',
            'created_at'    => 'Thời gian đăng ký',
            'emailed_at'    => 'Thời gian gửi vé',
            'checked_in_at' => 'Thời gian Check-in',
            'checked_in_by' => 'Nhân viên Check-in',
        );
    }

    private function staff_export_default_fields() {
        return array( 'ticket_code','full_name','phone','email','event_name','source','status','checked_in_at','checked_in_by' );
    }

    private function staff_export_fields( $source = array() ) {
        $map = $this->staff_export_field_map();
        $raw = $source['fields'] ?? array();
        if ( is_string( $raw ) ) {
            $raw = explode( ',', $raw );
        }
        $fields = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $raw ) ) ) );
        $fields = array_values( array_filter( $fields, function( $field ) use ( $map ) { return isset( $map[ $field ] ); } ) );
        return $fields ?: $this->staff_export_default_fields();
    }

    private function staff_export_headers( $fields = array() ) {
        $map = $this->staff_export_field_map();
        $fields = $fields ?: $this->staff_export_default_fields();
        return array_map( function( $field ) use ( $map ) { return $map[ $field ] ?? $field; }, $fields );
    }

    private function staff_export_value( $row, $field ) {
        if ( 'source' === $field ) {
            return ( $row['attribution_source'] ?? '' ) ?: ( $row['source'] ?? '' );
        }
        if ( 'status' === $field ) {
            return $this->status_label( $row['status'] ?? '' );
        }
        if ( in_array( $field, array( 'created_at','emailed_at','checked_in_at' ), true ) ) {
            return ! empty( $row[ $field ] ) ? $this->format_site_datetime( $row[ $field ], 'd/m/Y H:i' ) : '';
        }
        return $row[ $field ] ?? '';
    }

    private function staff_export_row( $row, $fields = array() ) {
        $fields = $fields ?: $this->staff_export_default_fields();
        $values = array();
        foreach ( $fields as $field ) {
            $values[] = $this->staff_export_value( $row, $field );
        }
        return $values;
    }

    private function staff_export_fail( $message, $status = 400 ) {
        status_header( absint( $status ) ?: 400 );
        wp_die( esc_html( (string) $message ) );
    }

    public function handle_staff_export_xlsx() {
        if ( ! is_user_logged_in() || ( ! current_user_can( 'vww_export_tickets' ) && ! current_user_can( 'manage_options' ) ) ) {
            $this->staff_export_fail( 'Không có quyền xuất danh sách.', 403 );
        }
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            $this->staff_export_fail( 'Yêu cầu xuất file không hợp lệ.', 405 );
        }
        $source = wp_unslash( $_POST );
        $nonce  = sanitize_text_field( $source['vww_staff_export_nonce'] ?? '' );
        if ( ! wp_verify_nonce( $nonce, 'vww_staff_export' ) ) {
            $this->staff_export_fail( 'Phiên xuất file đã hết hạn. Vui lòng tải lại Check-in Center.', 403 );
        }
        $filters = $this->request_filters( $source );
        $filters['view'] = '';
        $ids = array();
        if ( ! empty( $source['ids'] ) ) {
            $ids = array_values( array_unique( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( $source['ids'] ) ) ) ) ) );
        }
        $fields = $this->staff_export_fields( $source );
        $rows   = $this->export_rows( $filters, $ids );
        $data   = array( $this->staff_export_headers( $fields ) );
        foreach ( $rows as $row ) {
            $data[] = $this->staff_export_row( $row, $fields );
        }
        $path = wp_tempnam( 'vww-checkin.xlsx' );
        if ( ! $path ) {
            $this->staff_export_fail( 'Không thể tạo file tạm.', 500 );
        }
        $result = VWW_XLSX::write( $path, array( 'DANH_SACH_CHECKIN' => $data ) );
        if ( is_wp_error( $result ) ) {
            @unlink( $path );
            $this->staff_export_fail( $result->get_error_message(), 500 );
        }
        clearstatcache( true, $path );
        $size = is_file( $path ) ? filesize( $path ) : 0;
        if ( ! $size ) {
            @unlink( $path );
            $this->staff_export_fail( 'File Excel được tạo nhưng không có dữ liệu.', 500 );
        }
        $filename = 'vww-checkin-' . wp_date( 'Ymd-His' ) . '.xlsx';
        if ( 'checked' === $filters['date_type'] && $filters['date_from'] && $filters['date_from'] === $filters['date_to'] ) {
            $filename = 'vww-checkin-' . preg_replace( '/[^0-9-]/', '', $filters['date_from'] ) . '.xlsx';
        }
        nocache_headers();
        header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Content-Length: ' . $size );
        readfile( $path );
        @unlink( $path );
        exit;
    }

    public function handle_export_xlsx() {
        if ( ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'vww_export_tickets' ) ) || ! check_admin_referer( 'vww_export' ) ) {
            wp_die( 'Không có quyền.' );
        }
        list( $filters, $ids ) = $this->export_request_data();
        if ( 'trash' === $filters['view'] && ! current_user_can( 'manage_options' ) ) {
            $filters['view'] = '';
        }
        $rows = $this->export_rows( $filters, $ids );
        $staff_export = ! current_user_can( 'manage_options' );
        $staff_fields = $staff_export ? $this->staff_export_fields( wp_unslash( $_GET ) ) : array();
        $data = array( $staff_export ? $this->staff_export_headers( $staff_fields ) : $this->export_headers() );
        foreach ( $rows as $row ) {
            $data[] = $staff_export ? $this->staff_export_row( $row, $staff_fields ) : $this->synced_export_row( $row );
        }
        $path = wp_tempnam( 'vww-tickets.xlsx' );
        if ( ! $path ) {
            wp_die( 'Không thể tạo file tạm.' );
        }
        $result = VWW_XLSX::write( $path, array( 'DANH_SACH_VE' => $data ) );
        if ( is_wp_error( $result ) ) {
            @unlink( $path );
            wp_die( esc_html( $result->get_error_message() ) );
        }
        nocache_headers();
        header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
        header( 'Content-Disposition: attachment; filename="vww-tickets-' . wp_date( 'Ymd-His' ) . '.xlsx"' );
        header( 'Content-Length: ' . filesize( $path ) );
        readfile( $path );
        @unlink( $path );
        exit;
    }

    public function handle_export_csv() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vww_export' ) ) {
            wp_die( 'Không có quyền.' );
        }
        list( $filters, $ids ) = $this->export_request_data();
        $rows = $this->export_rows( $filters, $ids );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="vww-tickets-' . wp_date( 'Ymd-His' ) . '.csv"' );
        $out = fopen( 'php://output', 'w' );
        fwrite( $out, "\xEF\xBB\xBF" );
        fputcsv( $out, $this->export_headers() );
        foreach ( $rows as $row ) {
            fputcsv( $out, $this->csv_safe_row( $this->synced_export_row( $row ) ) );
        }
        fclose( $out );
        exit;
    }

    public function rest_routes() {
        register_rest_route(
            'vww/v1',
            '/cf7-ticket',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_create_cf7_ticket' ),
                'permission_callback' => '__return_true',
            )
        );
        register_rest_route(
            'vww/v1',
            '/checkin',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_checkin' ),
                'permission_callback' => function() { return current_user_can( 'vww_checkin' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/checkins/recent',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_recent_checkins' ),
                'permission_callback' => function() { return current_user_can( 'vww_view_tickets' ) || current_user_can( 'vww_checkin' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/tickets',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_ticket_list' ),
                'permission_callback' => function() { return current_user_can( 'vww_view_tickets' ) || current_user_can( 'vww_checkin' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/staff/tickets/bulk',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_staff_bulk_tickets' ),
                'permission_callback' => function() { return current_user_can( 'vww_checkin' ) || current_user_can( 'vww_resend_ticket' ) || current_user_can( 'manage_options' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/tickets/bulk',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_bulk_tickets' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/tickets/(?P<id>\d+)/confirm',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_confirm_ticket' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/tickets/(?P<id>\d+)/resend',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_resend_ticket' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ) || current_user_can( 'vww_resend_ticket' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/tickets/(?P<id>\d+)/undo-checkin',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_undo_checkin' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ) || current_user_can( 'vww_reset_checkin' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/email-preview',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_email_preview' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            )
        );
        register_rest_route(
            'vww/v1',
            '/email-test',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_email_test' ),
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            )
        );
    }

    public function rest_create_cf7_ticket( WP_REST_Request $request ) {
        $nonce = (string) $request->get_header( 'X-WP-Nonce' );
        if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return new WP_Error( 'vww_rest_nonce', 'Phiên tạo vé đã hết hạn. Thông tin đăng ký CF7 vẫn được ghi nhận.', array( 'status' => 403 ) );
        }

        $settings      = $this->settings();
        $configured_id = $this->configured_cf7_form_id();
        $form_id       = sanitize_text_field( (string) $request->get_param( 'form_id' ) );
        if ( '' === $configured_id || $form_id !== $configured_id ) {
            return new WP_Error( 'vww_wrong_form', 'Form này không được cấu hình để tạo vé.', array( 'status' => 400 ) );
        }

        $submission_id = sanitize_text_field( (string) $request->get_param( 'submission_id' ) );
        if ( ! preg_match( '/^[a-zA-Z0-9_-]{16,80}$/', $submission_id ) ) {
            return new WP_Error( 'vww_bad_submission', 'Mã lượt đăng ký không hợp lệ.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $external_id = 'cf7:' . $form_id . ':' . $submission_id;
        $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE external_id=%s LIMIT 1", $external_id ) );
        if ( $existing_id ) {
            $existing = $this->get_ticket( (int) $existing_id );
            return rest_ensure_response( array( 'success' => true, 'duplicate' => true, 'ticket_url' => $this->ticket_url( $existing ) ) );
        }

        $fields = $request->get_param( 'fields' );
        $fields = is_array( $fields ) ? $fields : array();
        $full_name = $this->cf7_value( $fields, 'your-name' );
        $email     = $this->normalize_email( $this->cf7_value( $fields, 'your-email' ) );
        if ( ! $full_name || ! is_email( $email ) ) {
            return new WP_Error( 'vww_missing', 'CF7 đã tiếp nhận đăng ký nhưng chưa đủ họ tên/email để tạo vé.', array( 'status' => 422 ) );
        }

        $event_name = sanitize_text_field( $settings['event_name'] );
        $existing   = $this->find_email_event( $email, $event_name );
        if ( $existing ) {
            return rest_ensure_response( array( 'success' => true, 'duplicate' => true, 'ticket_url' => $this->ticket_url( $existing ) ) );
        }

        $registration_url = esc_url_raw( (string) $request->get_param( 'page_url' ) );
        $referrer_url     = esc_url_raw( (string) $request->get_param( 'referrer' ) );
        $ticket_data = array_merge(
            array(
                'external_id'      => $external_id,
                'full_name'        => $full_name,
                'phone'            => $this->cf7_value( $fields, 'your-phone' ),
                'email'            => $email,
                'wedding_date'     => $this->cf7_value( $fields, 'wedding-date' ),
                'customer_role'    => $this->cf7_value( $fields, 'your-role' ),
                'interest'         => $this->cf7_value( $fields, $settings['cf7_event_content_field'] ),
                'event_name'       => $event_name,
                'source'           => 'cf7',
                'source_form_id'   => absint( $form_id ),
                'registration_url' => $registration_url,
                'referrer_url'     => $referrer_url,
                'visitor_ip'       => sanitize_text_field( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ),
                'user_agent'       => sanitize_textarea_field( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ),
                'source_page_title'=> sanitize_text_field( (string) $request->get_param( 'page_title' ) ),
                'status'           => 'registered',
            ),
            $this->attribution_from_cf7( $fields )
        );
        $ticket = $this->create_ticket( $ticket_data, false );
        if ( is_wp_error( $ticket ) ) {
            $this->log( 0, 'cf7_rest_ticket_failed', $ticket->get_error_message() );
            return new WP_Error( 'vww_ticket_failed', 'Đăng ký đã được tiếp nhận nhưng chưa thể tạo vé ngay.', array( 'status' => 500 ) );
        }

        $this->cf7_pending_ticket_id = (int) $ticket->id;
        $this->queue_pending_cf7_email_by_id( (int) $ticket->id );
        return rest_ensure_response( array( 'success' => true, 'duplicate' => false, 'ticket_url' => $this->ticket_url( $ticket ) ) );
    }

    private function queue_pending_cf7_email_by_id( $ticket_id ) {
        $ticket_id = absint( $ticket_id );
        if ( ! $ticket_id ) return;
        $args = array( $ticket_id );
        if ( ! wp_next_scheduled( 'vww_im_send_queued_cf7_email', $args ) ) {
            $scheduled = wp_schedule_single_event( time() + 10, 'vww_im_send_queued_cf7_email', $args );
            $this->log( $ticket_id, $scheduled ? 'cf7_email_queued' : 'cf7_email_queue_failed', 'Email xếp hàng sau API tạo vé độc lập.' );
        }
    }

    private function status_label( $status ) {
        $labels = array(
            'registered' => 'Đăng ký, chưa gửi vé',
            'issued'     => 'Chưa gửi vé',
            'emailed'    => 'Đã gửi vé',
            'checked_in' => 'Đã check-in',
            'cancelled'  => 'Đã hủy',
        );
        return $labels[ $status ] ?? $status;
    }

    private function ticket_payload( $ticket, $with_admin = false ) {
        $checked_by = '';
        if ( ! empty( $ticket->checked_in_by ) ) {
            $user = get_userdata( $ticket->checked_in_by );
            $checked_by = $user ? $user->display_name : '';
        }
        $payload = array(
            'id'          => (int) $ticket->id,
            'code'        => $ticket->ticket_code,
            'name'        => $ticket->full_name,
            'phone'       => $ticket->phone,
            'email'       => $ticket->email,
            'event'       => $ticket->event_name,
            'interest'    => $ticket->interest,
            'role'        => $ticket->customer_role,
            'source'      => $ticket->attribution_source ?: $ticket->source,
            'technicalSource' => $ticket->source,
            'attributionType' => $ticket->attribution_type,
            'referrerDomain' => $ticket->referrer_domain,
            'firstReferrer' => $ticket->first_referrer,
            'landingPage' => $ticket->landing_page,
            'utmSource' => $ticket->utm_source,
            'utmMedium' => $ticket->utm_medium,
            'utmCampaign' => $ticket->utm_campaign,
            'utmContent' => $ticket->utm_content,
            'utmTerm' => $ticket->utm_term,
            'registrationUrl' => $ticket->registration_url,
            'createdAt'   => $ticket->created_at ? $this->format_site_datetime( $ticket->created_at, 'd/m/Y H:i' ) : '',
            'status'      => $ticket->status,
            'statusLabel' => $this->status_label( $ticket->status ),
            'checkedAt'   => $ticket->checked_in_at ? $this->format_site_datetime( $ticket->checked_in_at, 'H:i d/m/Y' ) : '',
            'checkedBy'   => $checked_by,
            'trashed'     => ! empty( $ticket->trashed_at ),
            'confirmable' => empty( $ticket->trashed_at ) && in_array( $ticket->status, array( 'registered','issued' ), true ),
            'resendable'  => empty( $ticket->trashed_at ) && is_email( $ticket->email ) && ( current_user_can( 'manage_options' ) || ( current_user_can( 'vww_resend_ticket' ) && in_array( $ticket->status, array( 'emailed','checked_in' ), true ) ) ),
            'checkinable' => empty( $ticket->trashed_at ) && 'emailed' === $ticket->status,
        );
        if ( $with_admin ) {
            $payload['editUrl'] = admin_url( 'admin.php?page=vww-edit-ticket&id=' . $ticket->id );
        }
        return $payload;
    }

    public function rest_recent_checkins( WP_REST_Request $request ) {
        global $wpdb;
        $limit = min( 10, max( 1, absint( $request->get_param( 'limit' ) ?: 5 ) ) );
        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table()} WHERE trashed_at IS NULL AND status='checked_in' AND checked_in_at IS NOT NULL ORDER BY checked_in_at DESC, id DESC LIMIT %d",
            $limit
        );
        $tickets = $wpdb->get_results( $sql );
        $payload = array();
        foreach ( $tickets as $ticket ) {
            $payload[] = $this->ticket_payload( $ticket, false );
        }
        return new WP_REST_Response(
            array(
                'ok'       => true,
                'tickets'  => $payload,
                'stats'    => $this->checkin_stats(),
                'syncedAt' => current_time( 'H:i:s' ),
            )
        );
    }

    public function rest_ticket_list( WP_REST_Request $request ) {
        global $wpdb;
        $filters = $this->request_filters( $request->get_params() );
        if ( 'trash' === $filters['view'] && ! current_user_can( 'manage_options' ) ) {
            $filters['view'] = '';
        }
        $parts    = $this->filter_sql( $filters, 't' );
        $page     = max( 1, absint( $request->get_param( 'page' ) ) );
        $per_page = min( 200, max( 20, absint( $request->get_param( 'per_page' ) ?: 100 ) ) );
        $offset   = ( $page - 1 ) * $per_page;
        $count_sql= "SELECT COUNT(*) FROM {$this->table()} t WHERE {$parts['where']}";
        $order_sql = ( 'checked' === $filters['date_type'] && ( $filters['date_from'] || $filters['date_to'] ) ) ? 't.checked_in_at DESC, t.id DESC' : 't.id DESC';
        $list_sql = "SELECT t.* FROM {$this->table()} t WHERE {$parts['where']} ORDER BY $order_sql LIMIT %d OFFSET %d";
        $count_params = $parts['params'];
        if ( $count_params ) {
            $count_sql = $wpdb->prepare( $count_sql, $count_params );
        }
        $list_params   = array_merge( $parts['params'], array( $per_page, $offset ) );
        $list_sql      = $wpdb->prepare( $list_sql, $list_params );
        $total         = (int) $wpdb->get_var( $count_sql );
        $tickets       = $wpdb->get_results( $list_sql );
        $payload       = array();
        foreach ( $tickets as $ticket ) {
            $payload[] = $this->ticket_payload( $ticket, current_user_can( 'manage_options' ) );
        }
        $table  = $this->table();
        $counts = array(
            'all'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NULL" ),
            'registered' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NULL AND status IN ('registered','issued')" ),
            'emailed'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NULL AND status='emailed'" ),
            'checked_in' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NULL AND status='checked_in'" ),
            'cancelled'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NULL AND status='cancelled'" ),
            'trash'      => current_user_can( 'manage_options' ) ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE trashed_at IS NOT NULL" ) : 0,
        );
        $interests = $wpdb->get_col( "SELECT DISTINCT interest FROM $table WHERE trashed_at IS NULL AND interest<>'' ORDER BY interest LIMIT 200" );
        $events    = $wpdb->get_col( "SELECT DISTINCT event_name FROM $table WHERE trashed_at IS NULL AND event_name<>'' ORDER BY event_name LIMIT 100" );
        $sources   = $wpdb->get_col( "SELECT DISTINCT COALESCE(NULLIF(attribution_source,''),source) AS source_label FROM $table WHERE trashed_at IS NULL ORDER BY source_label LIMIT 100" );
        $registration_urls = $wpdb->get_col( "SELECT DISTINCT registration_url FROM $table WHERE trashed_at IS NULL AND registration_url<>'' ORDER BY registration_url LIMIT 100" );
        $batches   = $wpdb->get_results( "SELECT id,batch_code FROM {$this->batches()} ORDER BY id DESC LIMIT 100", ARRAY_A );
        return new WP_REST_Response(
            array(
                'ok'        => true,
                'tickets'   => $payload,
                'total'     => $total,
                'page'      => $page,
                'pages'     => max( 1, (int) ceil( $total / $per_page ) ),
                'counts'    => $counts,
                'stats'     => $this->checkin_stats(),
                'interests' => array_values( array_filter( $interests ) ),
                'events'    => array_values( array_filter( $events ) ),
                'sources'   => array_values( array_filter( $sources ) ),
                'registrationUrls' => array_values( array_filter( $registration_urls ) ),
                'batches'   => $batches,
                'syncedAt'  => current_time( 'H:i:s' ),
            )
        );
    }

    public function rest_confirm_ticket( WP_REST_Request $request ) {
        $ticket = $this->get_ticket( absint( $request['id'] ) );
        if ( ! $ticket ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không tìm thấy vé.' ), 404 );
        }
        if ( ! empty( $ticket->trashed_at ) || ! in_array( $ticket->status, array( 'registered','issued' ), true ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé không ở trạng thái chờ xác nhận.' ), 409 );
        }
        if ( ! $this->send_ticket_email( $ticket ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không gửi được email Vé Mời. Vui lòng kiểm tra SMTP.' ), 500 );
        }
        $this->log( $ticket->id, 'confirmed', 'Administrator xác nhận và gửi Vé Mời.' );
        return new WP_REST_Response( array( 'ok'=>true, 'message'=>'Đã xác nhận và gửi Vé Mời đến ' . $ticket->email . '.' ) );
    }

    public function rest_resend_ticket( WP_REST_Request $request ) {
        $ticket = $this->get_ticket( absint( $request['id'] ) );
        if ( ! $ticket ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không tìm thấy vé.' ), 404 );
        }
        if ( ! empty( $ticket->trashed_at ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không thể gửi email cho vé trong thùng rác.' ), 409 );
        }
        if ( ! current_user_can( 'manage_options' ) && ! in_array( $ticket->status, array( 'emailed','checked_in' ), true ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Nhân viên Check-in chỉ được gửi lại Vé Mời đã phát hành.' ), 403 );
        }
        if ( empty( $ticket->email ) || ! is_email( $ticket->email ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé chưa có địa chỉ email hợp lệ.' ), 422 );
        }
        if ( ! $this->send_ticket_email( $ticket, true ) ) {
            $message = 'SMTP/Brevo không tiếp nhận yêu cầu gửi lại.';
            if ( $this->mail_last_error ) {
                $message .= ' Lỗi: ' . sanitize_text_field( $this->mail_last_error );
            }
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>$message ), 500 );
        }
        $actor = current_user_can( 'manage_options' ) ? 'Administrator' : 'Nhân viên Check-in';
        $this->log( $ticket->id, 'resent', $actor . ' gửi lại Vé Mời.' );
        return new WP_REST_Response( array( 'ok'=>true, 'message'=>'Đã chuyển yêu cầu gửi lại Vé Mời đến ' . $ticket->email . '. Trạng thái vé được giữ nguyên.' ) );
    }

    public function rest_undo_checkin( WP_REST_Request $request ) {
        global $wpdb;
        $ticket = $this->get_ticket( absint( $request['id'] ) );
        if ( ! $ticket ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không tìm thấy vé.' ), 404 );
        }
        if ( ! empty( $ticket->trashed_at ) || 'checked_in' !== $ticket->status ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé hiện không ở trạng thái đã check-in.' ), 409 );
        }
        $now = current_time( 'mysql' );
        $old_time = $ticket->checked_in_at ?: 'không rõ';
        $old_user = absint( $ticket->checked_in_by );
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table()} SET status='emailed', checked_in_at=NULL, checked_in_by=NULL, updated_at=%s WHERE id=%d AND status='checked_in' AND trashed_at IS NULL",
                $now,
                $ticket->id
            )
        );
        if ( ! $updated ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không thể hoàn tác check-in. Trạng thái vé có thể vừa thay đổi ở thiết bị khác.' ), 409 );
        }
        $this->log( $ticket->id, 'checkin_undone', 'Chuyển về chưa check-in. Check-in cũ: ' . $old_time . '; user #' . $old_user . '.' );
        $ticket = $this->get_ticket( $ticket->id );
        return new WP_REST_Response( array( 'ok'=>true, 'message'=>'Đã chuyển vé về trạng thái chưa check-in.', 'ticket'=>$this->ticket_payload( $ticket ) ) );
    }

    private function bulk_ticket_ids( $params ) {
        global $wpdb;
        if ( ! empty( $params['select_all'] ) ) {
            $filters = $this->request_filters( isset( $params['filters'] ) && is_array( $params['filters'] ) ? $params['filters'] : array() );
            $parts   = $this->filter_sql( $filters, 't' );
            $sql     = "SELECT t.id FROM {$this->table()} t WHERE {$parts['where']} ORDER BY t.id DESC LIMIT 5000";
            if ( $parts['params'] ) {
                $sql = $wpdb->prepare( $sql, $parts['params'] );
            }
            return array_map( 'absint', $wpdb->get_col( $sql ) );
        }
        return array_values( array_unique( array_filter( array_map( 'absint', (array) ( $params['ids'] ?? array() ) ) ) ) );
    }

    public function rest_staff_bulk_tickets( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $params = is_array( $params ) ? $params : array();
        $action = sanitize_key( $params['action'] ?? '' );
        if ( ! in_array( $action, array( 'mark_checked_in','resend' ), true ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Thao tác Staff không hợp lệ.' ), 400 );
        }
        if ( 'mark_checked_in' === $action && ! current_user_can( 'vww_checkin' ) && ! current_user_can( 'manage_options' ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không có quyền Check-in hàng loạt.' ), 403 );
        }
        if ( 'resend' === $action && ! current_user_can( 'vww_resend_ticket' ) && ! current_user_can( 'manage_options' ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không có quyền gửi lại vé hàng loạt.' ), 403 );
        }
        $ids = $this->bulk_ticket_ids( $params );
        if ( ! $ids ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Chưa chọn khách.' ), 400 );
        }
        global $wpdb;
        $processed = 0;
        $skipped   = 0;
        $failed    = 0;
        $now       = current_time( 'mysql' );
        foreach ( array_slice( $ids, 0, 5000 ) as $id ) {
            $ticket = $this->get_ticket( $id );
            if ( ! $ticket || ! empty( $ticket->trashed_at ) ) {
                $skipped++;
                continue;
            }
            if ( 'mark_checked_in' === $action ) {
                if ( 'emailed' !== $ticket->status ) {
                    $skipped++;
                    continue;
                }
                $updated = $wpdb->update(
                    $this->table(),
                    array( 'status'=>'checked_in', 'checked_in_at'=>$now, 'checked_in_by'=>get_current_user_id(), 'updated_at'=>$now ),
                    array( 'id'=>$id, 'status'=>'emailed' )
                );
                if ( $updated ) {
                    $this->log( $id, 'staff_bulk_checked_in', 'Nhân viên Check-in xác nhận hàng loạt.' );
                    $processed++;
                } else {
                    $skipped++;
                }
            } elseif ( 'resend' === $action ) {
                if ( ! in_array( $ticket->status, array( 'emailed','checked_in' ), true ) || empty( $ticket->email ) || ! is_email( $ticket->email ) ) {
                    $skipped++;
                    continue;
                }
                if ( $this->send_ticket_email( $ticket, true ) ) {
                    $this->log( $id, 'staff_bulk_resent', 'Nhân viên Check-in gửi lại Vé Mời hàng loạt.' );
                    $processed++;
                } else {
                    $failed++;
                }
            }
        }
        return new WP_REST_Response(
            array(
                'ok'        => true,
                'message'   => 'Đã xử lý ' . $processed . ' khách; bỏ qua ' . $skipped . '; lỗi ' . $failed . '.',
                'processed' => $processed,
                'skipped'   => $skipped,
                'failed'    => $failed,
            )
        );
    }

    public function rest_bulk_tickets( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $params = is_array( $params ) ? $params : array();
        $action = sanitize_key( $params['action'] ?? '' );
        $allowed= array( 'confirm_send','resend','mark_checked_in','undo_checkin','cancel','restore_cancelled','trash','restore_trash','delete_permanently' );
        if ( ! in_array( $action, $allowed, true ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Thao tác không hợp lệ.' ), 400 );
        }
        $ids = $this->bulk_ticket_ids( $params );
        if ( ! $ids ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Chưa chọn vé.' ), 400 );
        }
        global $wpdb;
        $processed = 0;
        $skipped   = 0;
        $failed    = 0;
        $reason    = sanitize_textarea_field( $params['reason'] ?? '' );
        $now       = current_time( 'mysql' );
        foreach ( array_slice( $ids, 0, 5000 ) as $id ) {
            $ticket = $this->get_ticket( $id );
            if ( ! $ticket ) {
                $skipped++;
                continue;
            }
            if ( 'confirm_send' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || ! in_array( $ticket->status, array( 'registered','issued' ), true ) ) {
                    $skipped++;
                } elseif ( $this->send_ticket_email( $ticket ) ) {
                    $processed++;
                    $this->log( $id, 'bulk_confirmed', 'Xác nhận và gửi vé hàng loạt.' );
                } else {
                    $failed++;
                }
            } elseif ( 'resend' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || empty( $ticket->email ) || ! is_email( $ticket->email ) ) {
                    $skipped++;
                } elseif ( $this->send_ticket_email( $ticket, true ) ) {
                    $processed++;
                    $this->log( $id, 'bulk_resent', 'Gửi lại vé hàng loạt.' );
                } else {
                    $failed++;
                }
            } elseif ( 'mark_checked_in' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || 'emailed' !== $ticket->status ) {
                    $skipped++;
                } else {
                    $updated = $wpdb->update(
                        $this->table(),
                        array( 'status'=>'checked_in', 'checked_in_at'=>$now, 'checked_in_by'=>get_current_user_id(), 'updated_at'=>$now ),
                        array( 'id'=>$id, 'status'=>'emailed' )
                    );
                    if ( $updated ) {
                        $this->log( $id, 'bulk_checked_in', 'Check-in thủ công hàng loạt.' );
                        $processed++;
                    } else {
                        $skipped++;
                    }
                }
            } elseif ( 'undo_checkin' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || 'checked_in' !== $ticket->status ) {
                    $skipped++;
                } else {
                    $note = 'Hủy kết quả check-in hàng loạt. Check-in cũ: ' . ( $ticket->checked_in_at ?: 'không rõ' ) . '; user #' . absint( $ticket->checked_in_by );
                    $wpdb->update(
                        $this->table(),
                        array( 'status'=>'emailed', 'checked_in_at'=>null, 'checked_in_by'=>null, 'updated_at'=>$now ),
                        array( 'id'=>$id )
                    );
                    $this->log( $id, 'bulk_checkin_undone', $note );
                    $processed++;
                }
            } elseif ( 'cancel' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || in_array( $ticket->status, array( 'cancelled','checked_in' ), true ) ) {
                    $skipped++;
                } else {
                    $wpdb->update(
                        $this->table(),
                        array(
                            'previous_status' => $ticket->status,
                            'status'          => 'cancelled',
                            'cancelled_at'    => $now,
                            'cancelled_by'    => get_current_user_id(),
                            'cancel_reason'   => $reason,
                            'updated_at'      => $now,
                        ),
                        array( 'id'=>$id )
                    );
                    $this->log( $id, 'cancelled', $reason ?: 'Hủy vé hàng loạt.' );
                    $processed++;
                }
            } elseif ( 'restore_cancelled' === $action ) {
                if ( ! empty( $ticket->trashed_at ) || 'cancelled' !== $ticket->status ) {
                    $skipped++;
                } else {
                    $restored = $ticket->emailed_at ? 'emailed' : 'registered';
                    $wpdb->update(
                        $this->table(),
                        array(
                            'status'          => $restored,
                            'previous_status' => '',
                            'cancelled_at'    => null,
                            'cancelled_by'    => null,
                            'cancel_reason'   => null,
                            'updated_at'      => $now,
                        ),
                        array( 'id'=>$id )
                    );
                    $this->log( $id, 'cancel_restored', 'Khôi phục thành ' . $restored );
                    $processed++;
                }
            } elseif ( 'trash' === $action ) {
                if ( ! empty( $ticket->trashed_at ) ) {
                    $skipped++;
                } else {
                    $wpdb->update( $this->table(), array( 'trashed_at'=>$now, 'trashed_by'=>get_current_user_id(), 'updated_at'=>$now ), array( 'id'=>$id ) );
                    $this->log( $id, 'trashed', 'Chuyển vào thùng rác.' );
                    $processed++;
                }
            } elseif ( 'restore_trash' === $action ) {
                if ( empty( $ticket->trashed_at ) ) {
                    $skipped++;
                } else {
                    $wpdb->update( $this->table(), array( 'trashed_at'=>null, 'trashed_by'=>null, 'updated_at'=>$now ), array( 'id'=>$id ) );
                    $this->log( $id, 'trash_restored', 'Khôi phục từ thùng rác.' );
                    $processed++;
                }
            } elseif ( 'delete_permanently' === $action ) {
                if ( empty( $ticket->trashed_at ) ) {
                    $skipped++;
                } else {
                    $this->log( 0, 'permanently_deleted', 'Xóa vé ' . $ticket->ticket_code . ' bởi user #' . get_current_user_id() );
                    $wpdb->delete( $this->logs(), array( 'ticket_id'=>$id ) );
                    $wpdb->delete( $this->table(), array( 'id'=>$id ) );
                    $processed++;
                }
            }
        }
        return new WP_REST_Response(
            array(
                'ok'        => true,
                'message'   => 'Đã xử lý ' . $processed . ' vé; bỏ qua ' . $skipped . '; lỗi gửi ' . $failed . '.',
                'processed' => $processed,
                'skipped'   => $skipped,
                'failed'    => $failed,
            )
        );
    }

    public function rest_email_preview( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $params = is_array( $params ) ? $params : array();
        $type   = isset( $params['email_type'] ) && 'registration' === sanitize_key( $params['email_type'] ) ? 'registration' : 'invitation';
        $settings = array_merge( $this->settings(), $this->sanitize_template( $type, $params ) );
        $ticket = $this->sample_ticket();
        return new WP_REST_Response(
            array(
                'ok'      => true,
                'subject' => $this->render_email_subject( $type, $ticket, $settings ),
                'html'    => $this->render_email( $type, $ticket, $settings ),
            )
        );
    }

    public function rest_email_test( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $params = is_array( $params ) ? $params : array();
        $email  = sanitize_email( $params['test_email'] ?? '' );
        if ( ! is_email( $email ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Email nhận bản thử không hợp lệ.' ), 400 );
        }
        $type     = isset( $params['email_type'] ) && 'registration' === sanitize_key( $params['email_type'] ) ? 'registration' : 'invitation';
        $settings = array_merge( $this->settings(), $this->sanitize_template( $type, $params ) );
        $ticket   = $this->sample_ticket();
        $sent = wp_mail(
            $email,
            '[BẢN THỬ] ' . $this->render_email_subject( $type, $ticket, $settings ),
            $this->render_email( $type, $ticket, $settings ),
            $this->mail_headers( $settings )
        );
        if ( ! $sent ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không gửi được email thử. Vui lòng kiểm tra SMTP.' ), 500 );
        }
        return new WP_REST_Response( array( 'ok'=>true, 'message'=>'Đã gửi email thử đến ' . $email . '.' ) );
    }

    public function rest_checkin( WP_REST_Request $request ) {
        global $wpdb;
        $code   = trim( (string) $request->get_param( 'code' ) );
        $ticket = null;
        if ( false !== strpos( $code, 'vww_ticket=' ) ) {
            parse_str( parse_url( $code, PHP_URL_QUERY ) ?: '', $query );
            if ( ! empty( $query['vww_ticket'] ) ) {
                $ticket = $this->get_by_token( $query['vww_ticket'] );
            }
        }
        if ( ! $ticket ) {
            $ticket = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE ticket_code=%s", strtoupper( $code ) ) );
        }
        if ( ! $ticket ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Không tìm thấy vé.' ), 404 );
        }
        if ( ! empty( $ticket->trashed_at ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé nằm trong thùng rác và không còn hiệu lực.' ), 409 );
        }
        if ( 'checked_in' === $ticket->status ) {
            return new WP_REST_Response(
                array(
                    'ok'        => false,
                    'duplicate' => true,
                    'message'   => 'Vé đã check-in lúc ' . $this->format_site_datetime( $ticket->checked_in_at, 'H:i d/m/Y', 'không xác định' ),
                    'ticket'    => $this->ticket_payload( $ticket ),
                ),
                409
            );
        }
        if ( in_array( $ticket->status, array( 'registered','issued' ), true ) ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Đăng ký này chưa được xác nhận và gửi Vé Mời.' ), 409 );
        }
        if ( 'cancelled' === $ticket->status ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé đã bị hủy.' ), 409 );
        }
        $now = current_time( 'mysql' );
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table()} SET status='checked_in', checked_in_at=%s, checked_in_by=%d, updated_at=%s WHERE id=%d AND status='emailed' AND trashed_at IS NULL",
                $now,
                get_current_user_id(),
                $now,
                $ticket->id
            )
        );
        if ( ! $updated ) {
            return new WP_REST_Response( array( 'ok'=>false, 'message'=>'Vé không thể check-in. Có thể vừa được quét ở thiết bị khác.' ), 409 );
        }
        $ticket = $this->get_ticket( $ticket->id );
        $this->log( $ticket->id, 'checked_in', 'Check-in scanner hoặc từ dòng vé.' );
        return new WP_REST_Response( array( 'ok'=>true, 'message'=>'Check-in thành công.', 'ticket'=>$this->ticket_payload( $ticket ) ) );
    }

    public function scanner_shortcode() {
        if ( ! is_user_logged_in() || ! current_user_can( 'vww_checkin' ) ) {
            return '<div class="vww-public-error">Bạn cần đăng nhập bằng tài khoản nhân viên check-in để sử dụng màn quét.</div>';
        }
        wp_enqueue_style( 'vww-im-public' );
        wp_enqueue_script( 'vww-im-scanner' );
        wp_localize_script( 'vww-im-scanner', 'VWWScanner', array( 'endpoint'=>rest_url( 'vww/v1/checkin' ), 'nonce'=>wp_create_nonce( 'wp_rest' ) ) );
        return $this->staff_scanner_markup();
    }

    public function render_public_ticket() {
        if ( empty( $_GET['vww_ticket'] ) ) {
            return;
        }
        $token  = sanitize_text_field( wp_unslash( $_GET['vww_ticket'] ) );
        $ticket = $this->get_by_token( $token );
        $valid  = $ticket && empty( $ticket->trashed_at ) && 'cancelled' !== $ticket->status;
        status_header( $valid ? 200 : 410 );
        nocache_headers();
        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
        $design = $this->ticket_design_settings();
        $style_version = self::VERSION . '.' . absint( $design['ticket_design_version'] ?? 1 );
        echo '<!doctype html><html lang="vi"><head><meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Vé mời tham dự · Vietnam Wedding Week 2026</title><link rel="preload" href="' . esc_url( plugins_url( 'assets/fonts/be-vietnam-pro-latin-400-normal.woff2', VWW_IM_FILE ) ) . '" as="font" type="font/woff2" crossorigin><link rel="preload" href="' . esc_url( plugins_url( 'assets/fonts/cormorant-garamond-latin-400-normal.woff2', VWW_IM_FILE ) ) . '" as="font" type="font/woff2" crossorigin><link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/ticket-fonts.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( $style_version ) . '"><link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/public.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( $style_version ) . '"><link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/ticket-v2.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( $style_version ) . '"><link rel="stylesheet" href="' . esc_url( plugins_url( 'assets/css/ticket-custom.css', VWW_IM_FILE ) ) . '?ver=' . esc_attr( $style_version ) . '">';
        if ( ! empty( $design['ticket_custom_css'] ) ) {
            echo '<style id="vww-ticket-custom-css">' . str_replace( '</style', '<\/style', $design['ticket_custom_css'] ) . '</style>';
        }
        echo '</head><body class="vww-standalone-ticket">';
        echo '<main class="vww-ticket-page">';
        echo $valid ? $this->render_ticket_markup( $ticket ) : '<div class="vww-public-error"><strong>Vé mời không còn hiệu lực.</strong><br>Vé đã bị hủy, xóa hoặc đường dẫn không hợp lệ.</div>';
        echo '</main></body></html>';
        exit;
    }

    private function masked_email( $email ) {
        $parts = explode( '@', (string) $email, 2 );
        if ( 2 !== count( $parts ) ) return (string) $email;
        $name = $parts[0];
        return substr( $name, 0, min( 3, strlen( $name ) ) ) . '***@' . $parts[1];
    }

    private function render_ticket_markup( $ticket ) {
        $s = $this->ticket_design_settings();
        $replace = array(
            '{customer_name}'  => (string) $ticket->full_name,
            '{customer_email}' => $this->masked_email( $ticket->email ),
        );
        $intro = strtr( $s['ticket_intro'], $replace );
        $note  = strtr( $s['ticket_email_note'], $replace );
        $style = '--vww-primary:' . $s['ticket_primary_color'] . ';--vww-accent:' . $s['ticket_accent_color'] . ';--vww-bg:' . $s['ticket_background_color'] . ';--vww-card:' . $s['ticket_card_color'] . ';--vww-text:' . $s['ticket_text_color'];
        $status = 'checked_in' === $ticket->status ? '<div class="vww-ticket-status is-checked">✓ ĐÃ CHECK-IN</div>' : '<div class="vww-ticket-status">VÉ HỢP LỆ</div>';
        $buttons = '';
        foreach ( array( array( 'ticket_schedule_url','ticket_schedule_label','is-primary' ), array( 'ticket_map_url','ticket_map_label','' ), array( 'ticket_contact_url','ticket_contact_label','' ), array( 'ticket_home_url','ticket_home_label','' ) ) as $button ) {
            if ( ! empty( $s[ $button[0] ] ) && ! empty( $s[ $button[1] ] ) ) {
                $buttons .= '<a class="vww-action ' . esc_attr( $button[2] ) . '" href="' . esc_url( $s[ $button[0] ] ) . '">' . esc_html( $s[ $button[1] ] ) . '</a>';
            }
        }
        $identity = ! empty( $s['ticket_logo_url'] ) ? '<img class="vww-brand-logo" src="' . esc_url( $s['ticket_logo_url'] ) . '" alt="' . esc_attr( $s['ticket_brand_name'] ) . '">' : '<span class="vww-monogram">' . esc_html( $s['ticket_monogram'] ) . '</span>';
        $details = '<div class="vww-ticket-details">'
            . '<div><span>SỰ KIỆN</span><p><strong>' . esc_html( $ticket->event_name ) . '</strong>' . ( $s['ticket_concept'] ? '<small>' . esc_html( $s['ticket_concept'] ) . '</small>' : '' ) . '</p></div>'
            . '<div><span>THỜI GIAN</span><p><strong>' . esc_html( $s['ticket_event_date'] ) . '</strong><small>' . esc_html( $s['ticket_event_time'] ) . '</small></p></div>'
            . '<div><span>ĐỊA ĐIỂM</span><p><strong>' . esc_html( $s['ticket_venue'] ) . '</strong><small>' . esc_html( $s['ticket_address'] ) . '</small></p></div>'
            . ( $ticket->customer_role ? '<div><span>VAI TRÒ</span><p><strong>' . esc_html( $ticket->customer_role ) . '</strong></p></div>' : '' )
            . '<div><span>SỐ KHÁCH</span><p><strong>' . esc_html( $s['ticket_guest_count'] ) . '</strong></p></div></div>';
        return '<div class="vww-ticket-shell" style="' . esc_attr( $style ) . '"><section class="vww-overview"><div><p class="vww-eyebrow">' . esc_html( $s['ticket_eyebrow'] ) . '</p><h1>' . esc_html( $s['ticket_title'] ) . '</h1><p class="vww-lead">' . nl2br( esc_html( $intro ) ) . '</p><p class="vww-email-note">' . nl2br( esc_html( $note ) ) . '</p></div><div class="vww-overview-bottom"><div class="vww-rule"></div><p><strong>HƯỚNG DẪN CHECK-IN</strong><br>' . nl2br( esc_html( $s['ticket_instruction'] ) ) . '</p><div class="vww-actions">' . $buttons . '</div></div></section><section class="vww-invitation-wrap"><article class="vww-invitation vww-invitation-v2"><div class="vww-ticket-identity">' . $identity . '<strong>' . esc_html( $s['ticket_brand_name'] ) . '</strong></div><div class="vww-ticket-main"><p class="vww-invite-title">' . esc_html( $s['ticket_invitation_title'] ) . '</p><p class="vww-script">' . esc_html( $s['ticket_invite_phrase'] ) . '</p><h2>' . esc_html( $ticket->full_name ) . '</h2><div class="vww-gold-line"></div>' . $details . '</div><div class="vww-ticket-stub"><img src="' . esc_url( $this->qr_url( $ticket ) ) . '" alt="QR check-in" width="168" height="168"><div><small>MÃ THAM DỰ</small><strong>' . esc_html( $ticket->ticket_code ) . '</strong>' . $status . '<p>' . esc_html( $s['ticket_checkin_note'] ) . '</p></div></div></article><p class="vww-save-hint">Hãy chụp màn hình hoặc lưu lại trang vé này trên điện thoại.</p></section></div>';
    }

    public function ticket_shortcode() {
        $token  = isset( $_GET['vww_ticket'] ) ? sanitize_text_field( wp_unslash( $_GET['vww_ticket'] ) ) : '';
        $ticket = $token ? $this->get_by_token( $token ) : null;
        if ( ! $ticket || ! empty( $ticket->trashed_at ) || 'cancelled' === $ticket->status ) {
            return '<div class="vww-public-error">Vé mời không còn hiệu lực.</div>';
        }
        wp_enqueue_style( 'vww-im-public' );
        return $this->render_ticket_markup( $ticket );
    }
}

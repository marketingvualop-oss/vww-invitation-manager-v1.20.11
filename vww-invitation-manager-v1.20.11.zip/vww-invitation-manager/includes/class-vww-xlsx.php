<?php
/**
 * Lightweight XLSX reader/writer for VWW Invitation Manager.
 *
 * The implementation only uses PHP's ZipArchive and SimpleXML extensions.
 * It intentionally treats exported values as text to preserve phone numbers
 * and prevent spreadsheet formula injection.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class VWW_XLSX {
    public static function available() {
        return class_exists( 'ZipArchive' ) && function_exists( 'simplexml_load_string' );
    }

    private static function column_index( $reference ) {
        if ( ! preg_match( '/^([A-Z]+)/i', (string) $reference, $match ) ) {
            return 0;
        }
        $letters = strtoupper( $match[1] );
        $index   = 0;
        for ( $i = 0, $length = strlen( $letters ); $i < $length; $i++ ) {
            $index = ( $index * 26 ) + ( ord( $letters[ $i ] ) - 64 );
        }
        return max( 0, $index - 1 );
    }

    private static function column_name( $index ) {
        $index++;
        $name = '';
        while ( $index > 0 ) {
            $remainder = ( $index - 1 ) % 26;
            $name      = chr( 65 + $remainder ) . $name;
            $index     = (int) floor( ( $index - 1 ) / 26 );
        }
        return $name;
    }

    private static function xml_escape( $value ) {
        $value = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $value );
        return htmlspecialchars( $value, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
    }

    public static function read( $path, $limit = 10000 ) {
        if ( ! self::available() ) {
            return new WP_Error( 'vww_xlsx_missing', 'Máy chủ chưa bật ZipArchive/SimpleXML. Hãy bật hai extension này hoặc nhập file CSV.' );
        }

        $zip = new ZipArchive();
        if ( true !== $zip->open( $path ) ) {
            return new WP_Error( 'vww_xlsx_open', 'Không thể mở file Excel.' );
        }

        $shared = array();
        $shared_stat = $zip->statName( 'xl/sharedStrings.xml' );
        if ( $shared_stat && ! empty( $shared_stat['size'] ) && (int) $shared_stat['size'] > 20 * MB_IN_BYTES ) {
            $zip->close();
            return new WP_Error( 'vww_xlsx_large', 'Nội dung file Excel vượt giới hạn an toàn.' );
        }
        $shared_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
        if ( false !== $shared_xml ) {
            $document = simplexml_load_string( $shared_xml );
            if ( $document ) {
                $document->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
                foreach ( $document->xpath( '//x:si' ) as $item ) {
                    $item->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
                    $parts = array();
                    foreach ( $item->xpath( './/x:t' ) as $text ) {
                        $parts[] = (string) $text;
                    }
                    $shared[] = implode( '', $parts );
                }
            }
        }

        $sheet_path   = 'xl/worksheets/sheet1.xml';
        $workbook_xml = $zip->getFromName( 'xl/workbook.xml' );
        $rels_xml     = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );
        if ( false !== $workbook_xml && false !== $rels_xml ) {
            $workbook = simplexml_load_string( $workbook_xml );
            $rels     = simplexml_load_string( $rels_xml );
            if ( $workbook && $rels ) {
                $workbook->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
                $rels->registerXPathNamespace( 'r', 'http://schemas.openxmlformats.org/package/2006/relationships' );
                $first_sheets = $workbook->xpath( '//x:sheets/x:sheet[1]' );
                if ( $first_sheets ) {
                    $relationship_attributes = $first_sheets[0]->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' );
                    $relationship_id         = (string) $relationship_attributes['id'];
                    foreach ( $rels->xpath( '//r:Relationship' ) as $relationship ) {
                        $attributes = $relationship->attributes();
                        if ( (string) $attributes['Id'] === $relationship_id ) {
                            $target = ltrim( (string) $attributes['Target'], '/' );
                            if ( preg_match( '#^(?:xl/)?worksheets/[A-Za-z0-9_.-]+\.xml$#', $target ) ) {
                                $sheet_path = 0 === strpos( $target, 'xl/' ) ? $target : 'xl/' . $target;
                            }
                            break;
                        }
                    }
                }
            }
        }
        $sheet_stat = $zip->statName( $sheet_path );
        if ( $sheet_stat && ! empty( $sheet_stat['size'] ) && (int) $sheet_stat['size'] > 30 * MB_IN_BYTES ) {
            $zip->close();
            return new WP_Error( 'vww_xlsx_large', 'Sheet dữ liệu Excel vượt giới hạn an toàn.' );
        }
        $sheet_xml  = $zip->getFromName( $sheet_path );
        $zip->close();
        if ( false === $sheet_xml ) {
            return new WP_Error( 'vww_xlsx_sheet', 'File Excel không có sheet dữ liệu đầu tiên.' );
        }

        $sheet = simplexml_load_string( $sheet_xml );
        if ( ! $sheet ) {
            return new WP_Error( 'vww_xlsx_xml', 'Sheet dữ liệu Excel không hợp lệ.' );
        }
        $sheet->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
        $rows = array();
        foreach ( $sheet->xpath( '//x:sheetData/x:row' ) as $row ) {
            if ( count( $rows ) >= $limit ) {
                break;
            }
            $row->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
            $values = array();
            foreach ( $row->xpath( './x:c' ) as $cell ) {
                $cell->registerXPathNamespace( 'x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
                $attributes = $cell->attributes();
                $index      = self::column_index( (string) $attributes['r'] );
                $type       = (string) $attributes['t'];
                $value      = '';
                if ( 'inlineStr' === $type ) {
                    $texts = $cell->xpath( './/x:is/x:t' );
                    if ( $texts ) {
                        foreach ( $texts as $text ) {
                            $value .= (string) $text;
                        }
                    }
                } else {
                    $nodes = $cell->xpath( './x:v' );
                    $raw   = $nodes ? (string) $nodes[0] : '';
                    $value = ( 's' === $type && isset( $shared[ (int) $raw ] ) ) ? $shared[ (int) $raw ] : $raw;
                }
                $values[ $index ] = trim( (string) $value );
            }
            if ( $values ) {
                $max = max( array_keys( $values ) );
                for ( $i = 0; $i <= $max; $i++ ) {
                    if ( ! isset( $values[ $i ] ) ) {
                        $values[ $i ] = '';
                    }
                }
                ksort( $values );
                $rows[] = array_values( $values );
            }
        }
        return $rows;
    }

    public static function write( $path, array $sheets ) {
        if ( ! class_exists( 'ZipArchive' ) ) {
            return new WP_Error( 'vww_xlsx_missing', 'Máy chủ chưa bật ZipArchive nên chưa thể tạo file Excel.' );
        }
        if ( ! $sheets ) {
            return new WP_Error( 'vww_xlsx_empty', 'Không có dữ liệu để tạo file Excel.' );
        }

        $zip = new ZipArchive();
        if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
            return new WP_Error( 'vww_xlsx_write', 'Không thể tạo file Excel tạm thời.' );
        }

        $sheet_overrides = '';
        $workbook_sheets = '';
        $workbook_rels   = '';
        $app_titles      = '';
        $sheet_count     = 0;

        foreach ( $sheets as $sheet_name => $rows ) {
            $sheet_count++;
            $clean_name = preg_replace( '/[\\\\\\/?*\\[\\]:]/u', ' ', (string) $sheet_name );
            $safe_name  = function_exists( 'mb_substr' ) ? mb_substr( $clean_name, 0, 31 ) : substr( $clean_name, 0, 31 );
            if ( '' === trim( $safe_name ) ) {
                $safe_name = 'Sheet ' . $sheet_count;
            }
            $workbook_sheets .= '<sheet name="' . self::xml_escape( $safe_name ) . '" sheetId="' . $sheet_count . '" r:id="rId' . $sheet_count . '"/>';
            $workbook_rels   .= '<Relationship Id="rId' . $sheet_count . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $sheet_count . '.xml"/>';
            $sheet_overrides .= '<Override PartName="/xl/worksheets/sheet' . $sheet_count . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
            $app_titles      .= '<vt:lpstr>' . self::xml_escape( $safe_name ) . '</vt:lpstr>';

            $xml_rows = '';
            $row_no   = 0;
            $max_cols = 1;
            foreach ( (array) $rows as $row ) {
                $row_no++;
                $row      = array_values( (array) $row );
                $max_cols = max( $max_cols, count( $row ) );
                $cells    = '';
                foreach ( $row as $column => $value ) {
                    $reference = self::column_name( $column ) . $row_no;
                    $style     = ( 1 === $row_no ) ? ' s="1"' : '';
                    $safe      = self::xml_escape( (string) $value );
                    $cells    .= '<c r="' . $reference . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . $safe . '</t></is></c>';
                }
                $xml_rows .= '<row r="' . $row_no . '">' . $cells . '</row>';
            }
            $dimension = 'A1:' . self::column_name( max( 0, $max_cols - 1 ) ) . max( 1, $row_no );
            $widths    = '';
            for ( $column = 1; $column <= $max_cols; $column++ ) {
                $width = in_array( $column, array( 3, 4 ), true ) ? 22 : 18;
                if ( 2 === $column ) {
                    $width = 28;
                }
                $widths .= '<col min="' . $column . '" max="' . $column . '" width="' . $width . '" customWidth="1"/>';
            }
            $auto_filter = $row_no > 1 ? '<autoFilter ref="' . $dimension . '"/>' : '';
            $sheet_content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                . '<dimension ref="' . $dimension . '"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                . '<cols>' . $widths . '</cols><sheetData>' . $xml_rows . '</sheetData>' . $auto_filter . '</worksheet>';
            $zip->addFromString( 'xl/worksheets/sheet' . $sheet_count . '.xml', $sheet_content );
        }

        $zip->addFromString( '[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>' . $sheet_overrides . '</Types>' );
        $zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>' );
        $zip->addFromString( 'xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $workbook_sheets . '</sheets></workbook>' );
        $zip->addFromString( 'xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $workbook_rels . '<Relationship Id="rId' . ( $sheet_count + 1 ) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' );
        $zip->addFromString( 'xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF77171D"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"/></cellXfs></styleSheet>' );
        $now = gmdate( 'Y-m-d\TH:i:s\Z' );
        $zip->addFromString( 'docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>VWW Invitation Manager</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created></cp:coreProperties>' );
        $zip->addFromString( 'docProps/app.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>VWW Invitation Manager</Application><TitlesOfParts><vt:vector size="' . $sheet_count . '" baseType="lpstr">' . $app_titles . '</vt:vector></TitlesOfParts></Properties>' );
        $zip->close();
        return true;
    }
}

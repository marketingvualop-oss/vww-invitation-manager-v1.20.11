(function () {
  'use strict';

  function init() {
    if (!window.VWWStaffCenter) return;

    var tabs = Array.prototype.slice.call(document.querySelectorAll('[data-vww-staff-tab]'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('[data-vww-staff-panel]'));
    var rows = document.getElementById('vww-staff-rows');
    var cards = document.getElementById('vww-staff-cards');
    var search = document.getElementById('vww-staff-search');
    var status = document.getElementById('vww-staff-status');
    var eventName = document.getElementById('vww-staff-event');
    var source = document.getElementById('vww-staff-source');
    var dateFrom = document.getElementById('vww-staff-checkin-from');
    var dateTo = document.getElementById('vww-staff-checkin-to');
    var count = document.getElementById('vww-staff-count');
    var sync = document.getElementById('vww-staff-sync');
    var prev = document.getElementById('vww-staff-prev');
    var next = document.getElementById('vww-staff-next');
    var pageLabel = document.getElementById('vww-staff-page');
    var refresh = document.getElementById('vww-staff-refresh');
    var exportBtn = document.getElementById('vww-staff-export');
    var filterToggle = document.getElementById('vww-staff-filter-toggle');
    var filterPanel = document.getElementById('vww-staff-filter-panel');
    var filterClose = document.getElementById('vww-staff-filter-close');
    var filterApply = document.getElementById('vww-staff-filter-apply');
    var filterReset = document.getElementById('vww-staff-filter-reset');
    var filterBackdrop = document.getElementById('vww-filter-backdrop');
    var chips = Array.prototype.slice.call(document.querySelectorAll('[data-status-chip]'));
    var dateQuick = Array.prototype.slice.call(document.querySelectorAll('[data-date-quick]'));
    var recentList = document.getElementById('vww-recent-list');
    var recentToday = document.getElementById('vww-recent-today');
    var recentViewAll = document.getElementById('vww-recent-view-all');
    var toast = document.getElementById('vww-staff-toast');
    var modal = document.getElementById('vww-staff-modal');
    var modalKicker = document.getElementById('vww-staff-modal-kicker');
    var modalTitle = document.getElementById('vww-staff-modal-title');
    var modalBody = document.getElementById('vww-staff-modal-body');
    var modalConfirm = document.getElementById('vww-staff-modal-confirm');
    var modalCloseEls = Array.prototype.slice.call(document.querySelectorAll('[data-modal-close]'));
    var selectionBar = document.getElementById('vww-selection-bar');
    var selectedCount = document.getElementById('vww-selected-count');
    var selectPage = document.getElementById('vww-select-page');
    var selectAllResults = document.getElementById('vww-select-all-results');
    var selectionClear = document.getElementById('vww-selection-clear');
    var bulkAction = document.getElementById('vww-bulk-action');
    var bulkApply = document.getElementById('vww-bulk-apply');
    var exportSelected = document.getElementById('vww-export-selected');
    var exportModal = document.getElementById('vww-export-modal');
    var exportCloseEls = Array.prototype.slice.call(document.querySelectorAll('[data-export-close]'));
    var exportConfirm = document.getElementById('vww-export-confirm');
    var exportDefaultFields = document.getElementById('vww-export-default-fields');
    var exportAllFields = document.getElementById('vww-export-all-fields');
    var exportFilteredCount = document.getElementById('vww-export-filtered-count');
    var exportSelectedCount = document.getElementById('vww-export-selected-count');
    var exportSelectedOption = document.getElementById('vww-export-selected-option');

    if (!rows || !search || !status) return;

    var state = {
      page: 1,
      pages: 1,
      total: 0,
      request: 0,
      loaded: false,
      tickets: [],
      selected: new Set(),
      selectAllResults: false,
      counts: {}
    };
    var debounce = null;
    var toastTimer = null;
    var modalResolve = null;

    function esc(value) {
      var node = document.createElement('div');
      node.textContent = value == null ? '' : String(value);
      return node.innerHTML;
    }

    function showToast(message, type) {
      if (!toast) return;
      window.clearTimeout(toastTimer);
      toast.textContent = message || '';
      toast.className = 'vww-staff-toast is-visible' + (type === 'error' ? ' is-error' : '');
      toastTimer = window.setTimeout(function () { toast.className = 'vww-staff-toast'; }, 3600);
    }

    function closeModal(result) {
      if (!modal || modal.hidden) return;
      modal.hidden = true;
      document.body.classList.remove('vww-modal-open');
      var resolver = modalResolve;
      modalResolve = null;
      if (resolver) resolver(!!result);
    }

    function confirmModal(options) {
      options = options || {};
      if (!modal) return Promise.resolve(window.confirm(options.title || 'Xác nhận thao tác?'));
      if (modalResolve) closeModal(false);
      if (modalKicker) modalKicker.textContent = options.kicker || 'XÁC NHẬN';
      if (modalTitle) modalTitle.textContent = options.title || 'Xác nhận thao tác';
      if (modalBody) modalBody.innerHTML = options.body || '';
      if (modalConfirm) {
        modalConfirm.textContent = options.confirmLabel || 'Xác nhận';
        modalConfirm.style.background = options.danger ? '#9e3034' : '';
        modalConfirm.style.borderColor = options.danger ? '#9e3034' : '';
      }
      modal.hidden = false;
      document.body.classList.add('vww-modal-open');
      return new Promise(function (resolve) { modalResolve = resolve; });
    }

    window.VWWStaffConfirm = confirmModal;
    modalCloseEls.forEach(function (el) { el.addEventListener('click', function () { closeModal(false); }); });
    if (modalConfirm) modalConfirm.addEventListener('click', function () { closeModal(true); });

    function filters() {
      var from = dateFrom ? dateFrom.value : '';
      var to = dateTo ? dateTo.value : '';
      return {
        q: search ? search.value.trim() : '',
        status: status ? status.value : '',
        event_name: eventName ? eventName.value : '',
        source: source ? source.value : '',
        date_type: (from || to) ? 'checked' : '',
        date_from: from,
        date_to: to
      };
    }

    function appendFilters(url, withPage) {
      var active = filters();
      Object.keys(active).forEach(function (key) {
        if (active[key]) url.searchParams.set(key, active[key]);
      });
      if (withPage) {
        url.searchParams.set('page', String(state.page));
        url.searchParams.set('per_page', '100');
      }
      return url;
    }

    function listUrl() {
      return appendFilters(new URL(VWWStaffCenter.listEndpoint, window.location.origin), true).toString();
    }

    function statusClass(ticket) {
      if (ticket.status === 'checked_in') return 'is-checked';
      if (ticket.status === 'emailed') return 'is-ready';
      if (ticket.status === 'cancelled') return 'is-cancelled';
      return 'is-waiting';
    }

    function displayStatus(ticket) {
      if (ticket.status === 'emailed') return 'CHƯA CHECK-IN';
      return String(ticket.statusLabel || '').toUpperCase();
    }

    function secondaryActions(ticket) {
      var actions = [];
      if (ticket.status === 'checked_in' && VWWStaffCenter.canReset) {
        actions.push('<button type="button" data-action="undo" data-id="' + Number(ticket.id) + '" data-name="' + esc(ticket.name) + '" data-code="' + esc(ticket.code) + '">Chuyển về chưa check-in</button>');
      }
      if (ticket.resendable && VWWStaffCenter.canResend) {
        actions.push('<button type="button" data-action="resend" data-id="' + Number(ticket.id) + '" data-name="' + esc(ticket.name) + '" data-email="' + esc(ticket.email) + '">Gửi lại vé</button>');
      }
      return actions;
    }

    function actionHtml(ticket) {
      var direct = '';
      var secondary = secondaryActions(ticket);
      if (ticket.checkinable) {
        direct = '<button type="button" class="vww-staff-action is-checkin" data-action="checkin" data-code="' + esc(ticket.code) + '" data-name="' + esc(ticket.name) + '">CHECK-IN</button>';
      }
      var menu = secondary.length ? '<details class="vww-action-menu"><summary aria-label="Thao tác khác">⋯</summary><div class="vww-action-menu-popover">' + secondary.join('') + '</div></details>' : '';
      if (!direct && !menu) {
        if (ticket.status === 'registered' || ticket.status === 'issued') return '<span class="vww-staff-readonly">Chờ Admin gửi vé</span>';
        return '<span class="vww-staff-readonly">Chỉ xem</span>';
      }
      return '<div class="vww-staff-row-actions">' + direct + menu + '</div>';
    }

    function isSelected(id) {
      return state.selectAllResults || state.selected.has(Number(id));
    }

    function ticketCheckbox(ticket, mobile) {
      return '<input type="checkbox" class="vww-ticket-select' + (mobile ? ' is-mobile' : '') + '" data-select-ticket="' + Number(ticket.id) + '" aria-label="Chọn ' + esc(ticket.name) + '" ' + (isSelected(ticket.id) ? 'checked ' : '') + (state.selectAllResults ? 'disabled' : '') + '>';
    }

    function render(tickets) {
      state.tickets = tickets || [];
      if (!tickets || !tickets.length) {
        rows.innerHTML = '<tr><td colspan="7">Không tìm thấy khách phù hợp.</td></tr>';
        if (cards) cards.innerHTML = '<div class="vww-recent-empty">Không tìm thấy khách phù hợp.</div>';
        updateSelectionUi();
        return;
      }
      rows.innerHTML = tickets.map(function (ticket) {
        var checked = ticket.checkedAt ? '<small class="vww-staff-checked-meta">' + esc(ticket.checkedAt) + (ticket.checkedBy ? ' · ' + esc(ticket.checkedBy) : '') + '</small>' : '';
        return '<tr class="' + (isSelected(ticket.id) ? 'is-selected' : '') + '">' +
          '<td class="vww-select-col">' + ticketCheckbox(ticket, false) + '</td>' +
          '<td><b>' + esc(ticket.name) + '</b><small class="vww-staff-code">' + esc(ticket.code) + '</small></td>' +
          '<td><span>' + esc(ticket.phone || '—') + '</span><small>' + esc(ticket.email || '') + '</small></td>' +
          '<td><b>' + esc(ticket.event || '—') + '</b><small>' + esc(ticket.interest || '') + '</small></td>' +
          '<td>' + esc(ticket.source || '—') + '</td>' +
          '<td><span class="vww-staff-status ' + statusClass(ticket) + '">' + esc(displayStatus(ticket)) + '</span>' + checked + '</td>' +
          '<td>' + actionHtml(ticket) + '</td>' +
          '</tr>';
      }).join('');

      if (cards) {
        cards.innerHTML = tickets.map(function (ticket) {
          var checked = ticket.checkedAt ? '<small class="vww-staff-checked-meta">' + esc(ticket.checkedAt) + (ticket.checkedBy ? ' · ' + esc(ticket.checkedBy) : '') + '</small>' : '';
          return '<article class="vww-guest-card' + (isSelected(ticket.id) ? ' is-selected' : '') + '">' +
            '<div class="vww-guest-card-select">' + ticketCheckbox(ticket, true) + '</div>' +
            '<div class="vww-guest-card-head"><div><b>' + esc(ticket.name) + '</b><code>' + esc(ticket.code) + '</code></div><span class="vww-staff-status ' + statusClass(ticket) + '">' + esc(displayStatus(ticket)) + '</span></div>' +
            '<div class="vww-guest-card-contact"><span>' + esc(ticket.phone || '—') + '</span><span>' + esc(ticket.email || '') + '</span></div>' +
            '<div class="vww-guest-card-event">' + esc(ticket.event || '—') + (ticket.interest ? ' · ' + esc(ticket.interest) : '') + '</div>' +
            '<div class="vww-guest-card-bottom"><div class="vww-guest-card-status">' + checked + '</div><div class="vww-guest-card-actions">' + actionHtml(ticket) + '</div></div>' +
            '</article>';
        }).join('');
      }
      updateSelectionUi();
    }

    function populate(select, values) {
      if (!select || !values) return;
      var current = select.value;
      var first = select.options.length ? select.options[0].outerHTML : '<option value="">Tất cả</option>';
      select.innerHTML = first + values.map(function (value) { return '<option value="' + esc(value) + '">' + esc(value) + '</option>'; }).join('');
      select.value = current;
    }

    function updateStats(stats) {
      stats = stats || {};
      var map = {
        'vww-staff-stat-total': stats.total || 0,
        'vww-staff-stat-checked': stats.checked || 0,
        'vww-staff-stat-waiting': stats.waiting || 0,
        'vww-staff-stat-today': stats.today || 0
      };
      Object.keys(map).forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.textContent = String(map[id]);
      });
    }

    function updateCounts(counts) {
      state.counts = counts || {};
      var map = {
        'vww-staff-count-all': state.counts.all || 0,
        'vww-staff-count-registered': state.counts.registered || 0,
        'vww-staff-count-emailed': state.counts.emailed || 0,
        'vww-staff-count-checked_in': state.counts.checked_in || 0,
        'vww-staff-count-cancelled': state.counts.cancelled || 0
      };
      Object.keys(map).forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.textContent = String(map[id]);
      });
    }

    function selectionCountValue() {
      return state.selectAllResults ? state.total : state.selected.size;
    }

    function currentPageIds() {
      return state.tickets.map(function (ticket) { return Number(ticket.id); });
    }

    function updateSelectionUi() {
      var totalSelected = selectionCountValue();
      if (selectionBar) selectionBar.hidden = totalSelected < 1;
      if (selectedCount) selectedCount.textContent = totalSelected + ' khách đã chọn';
      if (selectAllResults) {
        selectAllResults.hidden = state.selectAllResults || totalSelected < 1 || state.total <= totalSelected;
        if (!selectAllResults.hidden) selectAllResults.textContent = 'Chọn toàn bộ ' + state.total + ' kết quả đang lọc';
      }
      if (selectPage) {
        var ids = currentPageIds();
        var checkedOnPage = ids.filter(function (id) { return isSelected(id); }).length;
        selectPage.checked = ids.length > 0 && checkedOnPage === ids.length;
        selectPage.indeterminate = checkedOnPage > 0 && checkedOnPage < ids.length;
        selectPage.disabled = state.selectAllResults || !ids.length;
      }
      if (exportSelectedOption) exportSelectedOption.hidden = totalSelected < 1;
      if (exportSelectedCount) exportSelectedCount.textContent = totalSelected + ' khách';
      if (exportFilteredCount) exportFilteredCount.textContent = state.total + ' khách';
    }

    function clearSelection(renderAgain) {
      state.selected.clear();
      state.selectAllResults = false;
      if (renderAgain !== false) render(state.tickets);
      else updateSelectionUi();
    }

    function loadTickets(keepPage) {
      if (!keepPage) state.page = Math.max(1, state.page);
      var requestNo = ++state.request;
      if (count) count.textContent = 'Đang tải danh sách…';
      return fetch(listUrl(), { credentials: 'same-origin', headers: { 'X-WP-Nonce': VWWStaffCenter.nonce } })
        .then(function (response) {
          return response.json().then(function (body) {
            if (!response.ok || !body.ok) throw new Error(body.message || 'Không tải được danh sách khách.');
            return body;
          });
        }).then(function (data) {
          if (requestNo !== state.request) return;
          state.pages = Number(data.pages || 1);
          state.total = Number(data.total || 0);
          state.loaded = true;
          render(data.tickets || []);
          updateStats(data.stats || {});
          updateCounts(data.counts || {});
          populate(eventName, data.events || []);
          populate(source, data.sources || []);
          if (count) count.textContent = state.total + ' khách phù hợp';
          if (sync) sync.textContent = 'Cập nhật lúc ' + (data.syncedAt || '—') + ' · không tự refresh';
          if (pageLabel) pageLabel.textContent = 'Trang ' + state.page + ' / ' + state.pages;
          if (prev) prev.disabled = state.page <= 1;
          if (next) next.disabled = state.page >= state.pages;
          syncChips();
          updateSelectionUi();
        }).catch(function (error) {
          if (requestNo !== state.request) return;
          rows.innerHTML = '<tr><td colspan="7">Không tải được dữ liệu.</td></tr>';
          if (cards) cards.innerHTML = '<div class="vww-recent-empty">Không tải được dữ liệu.</div>';
          showToast(error.message, 'error');
        });
    }

    function renderRecent(tickets) {
      if (!recentList) return;
      if (!tickets || !tickets.length) {
        recentList.innerHTML = '<div class="vww-recent-empty">Chưa có lượt check-in nào.</div>';
        return;
      }
      recentList.innerHTML = tickets.map(function (ticket) {
        var time = ticket.checkedAt ? String(ticket.checkedAt).split(' ')[0] : '—';
        return '<article class="vww-recent-item">' +
          '<div class="vww-recent-person"><b>' + esc(ticket.name) + '</b><small>' + esc(ticket.code) + '</small></div>' +
          '<div class="vww-recent-event">' + esc(ticket.event || 'VWW') + '</div>' +
          '<div class="vww-recent-time"><i></i><span>' + esc(time) + (ticket.checkedBy ? ' · ' + esc(ticket.checkedBy) : '') + '</span></div>' +
          '</article>';
      }).join('');
    }

    function loadRecent() {
      if (!recentList || !VWWStaffCenter.recentEndpoint) return Promise.resolve();
      var url = new URL(VWWStaffCenter.recentEndpoint, window.location.origin);
      url.searchParams.set('limit', '5');
      return fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-WP-Nonce': VWWStaffCenter.nonce } })
        .then(function (response) { return response.json().then(function (body) { if (!response.ok || !body.ok) throw new Error(); return body; }); })
        .then(function (data) {
          renderRecent(data.tickets || []);
          if (recentToday) recentToday.textContent = 'Hôm nay: ' + Number((data.stats || {}).today || 0);
        }).catch(function () {
          recentList.innerHTML = '<div class="vww-recent-empty">Không tải được check-in gần nhất.</div>';
        });
    }

    function apiPost(endpoint, payload) {
      return fetch(endpoint, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': VWWStaffCenter.nonce },
        body: JSON.stringify(payload || {})
      }).then(function (response) {
        return response.json().catch(function () { return {}; }).then(function (body) {
          if (!response.ok || !body.ok) throw new Error(body.message || 'Không thể xử lý yêu cầu.');
          return body;
        });
      });
    }

    function runAction(button) {
      if (!button || button.disabled) return;
      var action = button.dataset.action;
      var idle = button.textContent;
      var name = button.dataset.name || '';
      var code = button.dataset.code || '';
      var email = button.dataset.email || '';
      var options = null;
      if (action === 'checkin') {
        options = { title: 'Xác nhận Check-in', body: '<div class="vww-staff-modal-person"><b>' + esc(name) + '</b><code>' + esc(code) + '</code></div>', confirmLabel: 'XÁC NHẬN CHECK-IN' };
      } else if (action === 'undo') {
        options = { title: 'Chuyển về chưa Check-in?', body: '<div class="vww-staff-modal-person"><b>' + esc(name) + '</b><code>' + esc(code) + '</code></div><p>Lịch sử thao tác cũ vẫn được giữ trong nhật ký hệ thống.</p>', confirmLabel: 'XÁC NHẬN HOÀN TÁC', danger: true };
      } else if (action === 'resend') {
        options = { title: 'Gửi lại Vé Mời?', body: '<div class="vww-staff-modal-person"><b>' + esc(name) + '</b><code>' + esc(email) + '</code></div><p>Email chỉ đọc và không thể chỉnh sửa tại Check-in Center.</p>', confirmLabel: 'GỬI LẠI VÉ' };
      }
      if (!options) return;
      confirmModal(options).then(function (confirmed) {
        if (!confirmed) return;
        button.disabled = true;
        button.textContent = action === 'checkin' ? 'Đang check-in…' : (action === 'resend' ? 'Đang gửi…' : 'Đang xử lý…');
        var request;
        if (action === 'checkin') request = apiPost(VWWStaffCenter.checkinEndpoint, { code: code });
        else if (action === 'undo') request = apiPost(String(VWWStaffCenter.ticketEndpoint).replace(/\/$/, '') + '/' + button.dataset.id + '/undo-checkin', {});
        else request = apiPost(String(VWWStaffCenter.ticketEndpoint).replace(/\/$/, '') + '/' + button.dataset.id + '/resend', {});
        request.then(function (data) {
          var message = action === 'checkin' ? '✓ CHECK-IN THÀNH CÔNG · ' + ((data.ticket || {}).name || name) : '✓ ' + (data.message || 'Đã xử lý.');
          showToast(message, 'success');
        }).catch(function (error) {
          showToast(error.message, 'error');
        }).finally(function () {
          button.disabled = false;
          button.textContent = idle;
          loadTickets(true);
          loadRecent();
        });
      });
    }

    function bulkPayload(action) {
      return {
        action: action,
        select_all: state.selectAllResults,
        ids: state.selectAllResults ? [] : Array.from(state.selected),
        filters: filters()
      };
    }

    function runBulkAction() {
      if (!bulkAction || !bulkAction.value) {
        showToast('Hãy chọn một thao tác hàng loạt.', 'error');
        return;
      }
      var total = selectionCountValue();
      if (!total) {
        showToast('Chưa chọn khách.', 'error');
        return;
      }
      var action = bulkAction.value;
      var isCheckin = action === 'mark_checked_in';
      var title = isCheckin ? 'Check-in khách đã chọn?' : 'Gửi lại vé cho khách đã chọn?';
      var note = isCheckin
        ? 'Chỉ các vé đã gửi và chưa Check-in mới được xử lý. Vé không đủ điều kiện sẽ được bỏ qua.'
        : 'Chỉ vé đã phát hành có email hợp lệ mới được gửi lại. Trạng thái vé được giữ nguyên.';
      confirmModal({
        title: title,
        body: '<div class="vww-staff-modal-person"><b>' + total + ' khách đã chọn</b><code>' + esc(note) + '</code></div>',
        confirmLabel: isCheckin ? 'CHECK-IN ' + total + ' KHÁCH' : 'GỬI LẠI VÉ'
      }).then(function (confirmed) {
        if (!confirmed) return;
        if (bulkApply) bulkApply.disabled = true;
        apiPost(VWWStaffCenter.bulkEndpoint, bulkPayload(action)).then(function (data) {
          showToast('✓ ' + (data.message || 'Đã xử lý hàng loạt.'), 'success');
          clearSelection(false);
          if (bulkAction) bulkAction.value = '';
          return Promise.all([loadTickets(true), loadRecent()]);
        }).catch(function (error) {
          showToast(error.message, 'error');
        }).finally(function () {
          if (bulkApply) bulkApply.disabled = false;
        });
      });
    }

    function openExportModal(preferSelected) {
      if (!exportModal) return;
      updateSelectionUi();
      var totalSelected = selectionCountValue();
      var radios = Array.prototype.slice.call(exportModal.querySelectorAll('input[name="vww-export-scope"]'));
      radios.forEach(function (radio) {
        radio.checked = preferSelected && totalSelected > 0 ? radio.value === 'selected' : radio.value === 'filtered';
      });
      exportModal.hidden = false;
      document.body.classList.add('vww-modal-open');
    }

    function closeExportModal() {
      if (!exportModal) return;
      exportModal.hidden = true;
      document.body.classList.remove('vww-modal-open');
    }

    function exportFields(defaultOnly) {
      var fields = Array.prototype.slice.call(document.querySelectorAll('[data-export-field]'));
      if (defaultOnly === true) fields.forEach(function (field) { field.checked = field.dataset.default === '1'; });
      if (defaultOnly === false) fields.forEach(function (field) { field.checked = true; });
      return fields;
    }

    function addHidden(form, name, value) {
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = name;
      input.value = value == null ? '' : String(value);
      form.appendChild(input);
    }

    function submitExport() {
      if (!VWWStaffCenter.exportUrl || !VWWStaffCenter.exportNonce || !VWWStaffCenter.exportAction) return;
      var selectedFields = exportFields().filter(function (field) { return field.checked; });
      if (!selectedFields.length) {
        showToast('Hãy chọn ít nhất một trường dữ liệu để Export.', 'error');
        return;
      }
      var scopeEl = exportModal ? exportModal.querySelector('input[name="vww-export-scope"]:checked') : null;
      var scope = scopeEl ? scopeEl.value : 'filtered';
      var totalSelected = selectionCountValue();
      if (scope === 'selected' && totalSelected < 1) {
        showToast('Chưa có khách nào được chọn.', 'error');
        return;
      }

      // Use WordPress' native admin-post flow for downloads. The browser owns
      // Content-Disposition and file saving directly: no Fetch, Blob or iframe.
      var form = document.createElement('form');
      form.method = 'post';
      form.action = VWWStaffCenter.exportUrl;
      form.style.display = 'none';
      addHidden(form, 'action', VWWStaffCenter.exportAction);
      addHidden(form, 'vww_staff_export_nonce', VWWStaffCenter.exportNonce);

      var activeFilters = filters();
      Object.keys(activeFilters).forEach(function (key) {
        if (activeFilters[key]) addHidden(form, key, activeFilters[key]);
      });
      if (scope === 'selected' && !state.selectAllResults) {
        addHidden(form, 'ids', Array.from(state.selected).join(','));
      }
      selectedFields.forEach(function (field) { addHidden(form, 'fields[]', field.value); });

      document.body.appendChild(form);
      closeExportModal();
      showToast('Đang tạo file Excel…', 'success');
      form.submit();
      window.setTimeout(function () {
        if (form.parentNode) form.parentNode.removeChild(form);
      }, 2000);
    }

    function resetSelectionForFilterChange() {
      if (state.selected.size || state.selectAllResults) clearSelection(false);
    }

    function changed() {
      resetSelectionForFilterChange();
      state.page = 1;
      loadTickets(false);
    }

    function syncChips() {
      var active = status ? status.value : '';
      chips.forEach(function (chip) { chip.classList.toggle('is-active', chip.dataset.statusChip === active); });
      if (!chips.some(function (chip) { return chip.classList.contains('is-active'); }) && chips[0]) chips[0].classList.add('is-active');
    }

    function openFilters() {
      if (!filterPanel) return;
      filterPanel.classList.add('is-open');
      if (filterBackdrop) filterBackdrop.classList.add('is-open');
      document.body.classList.add('vww-filter-open');
    }

    function closeFilters() {
      if (!filterPanel) return;
      filterPanel.classList.remove('is-open');
      if (filterBackdrop) filterBackdrop.classList.remove('is-open');
      document.body.classList.remove('vww-filter-open');
    }

    document.addEventListener('click', function (event) {
      var button = event.target.closest('[data-action]');
      if (button) { event.preventDefault(); runAction(button); return; }
      var quick = event.target.closest('[data-date-quick]');
      if (quick) {
        event.preventDefault();
        var mode = quick.dataset.dateQuick;
        if (mode === 'today') {
          if (dateFrom) dateFrom.value = VWWStaffCenter.today || '';
          if (dateTo) dateTo.value = VWWStaffCenter.today || '';
        } else if (mode === 'yesterday') {
          if (dateFrom) dateFrom.value = VWWStaffCenter.yesterday || '';
          if (dateTo) dateTo.value = VWWStaffCenter.yesterday || '';
        } else {
          if (dateFrom) dateFrom.value = '';
          if (dateTo) dateTo.value = '';
        }
        if (window.innerWidth > 900) changed();
      }
    });

    document.addEventListener('change', function (event) {
      var checkbox = event.target.closest('[data-select-ticket]');
      if (!checkbox || state.selectAllResults) return;
      var id = Number(checkbox.dataset.selectTicket);
      if (checkbox.checked) state.selected.add(id);
      else state.selected.delete(id);
      render(state.tickets);
    });

    if (selectPage) selectPage.addEventListener('change', function () {
      if (state.selectAllResults) return;
      currentPageIds().forEach(function (id) {
        if (selectPage.checked) state.selected.add(id);
        else state.selected.delete(id);
      });
      render(state.tickets);
    });
    if (selectAllResults) selectAllResults.addEventListener('click', function () {
      state.selectAllResults = true;
      state.selected.clear();
      render(state.tickets);
    });
    if (selectionClear) selectionClear.addEventListener('click', function () { clearSelection(true); });
    if (bulkApply) bulkApply.addEventListener('click', runBulkAction);
    if (exportSelected) exportSelected.addEventListener('click', function () { openExportModal(true); });

    if (search) search.addEventListener('input', function () {
      window.clearTimeout(debounce);
      debounce = window.setTimeout(changed, 320);
    });
    [status, eventName, source, dateFrom, dateTo].forEach(function (element) {
      if (element) element.addEventListener('change', function () { syncChips(); if (window.innerWidth > 900) changed(); });
    });
    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        if (status) status.value = chip.dataset.statusChip || '';
        syncChips();
        changed();
      });
    });
    if (filterToggle) filterToggle.addEventListener('click', openFilters);
    if (filterClose) filterClose.addEventListener('click', closeFilters);
    if (filterBackdrop) filterBackdrop.addEventListener('click', closeFilters);
    if (filterApply) filterApply.addEventListener('click', function () { closeFilters(); changed(); });
    if (filterReset) filterReset.addEventListener('click', function () {
      if (status) status.value = '';
      if (eventName) eventName.value = '';
      if (source) source.value = '';
      if (dateFrom) dateFrom.value = '';
      if (dateTo) dateTo.value = '';
      syncChips();
      if (window.innerWidth <= 900) closeFilters();
      changed();
    });
    if (refresh) refresh.addEventListener('click', function () {
      refresh.disabled = true;
      refresh.textContent = '↻ Đang tải…';
      Promise.all([loadTickets(true), loadRecent()]).finally(function () {
        refresh.disabled = false;
        refresh.textContent = '↻ Làm mới';
      });
    });
    if (prev) prev.addEventListener('click', function () { if (state.page > 1) { state.page--; loadTickets(true); } });
    if (next) next.addEventListener('click', function () { if (state.page < state.pages) { state.page++; loadTickets(true); } });
    if (exportBtn) exportBtn.addEventListener('click', function () { openExportModal(selectionCountValue() > 0); });

    exportCloseEls.forEach(function (el) { el.addEventListener('click', closeExportModal); });
    if (exportConfirm) exportConfirm.addEventListener('click', submitExport);
    if (exportDefaultFields) exportDefaultFields.addEventListener('click', function () { exportFields(true); });
    if (exportAllFields) exportAllFields.addEventListener('click', function () { exportFields(false); });

    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      if (filterPanel && filterPanel.classList.contains('is-open')) closeFilters();
      else if (exportModal && !exportModal.hidden) closeExportModal();
      else closeModal(false);
    });

    function activateTab(target) {
      tabs.forEach(function (tab) { tab.classList.toggle('is-active', tab.dataset.vwwStaffTab === target); });
      panels.forEach(function (panel) { panel.classList.toggle('is-active', panel.dataset.vwwStaffPanel === target); });
      if (target === 'guests') {
        if (window.VWWScannerController && window.VWWScannerController.isRunning()) window.VWWScannerController.stop();
        if (!state.loaded) loadTickets(false);
      }
      // Camera is intentionally not auto-started when returning to the QR tab.
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    tabs.forEach(function (button) { button.addEventListener('click', function () { activateTab(button.dataset.vwwStaffTab); }); });
    if (recentViewAll) recentViewAll.addEventListener('click', function () {
      if (status) status.value = 'checked_in';
      if (dateFrom) dateFrom.value = '';
      if (dateTo) dateTo.value = '';
      syncChips();
      clearSelection(false);
      state.page = 1;
      state.loaded = false;
      activateTab('guests');
    });

    document.addEventListener('vww:ticket-updated', function () {
      loadRecent();
      if (state.loaded) loadTickets(true);
      showToast('✓ Check-in thành công', 'success');
    });

    loadRecent();
    syncChips();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
}());

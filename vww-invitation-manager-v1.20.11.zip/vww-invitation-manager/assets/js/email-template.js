(function () {
  function initEmailTemplate() {
    var form = document.getElementById('vww-email-template-form');
    if (!form || !window.VWWEmailTemplate) return;

    var editorId = VWWEmailTemplate.bodyId || 'vww_invitation_body';
    var previewButton = document.getElementById('vww-email-preview');
    var previewModal = document.getElementById('vww-email-preview-modal');
    var previewFrame = document.getElementById('vww-email-preview-frame');
    var previewSubject = document.getElementById('vww-email-preview-subject');
    var closePreview = document.getElementById('vww-close-email-preview');
    var testButton = document.getElementById('vww-send-test-email');
    var testEmail = document.getElementById('vww-test-email-address');
    var testResult = document.getElementById('vww-email-test-result');
    var resetButton = document.getElementById('vww-reset-email-template');
    var logoButton = document.getElementById('vww-select-email-logo');
    var logoInput = document.getElementById('vww-template-logo-url');

    function editorContent() {
      if (window.tinymce) {
        var editor = window.tinymce.get(editorId);
        if (editor && !editor.isHidden()) return editor.getContent();
      }
      var textarea = document.getElementById(editorId);
      return textarea ? textarea.value : '';
    }

    function collectTemplate() {
      var payload = {};
      new FormData(form).forEach(function (value, key) {
        if (typeof value === 'string') payload[key] = value;
      });
      payload[VWWEmailTemplate.bodyKey || 'invitation_body'] = editorContent();
      payload.email_type = VWWEmailTemplate.type || 'invitation';
      return payload;
    }

    function apiPost(endpoint, payload) {
      return fetch(endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': VWWEmailTemplate.nonce
        },
        body: JSON.stringify(payload)
      }).then(function (response) {
        return response.json().then(function (body) {
          if (!response.ok || !body.ok) throw new Error(body.message || 'Không thể xử lý yêu cầu.');
          return body;
        });
      });
    }

    function insertVariable(token) {
      if (window.tinymce) {
        var editor = window.tinymce.get(editorId);
        if (editor && !editor.isHidden()) {
          editor.focus();
          editor.execCommand('mceInsertContent', false, token);
          return;
        }
      }
      var textarea = document.getElementById(editorId);
      if (!textarea) return;
      textarea.focus();
      if (typeof textarea.setRangeText === 'function') {
        textarea.setRangeText(token, textarea.selectionStart, textarea.selectionEnd, 'end');
      } else {
        textarea.value += token;
      }
    }

    function setBusy(button, busyText, idleText, busy) {
      if (!button) return;
      button.disabled = busy;
      button.textContent = busy ? busyText : idleText;
    }

    function showTestResult(message, type) {
      if (!testResult) return;
      testResult.hidden = false;
      testResult.className = 'vww-email-result ' + (type || '');
      testResult.textContent = message;
    }

    Array.prototype.forEach.call(document.querySelectorAll('.vww-insert-variable'), function (button) {
      button.addEventListener('click', function () {
        insertVariable(button.getAttribute('data-token') || '');
      });
    });

    if (previewButton && previewModal && previewFrame) {
      previewButton.addEventListener('click', function () {
        setBusy(previewButton, 'Đang dựng bản xem trước…', 'Xem trước', true);
        apiPost(VWWEmailTemplate.previewEndpoint, collectTemplate()).then(function (data) {
          previewSubject.textContent = data.subject || 'Email Vé Mời';
          previewFrame.srcdoc = data.html || '';
          previewModal.hidden = false;
          document.body.classList.add('vww-email-modal-open');
        }).catch(function (error) {
          window.alert(error.message);
        }).finally(function () {
          setBusy(previewButton, '', 'Xem trước', false);
        });
      });
    }

    function hidePreview() {
      if (!previewModal) return;
      previewModal.hidden = true;
      document.body.classList.remove('vww-email-modal-open');
    }

    if (closePreview) closePreview.addEventListener('click', hidePreview);
    if (previewModal) {
      previewModal.addEventListener('click', function (event) {
        if (event.target === previewModal) hidePreview();
      });
    }
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && previewModal && !previewModal.hidden) hidePreview();
    });

    if (testButton && testEmail) {
      testButton.addEventListener('click', function () {
        var address = testEmail.value.trim();
        if (!address) {
          showTestResult('Vui lòng nhập email nhận bản thử.', 'error');
          return;
        }
        var payload = collectTemplate();
        payload.test_email = address;
        setBusy(testButton, 'Đang gửi…', 'Gửi email thử', true);
        showTestResult('Đang gửi email thử…', '');
        apiPost(VWWEmailTemplate.testEndpoint, payload).then(function (data) {
          showTestResult('✓ ' + data.message, 'success');
        }).catch(function (error) {
          showTestResult(error.message, 'error');
        }).finally(function () {
          setBusy(testButton, '', 'Gửi email thử', false);
        });
      });
    }

    if (resetButton) {
      resetButton.addEventListener('click', function (event) {
        if (!window.confirm('Khôi phục mẫu email hiện tại về mặc định?')) event.preventDefault();
      });
    }

    if (logoButton && logoInput && window.wp && window.wp.media) {
      logoButton.addEventListener('click', function () {
        var frame = window.wp.media({
          title: 'Chọn logo cho email',
          button: { text: 'Dùng logo này' },
          multiple: false,
          library: { type: 'image' }
        });
        frame.on('select', function () {
          var attachment = frame.state().get('selection').first().toJSON();
          logoInput.value = attachment.url || '';
        });
        frame.open();
      });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initEmailTemplate);
  else initEmailTemplate();
}());

(function () {
    'use strict';
    var KEY = 'vww_first_touch_v1';
    var MAX_AGE = 30 * 24 * 60 * 60 * 1000;

    function matchesConfiguredForm(form) {
        var configured = window.VWWCF7Config ? String(VWWCF7Config.formId || '') : '';
        if (!configured || !form) return false;
        var hidden = form.querySelector('input[name="_wpcf7"]');
        var wrapper = form.closest('.wpcf7');
        var candidates = [hidden ? hidden.value : '', wrapper && wrapper.dataset ? wrapper.dataset.wpcf7Id : ''];
        if (wrapper && wrapper.id) {
            var match = wrapper.id.match(/^wpcf7-f([^\-]+)/);
            if (match) candidates.push(match[1]);
        }
        return candidates.map(String).indexOf(configured) !== -1;
    }

    function safeParse(value) {
        try { return JSON.parse(value); } catch (e) { return null; }
    }

    function sourceFromReferrer(referrer) {
        if (!referrer) return 'Truy cập trực tiếp';
        try {
            var host = new URL(referrer).hostname.replace(/^www\./, '').toLowerCase();
            if (/(^|\.)facebook\.com$/.test(host)) return 'Facebook';
            if (/(^|\.)instagram\.com$/.test(host)) return 'Instagram';
            if (/(^|\.)tiktok\.com$/.test(host)) return 'TikTok';
            if (/(^|\.)google\./.test(host)) return 'Google';
            if (/(^|\.)youtube\.com$/.test(host)) return 'YouTube';
            if (/(^|\.)zalo\.me$/.test(host)) return 'Zalo';
            return host;
        } catch (e) { return 'Không xác định'; }
    }

    function firstTouch() {
        var saved = null;
        try { saved = safeParse(localStorage.getItem(KEY)); } catch (e) {}
        if (saved && saved.savedAt && Date.now() - saved.savedAt < MAX_AGE) return saved;
        var query = new URLSearchParams(window.location.search);
        var referrer = document.referrer || '';
        var data = {
            savedAt: Date.now(),
            attributed_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
            first_source: query.get('utm_source') || sourceFromReferrer(referrer),
            first_referrer: referrer,
            landing_page: window.location.href,
            utm_source: query.get('utm_source') || '',
            utm_medium: query.get('utm_medium') || '',
            utm_campaign: query.get('utm_campaign') || '',
            utm_content: query.get('utm_content') || '',
            utm_term: query.get('utm_term') || ''
        };
        try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) {}
        return data;
    }

    function inject(form, data) {
        if (!matchesConfiguredForm(form)) return;
        var fields = {
            vww_first_source: data.first_source,
            vww_first_referrer: data.first_referrer,
            vww_landing_page: data.landing_page,
            vww_utm_source: data.utm_source,
            vww_utm_medium: data.utm_medium,
            vww_utm_campaign: data.utm_campaign,
            vww_utm_content: data.utm_content,
            vww_utm_term: data.utm_term,
            vww_attributed_at: data.attributed_at
        };
        Object.keys(fields).forEach(function (name) {
            var input = form.querySelector('input[name="' + name + '"]');
            if (!input) {
                input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                form.appendChild(input);
            }
            input.value = fields[name] || '';
        });
    }

    function apply() {
        var data = firstTouch();
        document.querySelectorAll('.wpcf7 form').forEach(function (form) { if (matchesConfiguredForm(form)) inject(form, data); });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply);
    else apply();
    document.addEventListener('wpcf7beforesubmit', function (event) {
        var form = event.target && event.target.matches('form') ? event.target : event.target.querySelector('form');
        if (form && matchesConfiguredForm(form)) inject(form, firstTouch());
    });
}());

(function () {
  function initScanner() {
    var input = document.getElementById('vww-ticket-code');
    var submit = document.getElementById('vww-checkin');
    var startBtn = document.getElementById('vww-start-camera');
    var stopBtn = document.getElementById('vww-stop-camera');
    var switchBtn = document.getElementById('vww-switch-camera');
    var cameraName = document.getElementById('vww-camera-name');
    var status = document.getElementById('vww-camera-status');
    var reader = document.getElementById('vww-reader');
    var result = document.getElementById('vww-result');
    var overlay = document.getElementById('vww-scan-success');
    var overlayIcon = document.getElementById('vww-scan-success-icon');
    var overlayTitle = document.getElementById('vww-scan-success-title');
    var overlayName = document.getElementById('vww-scan-success-name');
    var overlayCode = document.getElementById('vww-scan-success-code');
    var overlayMeta = document.getElementById('vww-scan-success-meta');
    var continueBtn = document.getElementById('vww-scan-continue');
    if (!input || !submit || !reader || !window.VWWScanner) return;

    var scanner = null;
    var cameras = [];
    var cameraIndex = 0;
    var running = false;
    var busy = false;
    var locked = false;
    var activeCamera = null;

    function esc(value) {
      var node = document.createElement('div');
      node.textContent = value || '';
      return node.innerHTML;
    }

    function show(message, type) {
      result.className = 'vww-result ' + (type || '');
      result.innerHTML = message;
    }

    function setStatus(label, type) {
      if (!status) return;
      status.className = 'vww-camera-status ' + (type || 'is-idle');
      var text = status.querySelector('span');
      if (text) text.textContent = label;
    }

    function setControls(isRunning) {
      running = isRunning;
      reader.classList.toggle('is-active', isRunning);
      if (startBtn) startBtn.hidden = isRunning || locked;
      if (stopBtn) stopBtn.hidden = !isRunning;
      if (switchBtn) switchBtn.hidden = !isRunning || cameras.length < 2;
    }

    function errorText(error) {
      var name = error && (error.name || error.message) || '';
      if (!window.isSecureContext) return 'Camera chỉ hoạt động trên kết nối HTTPS.';
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return 'Trình duyệt này không hỗ trợ mở camera.';
      if (/NotAllowed|Permission|denied/i.test(name)) return 'Quyền Camera đang bị từ chối. Hãy cho phép Camera trong cài đặt trình duyệt.';
      if (/NotFound|DevicesNotFound|no_camera/i.test(name)) return 'Không tìm thấy camera trên thiết bị.';
      if (/NotReadable|TrackStart|busy/i.test(name)) return 'Camera đang được ứng dụng khác sử dụng.';
      return 'Không thể mở camera. Hãy kiểm tra quyền Camera rồi thử lại.';
    }

    function cameraError(error) {
      var message = errorText(error);
      setControls(false);
      setStatus('Camera lỗi', 'is-error');
      reader.innerHTML = '<div class="vww-camera-help"><strong>Không thể mở Camera</strong><span>' + esc(message) + '</span><button type="button" id="vww-retry-camera">Thử lại</button></div>';
      var retry = document.getElementById('vww-retry-camera');
      if (retry) retry.addEventListener('click', openCamera);
      show(message + ' Bạn vẫn có thể nhập mã vé thủ công.', 'error');
    }

    function feedback(kind) {
      try {
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
          var ctx = new AudioContext();
          var osc = ctx.createOscillator();
          var gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.frequency.value = kind === 'success' ? 920 : 360;
          gain.gain.setValueAtTime(0.09, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (kind === 'success' ? 0.12 : 0.2));
          osc.start();
          osc.stop(ctx.currentTime + (kind === 'success' ? 0.12 : 0.2));
        }
      } catch (e) {}
      try {
        if (navigator.vibrate) navigator.vibrate(kind === 'success' ? [90] : [120, 60, 120]);
      } catch (e) {}
    }

    function overlayState(type, ticket, message) {
      if (!overlay) return;
      ticket = ticket || {};
      var title = 'KHÔNG THỂ CHECK-IN';
      var icon = '!';
      var meta = message || '';
      if (type === 'success') {
        title = 'CHECK-IN THÀNH CÔNG';
        icon = '✓';
        meta = ticket.checkedAt ? 'Check-in lúc ' + ticket.checkedAt : '';
      } else if (type === 'duplicate') {
        title = 'VÉ ĐÃ CHECK IN';
        icon = '!';
        meta = ticket.checkedAt ? 'Đã check-in lúc ' + ticket.checkedAt : (message || 'Vé đã được sử dụng.');
      } else if (type === 'notfound') {
        title = 'VÉ KHÔNG TỒN TẠI';
        icon = '×';
        meta = 'Mã QR không tồn tại trong hệ thống VWW.';
      }
      overlay.className = 'vww-scan-success is-visible is-' + type;
      overlay.setAttribute('aria-hidden', 'false');
      if (overlayIcon) overlayIcon.textContent = icon;
      if (overlayTitle) overlayTitle.textContent = title;
      if (overlayName) overlayName.textContent = ticket.name || '';
      if (overlayCode) overlayCode.textContent = ticket.code || '';
      if (overlayMeta) overlayMeta.textContent = meta;
      if (continueBtn) continueBtn.textContent = 'QUÉT VÉ TIẾP →';
      feedback(type === 'success' ? 'success' : 'error');
    }

    function hideOverlay() {
      if (!overlay) return;
      overlay.className = 'vww-scan-success';
      overlay.setAttribute('aria-hidden', 'true');
    }

    function config() {
      var size = Math.max(190, Math.min(280, Math.floor(reader.clientWidth * 0.58)));
      return { fps: 10, qrbox: { width: size, height: size }, aspectRatio: 1 };
    }

    function rearIndex(list) {
      var pattern = /back|rear|environment|traseira|arrière|hinten|sau|后置|後置|후면/i;
      var index = list.findIndex(function (item) { return pattern.test(item.label || ''); });
      return index >= 0 ? index : Math.max(0, list.length - 1);
    }

    function stopCamera(keepPreview) {
      if (!scanner || !running) {
        setControls(false);
        return Promise.resolve();
      }
      return scanner.stop().catch(function () {}).then(function () {
        setControls(false);
        if (!keepPreview) {
          reader.innerHTML = '<div class="vww-camera-off-state"><span aria-hidden="true">◉</span><strong>Camera đang tắt</strong><p>Bấm “Mở camera” để bắt đầu quét QR.</p></div>';
          setStatus('Camera tắt', 'is-idle');
        }
      });
    }

    function startCamera(camera) {
      if (!scanner) scanner = new Html5Qrcode('vww-reader');
      activeCamera = camera;
      setStatus('Đang mở…', 'is-idle');
      return scanner.start(camera, config(), function (text) {
        if (locked || busy) return;
        locked = true;
        setStatus('Đã nhận QR', 'is-idle');
        stopCamera(true).then(function () { checkin(text, true); });
      }, function () {}).then(function () {
        setControls(true);
        setStatus('Đang quét', 'is-active');
        if (cameraName && cameras[cameraIndex]) cameraName.textContent = cameras[cameraIndex].label || 'Camera đang hoạt động';
      });
    }

    function openCamera() {
      if (busy || running || locked) return;
      hideOverlay();
      reader.innerHTML = '<p>Đang yêu cầu quyền truy cập Camera…</p>';
      setStatus('Đang mở…', 'is-idle');
      if (!scanner && window.Html5Qrcode) scanner = new Html5Qrcode('vww-reader');
      Html5Qrcode.getCameras().then(function (list) {
        cameras = list || [];
        if (!cameras.length) throw new Error('no_camera');
        cameraIndex = rearIndex(cameras);
        return startCamera(cameras[cameraIndex].id);
      }).catch(function (firstError) {
        return startCamera({ facingMode: { exact: 'environment' } }).catch(function () {
          return startCamera({ facingMode: 'environment' });
        }).catch(function () { throw firstError; });
      }).catch(cameraError);
    }

    function continueScanning() {
      if (busy) return;
      hideOverlay();
      locked = false;
      show('Sẵn sàng quét Vé Mời tiếp theo.', '');
      if (activeCamera) {
        startCamera(activeCamera).catch(cameraError);
      } else {
        openCamera();
      }
    }

    function checkin(code, fromCamera, skipConfirm) {
      code = String(code || '').trim();
      if (!code || busy) return Promise.resolve(false);
      if (!fromCamera && !skipConfirm) {
        if (window.VWWStaffConfirm) {
          return window.VWWStaffConfirm({
            title: 'Xác nhận Check-in',
            body: '<div class="vww-staff-modal-person"><b>Mã vé thủ công</b><code>' + esc(code) + '</code></div>',
            confirmLabel: 'XÁC NHẬN CHECK-IN'
          }).then(function (confirmed) { return confirmed ? checkin(code, false, true) : false; });
        }
        if (!window.confirm('Xác nhận check-in mã vé “' + code + '”?')) return Promise.resolve(false);
      }
      busy = true;
      submit.disabled = true;
      submit.textContent = 'Đang kiểm tra…';
      return fetch(VWWScanner.endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': VWWScanner.nonce },
        body: JSON.stringify({ code: code })
      }).then(function (response) {
        return response.json().catch(function () { return {}; }).then(function (body) {
          return { ok: response.ok, status: response.status, body: body || {} };
        });
      }).then(function (response) {
        var data = response.body || {};
        var ticket = data.ticket || {};
        if (response.ok && data.ok) {
          input.value = '';
          show('<strong>✓ CHECK-IN THÀNH CÔNG</strong><br><b>' + esc(ticket.name) + '</b> · ' + esc(ticket.code), 'success');
          if (fromCamera) overlayState('success', ticket, data.message);
          document.dispatchEvent(new CustomEvent('vww:ticket-updated', { detail: { ticket: ticket } }));
          return true;
        }
        if (fromCamera) {
          if (data.duplicate) overlayState('duplicate', ticket, data.message);
          else if (response.status === 404) overlayState('notfound', ticket, data.message);
          else overlayState('error', ticket, data.message || 'Vé không đủ điều kiện check-in.');
        }
        show('<strong>' + (data.duplicate ? 'VÉ ĐÃ CHECK IN' : (response.status === 404 ? 'VÉ KHÔNG TỒN TẠI' : 'KHÔNG THỂ CHECK-IN')) + '</strong><br>' + esc(data.message || 'Mã vé không hợp lệ.') + (ticket.name ? '<br><small>' + esc(ticket.name) + ' · ' + esc(ticket.code) + '</small>' : ''), 'error');
        return false;
      }).catch(function () {
        if (fromCamera) overlayState('error', {}, 'Không kết nối được tới hệ thống. Vui lòng thử lại.');
        show('Không kết nối được tới hệ thống. Vui lòng thử lại.', 'error');
        return false;
      }).finally(function () {
        busy = false;
        submit.disabled = false;
        submit.textContent = 'Xác nhận check-in';
        // Intentionally do not auto-restart after camera scans. Staff must confirm the result.
        if (fromCamera) {
          setStatus('Chờ xác nhận', 'is-idle');
          setControls(false);
        }
      });
    }

    submit.addEventListener('click', function () { checkin(input.value, false); });
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        checkin(input.value, false);
      }
    });
    if (continueBtn) continueBtn.addEventListener('click', continueScanning);

    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      cameraError(new Error(!window.isSecureContext ? 'insecure' : 'unsupported'));
      return;
    }
    if (!window.Html5Qrcode) {
      setStatus('Bộ quét lỗi', 'is-error');
      reader.innerHTML = '<div class="vww-camera-help"><strong>Không tải được bộ quét QR</strong><span>Hãy tải lại trang hoặc dùng ô nhập mã vé thủ công.</span></div>';
      return;
    }

    scanner = new Html5Qrcode('vww-reader');
    if (startBtn) startBtn.addEventListener('click', openCamera);
    if (stopBtn) stopBtn.addEventListener('click', function () { stopCamera(false); });
    if (switchBtn) switchBtn.addEventListener('click', function () {
      if (busy || locked || cameras.length < 2) return;
      switchBtn.disabled = true;
      stopCamera(true).then(function () {
        cameraIndex = (cameraIndex + 1) % cameras.length;
        return startCamera(cameras[cameraIndex].id);
      }).catch(cameraError).finally(function () { switchBtn.disabled = false; });
    });

    window.VWWScannerController = {
      open: openCamera,
      stop: function () { return stopCamera(false); },
      isRunning: function () { return running; },
      isLocked: function () { return locked; }
    };

    setStatus('Camera tắt', 'is-idle');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initScanner);
  else initScanner();
}());

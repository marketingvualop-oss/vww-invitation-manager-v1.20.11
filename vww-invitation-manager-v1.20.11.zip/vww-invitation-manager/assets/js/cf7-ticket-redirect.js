(function () {
  'use strict';

  var ATTRIBUTION_KEY = 'vww_attribution_v2';
  var ATTRIBUTION_MAX_AGE = 30 * 24 * 60 * 60 * 1000;

  function randomId() {
    if (window.crypto && window.crypto.getRandomValues) {
      var bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      return Array.prototype.map.call(bytes, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
    }
    return String(Date.now()) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  }

  function fieldsFromEvent(event) {
    var fields = {};
    var inputs = event && event.detail && Array.isArray(event.detail.inputs) ? event.detail.inputs : [];
    inputs.forEach(function (item) {
      if (!item || !item.name || /^_wpcf7/.test(item.name)) return;
      if (Object.prototype.hasOwnProperty.call(fields, item.name)) {
        fields[item.name] = [].concat(fields[item.name], item.value);
      } else {
        fields[item.name] = item.value;
      }
    });
    return fields;
  }

  function sourceFromReferrer(referrer) {
    if (!referrer) return 'Truy cập trực tiếp';
    try {
      var host = new URL(referrer).hostname.replace(/^www\./, '').toLowerCase();
      var sources = [
        [/((^|\.)zalo\.me$|(^|\.)zaloapp\.com$)/, 'Zalo'],
        [/((^|\.)facebook\.com$|(^|\.)fb\.com$)/, 'Facebook'],
        [/(^|\.)instagram\.com$/, 'Instagram'],
        [/(^|\.)tiktok\.com$/, 'TikTok'],
        [/(^|\.)youtube\.com$/, 'YouTube'],
        [/(^|\.)google\./, 'Google']
      ];
      for (var i = 0; i < sources.length; i += 1) {
        if (sources[i][0].test(host)) return sources[i][1];
      }
      return host;
    } catch (e) {
      return 'Không xác định';
    }
  }

  function readStoredAttribution() {
    try {
      var value = JSON.parse(window.localStorage.getItem(ATTRIBUTION_KEY) || 'null');
      if (value && value.saved_at && Date.now() - Number(value.saved_at) < ATTRIBUTION_MAX_AGE) return value;
    } catch (e) {}
    return null;
  }

  function currentAttribution() {
    var query = new URLSearchParams(window.location.search);
    var referrer = document.referrer || '';
    var taggedSource = query.get('utm_source') || query.get('vww_source') || '';
    var hasCampaign = Boolean(taggedSource || query.get('utm_medium') || query.get('utm_campaign') || query.get('utm_content') || query.get('utm_term'));
    var stored = readStoredAttribution();

    // A deliberately tagged campaign is newer, stronger evidence than a saved
    // direct/referral visit. Untagged pages keep the prior source for 30 days.
    if (stored && !hasCampaign) return stored;

    var data = {
      saved_at: Date.now(),
      vww_first_source: taggedSource || sourceFromReferrer(referrer),
      vww_first_referrer: referrer,
      vww_landing_page: window.location.href,
      vww_utm_source: query.get('utm_source') || taggedSource,
      vww_utm_medium: query.get('utm_medium') || '',
      vww_utm_campaign: query.get('utm_campaign') || '',
      vww_utm_content: query.get('utm_content') || '',
      vww_utm_term: query.get('utm_term') || '',
      vww_attributed_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
    };
    try { window.localStorage.setItem(ATTRIBUTION_KEY, JSON.stringify(data)); } catch (e) {}
    return data;
  }

  // Reading the URL and saving attribution never changes a CF7 form or mail request.
  currentAttribution();

  document.addEventListener('wpcf7mailsent', function (event) {
    var config = window.VWWCF7Config || {};
    var configuredId = String(config.formId || '');
    var submittedId = event && event.detail ? String(event.detail.contactFormId || '') : '';
    if (!configuredId || submittedId !== configuredId || !config.endpoint) return;

    var form = event.target && event.target.matches && event.target.matches('form') ? event.target : null;
    var submissionId = form && form.dataset.vwwSubmissionId ? form.dataset.vwwSubmissionId : randomId();
    if (form) form.dataset.vwwSubmissionId = submissionId;

    var payload = {
      form_id: submittedId,
      submission_id: submissionId,
      fields: Object.assign(fieldsFromEvent(event), currentAttribution()),
      page_url: window.location.href,
      page_title: document.title,
      referrer: document.referrer || ''
    };

    fetch(config.endpoint, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': String(config.nonce || '') },
      body: JSON.stringify(payload)
    }).then(function (response) {
      if (!response.ok) throw new Error('ticket_api_' + response.status);
      return response.json();
    }).then(function (data) {
      if (data && data.ticket_url) window.location.assign(data.ticket_url);
    }).catch(function (error) {
      if (window.console && console.warn) console.warn('VWW: CF7 đã gửi thành công; chưa thể tạo/chuyển tới vé.', error);
    });
  });
})();

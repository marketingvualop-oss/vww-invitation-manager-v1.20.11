(function () {
  function initDashboard() {
    var rows = document.getElementById('vww-dashboard-rows');
    var search = document.getElementById('vww-dashboard-search');
    var status = document.getElementById('vww-dashboard-status');
    var interest = document.getElementById('vww-dashboard-interest');
    var eventName = document.getElementById('vww-dashboard-event');
    var source = document.getElementById('vww-dashboard-source');
    var registrationUrl = document.getElementById('vww-dashboard-registration-url');
    var batch = document.getElementById('vww-dashboard-batch');
    var dateType = document.getElementById('vww-dashboard-date-type');
    var dateFrom = document.getElementById('vww-dashboard-date-from');
    var dateTo = document.getElementById('vww-dashboard-date-to');
    var refresh = document.getElementById('vww-dashboard-refresh');
    var count = document.getElementById('vww-dashboard-count');
    var sync = document.getElementById('vww-dashboard-sync');
    var notice = document.getElementById('vww-dashboard-notice');
    var prev = document.getElementById('vww-page-prev');
    var next = document.getElementById('vww-page-next');
    var pageLabel = document.getElementById('vww-page-label');
    var selectPage = document.getElementById('vww-select-page');
    var selectPageHead = document.getElementById('vww-select-page-head');
    var selectFiltered = document.getElementById('vww-select-filtered');
    var selectedCount = document.getElementById('vww-selected-count');
    var bulkAction = document.getElementById('vww-bulk-action');
    var applyBulk = document.getElementById('vww-apply-bulk');
    var bulkBar = document.querySelector('.vww-bulk-bar');
    var advancedToggle = document.getElementById('vww-toggle-advanced');
    var advancedFilters = document.getElementById('vww-advanced-filters');
    if (!rows || !search || !status || !interest || !window.VWWDashboard) return;

    var state = {
      page: 1,
      pages: 1,
      total: 0,
      view: '',
      selected: new Set(),
      selectAllFiltered: false,
      visibleIds: [],
      request: 0
    };
    var debounceTimer = null;
    var bulkActionLabels = {
      confirm_send: 'Xác nhận & Gửi vé',
      resend: 'Gửi lại Vé Mời',
      mark_checked_in: 'Đánh dấu đã check-in',
      undo_checkin: 'Chuyển về chưa check-in',
      cancel: 'Hủy vé',
      restore_cancelled: 'Khôi phục vé đã hủy',
      trash: 'Chuyển vào thùng rác',
      restore_trash: 'Khôi phục từ thùng rác',
      delete_permanently: 'Xóa vĩnh viễn',
      export_selected: 'Xuất Excel vé đã chọn'
    };

    function availableBulkActions() {
      if (state.view === 'trash') return ['restore_trash', 'delete_permanently', 'export_selected'];
      switch (status.value) {
        case 'registered':
        case 'issued':
          return ['confirm_send', 'resend', 'cancel', 'trash', 'export_selected'];
        case 'emailed':
          return ['resend', 'mark_checked_in', 'cancel', 'trash', 'export_selected'];
        case 'checked_in':
          return ['resend', 'undo_checkin', 'trash', 'export_selected'];
        case 'cancelled':
          return ['resend', 'restore_cancelled', 'trash', 'export_selected'];
        default:
          return ['resend', 'cancel', 'trash', 'export_selected'];
      }
    }

    function updateBulkActions() {
      if (!bulkAction) return;
      var current = bulkAction.value;
      var actions = availableBulkActions();
      bulkAction.innerHTML = '<option value="">Thao tác hàng loạt</option>';
      actions.forEach(function (action) {
        var option = document.createElement('option');
        option.value = action;
        option.textContent = bulkActionLabels[action];
        if (action === 'delete_permanently') option.className = 'vww-danger-option';
        bulkAction.appendChild(option);
      });
      bulkAction.value = actions.indexOf(current) !== -1 ? current : '';
      bulkAction.classList.toggle('is-danger', bulkAction.value === 'delete_permanently');
    }

    function escapeHtml(value) {
      var div = document.createElement('div');
      div.textContent = value == null ? '' : String(value);
      return div.innerHTML;
    }

    function showNotice(message, type) {
      if (!notice) return;
      notice.hidden = false;
      notice.className = 'vww-dashboard-notice ' + (type || '');
      notice.textContent = message;
      window.setTimeout(function () { notice.hidden = true; }, 6500);
    }

    function setText(id, value) {
      var element = document.getElementById(id);
      if (element) element.textContent = String(value || 0);
    }

    function updateStats(stats, counts) {
      stats = stats || {};
      counts = counts || {};
      setText('vww-stat-total', stats.total);
      setText('vww-stat-checked', stats.checked);
      setText('vww-stat-waiting', stats.waiting);
      setText('vww-stat-today', stats.today);
      Object.keys(counts).forEach(function (key) { setText('vww-count-' + key, counts[key]); });
    }

    function populateSelect(select, items, valueKey, labelKey) {
      if (!select) return;
      var current = select.value;
      while (select.options.length > 1) select.remove(1);
      (items || []).forEach(function (item) {
        var option = document.createElement('option');
        option.value = valueKey ? item[valueKey] : item;
        option.textContent = labelKey ? item[labelKey] : item;
        select.appendChild(option);
      });
      if (Array.prototype.some.call(select.options, function (option) { return option.value === current; })) {
        select.value = current;
      }
    }

    function filters() {
      return {
        q: search.value.trim(),
        status: status.value,
        interest: interest.value,
        event_name: eventName ? eventName.value : '',
        source: source ? source.value : '',
        registration_url: registrationUrl ? registrationUrl.value : '',
        import_batch: batch ? batch.value : '',
        date_type: dateType ? dateType.value : 'created',
        date_from: dateFrom ? dateFrom.value : '',
        date_to: dateTo ? dateTo.value : '',
        view: state.view
      };
    }

    function appendFilters(url, includePage) {
      var active = filters();
      Object.keys(active).forEach(function (key) {
        if (active[key]) url.searchParams.set(key, active[key]);
      });
      if (includePage) {
        url.searchParams.set('page', String(state.page));
        url.searchParams.set('per_page', '100');
      }
      return url;
    }

    function listUrl() {
      return appendFilters(new URL(VWWDashboard.listEndpoint, window.location.origin), true).toString();
    }

    function updateSelectionText() {
      if (!selectedCount) return;
      selectedCount.textContent = state.selectAllFiltered
        ? state.total + ' vé trong kết quả lọc đã chọn'
        : state.selected.size + ' vé đã chọn';
      var allVisible = state.visibleIds.length && state.visibleIds.every(function (id) { return state.selected.has(id); });
      if (selectPage) selectPage.checked = !!allVisible;
      if (selectPageHead) selectPageHead.checked = !!allVisible;
      if (bulkBar) bulkBar.hidden = !(state.selectAllFiltered || state.selected.size);
    }

    function actionHtml(ticket) {
      var html = '<div class="vww-row-actions">';
      if (ticket.trashed) {
        html += '<span class="vww-action-muted">Trong thùng rác</span>';
      } else if (ticket.confirmable && VWWDashboard.canManage) {
        html += '<button type="button" class="button button-primary vww-row-confirm" data-id="' + ticket.id + '">Xác nhận &amp; Gửi vé</button>';
      } else if (ticket.checkinable) {
        html += '<button type="button" class="button button-primary vww-row-checkin" data-code="' + escapeHtml(ticket.code) + '">Check-in</button>';
      } else if (ticket.status === 'checked_in') {
        html += '<span class="vww-action-done">✓ Đã xong</span>';
      }
      if (VWWDashboard.canManage && ticket.editUrl && !ticket.trashed) {
        html += '<a class="button" href="' + escapeHtml(ticket.editUrl) + '">Sửa</a>';
      }
      if (VWWDashboard.canManage && ticket.resendable) {
        html += '<details class="vww-row-more"><summary class="button" aria-label="Thao tác khác">⋮</summary><div class="vww-row-menu"><button type="button" class="button-link vww-row-resend" data-id="' + ticket.id + '">Email lại</button></div></details>';
      }
      return html + '</div>';
    }

    function renderRows(tickets) {
      state.visibleIds = (tickets || []).map(function (ticket) { return Number(ticket.id); });
      if (!tickets || !tickets.length) {
        rows.innerHTML = '<tr><td colspan="' + (VWWDashboard.canManage ? 7 : 6) + '">Không tìm thấy vé phù hợp.</td></tr>';
        updateSelectionText();
        return;
      }
      rows.innerHTML = tickets.map(function (ticket) {
        var id = Number(ticket.id);
        var checked = state.selectAllFiltered || state.selected.has(id);
        var checkedMeta = ticket.checkedAt ? '<small>' + escapeHtml(ticket.checkedAt) + (ticket.checkedBy ? ' · ' + escapeHtml(ticket.checkedBy) : '') + '</small>' : '';
        var checkbox = VWWDashboard.canManage ? '<th class="check-column"><input type="checkbox" class="vww-row-select" data-id="' + id + '" ' + (checked ? 'checked' : '') + '></th>' : '';
        var sourceDetails = [ticket.utmMedium, ticket.utmCampaign, ticket.referrerDomain].filter(Boolean).join(' · ');
        var sourceLink = ticket.landingPage || ticket.registrationUrl;
        return '<tr class="' + (ticket.trashed ? 'is-trashed' : '') + '">' + checkbox +
          '<td><strong>' + escapeHtml(ticket.code) + '</strong><br><b>' + escapeHtml(ticket.name) + '</b></td>' +
          '<td>' + escapeHtml(ticket.phone || '—') + '<br><small>' + escapeHtml(ticket.email || '') + '</small></td>' +
          '<td><b>' + escapeHtml(ticket.event || '—') + '</b><br><small>' + escapeHtml(ticket.interest || '—') + '</small>' + (ticket.createdAt ? '<br><small class="vww-created-at">Thời gian đăng ký: ' + escapeHtml(ticket.createdAt) + '</small>' : '') + '</td>' +
          '<td><b>' + escapeHtml(ticket.source || 'Chưa ghi nhận') + '</b>' + (sourceDetails ? '<br><small>' + escapeHtml(sourceDetails) + '</small>' : '') + (sourceLink ? '<br><a class="vww-source-link" href="' + escapeHtml(sourceLink) + '" target="_blank" rel="noopener noreferrer" title="' + escapeHtml(sourceLink) + '">Mở landing page ↗</a>' : '') + '</td>' +
          '<td><span class="vww-status ' + escapeHtml(ticket.status) + '">' + escapeHtml(ticket.statusLabel) + '</span>' + checkedMeta + '</td>' +
          '<td>' + actionHtml(ticket) + '</td></tr>';
      }).join('');
      updateSelectionText();
    }

    function loadTickets(silent) {
      var requestNumber = ++state.request;
      if (!silent) count.textContent = 'Đang tải danh sách…';
      return fetch(listUrl(), {
        method: 'GET',
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': VWWDashboard.nonce }
      }).then(function (response) {
        return response.json().then(function (body) {
          if (!response.ok) throw new Error(body.message || 'Không tải được danh sách vé.');
          return body;
        });
      }).then(function (data) {
        if (requestNumber !== state.request) return;
        state.page = data.page || 1;
        state.pages = data.pages || 1;
        state.total = data.total || 0;
        renderRows(data.tickets || []);
        populateSelect(interest, data.interests || []);
        populateSelect(eventName, data.events || []);
        populateSelect(source, data.sources || []);
        populateSelect(registrationUrl, data.registrationUrls || []);
        populateSelect(batch, data.batches || [], 'id', 'batch_code');
        updateStats(data.stats, data.counts);
        count.textContent = state.total + ' vé phù hợp';
        sync.textContent = 'Cập nhật lúc ' + (data.syncedAt || '—') + ' · bấm ↻ để làm mới';
        if (pageLabel) pageLabel.textContent = 'Trang ' + state.page + ' / ' + state.pages;
        if (prev) prev.disabled = state.page <= 1;
        if (next) next.disabled = state.page >= state.pages;
      }).catch(function (error) {
        if (requestNumber !== state.request) return;
        rows.innerHTML = '<tr><td colspan="' + (VWWDashboard.canManage ? 7 : 6) + '">Không tải được dữ liệu.</td></tr>';
        showNotice(error.message, 'error');
      });
    }

    function apiPost(endpoint, payload) {
      return fetch(endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': VWWDashboard.nonce },
        body: JSON.stringify(payload || {})
      }).then(function (response) {
        return response.json().then(function (body) {
          if (!response.ok || !body.ok) throw new Error(body.message || 'Không thể xử lý yêu cầu.');
          return body;
        });
      });
    }

    function rowAction(button, endpoint, busyText) {
      var idle = button.textContent;
      button.disabled = true;
      button.textContent = busyText;
      apiPost(endpoint, {}).then(function (data) {
        showNotice('✓ ' + data.message, 'success');
      }).catch(function (error) {
        showNotice(error.message, 'error');
      }).finally(function () {
        button.disabled = false;
        button.textContent = idle;
        loadTickets(true);
      });
    }

    rows.addEventListener('click', function (event) {
      var confirmButton = event.target.closest('.vww-row-confirm');
      if (confirmButton) {
        rowAction(confirmButton, String(VWWDashboard.ticketEndpoint).replace(/\/$/, '') + '/' + confirmButton.dataset.id + '/confirm', 'Đang gửi…');
        return;
      }
      var resendButton = event.target.closest('.vww-row-resend');
      if (resendButton) {
        rowAction(resendButton, String(VWWDashboard.ticketEndpoint).replace(/\/$/, '') + '/' + resendButton.dataset.id + '/resend', 'Đang gửi…');
        return;
      }
      var checkinButton = event.target.closest('.vww-row-checkin');
      if (checkinButton) {
        checkinButton.disabled = true;
        checkinButton.textContent = 'Đang xử lý…';
        apiPost(VWWDashboard.checkinEndpoint, { code: checkinButton.dataset.code }).then(function (data) {
          showNotice('✓ Đã check-in ' + (data.ticket.name || checkinButton.dataset.code), 'success');
        }).catch(function (error) {
          showNotice(error.message, 'error');
        }).finally(function () {
          checkinButton.disabled = false;
          checkinButton.textContent = 'Check-in';
          loadTickets(true);
        });
      }
    });

    rows.addEventListener('change', function (event) {
      if (!event.target.classList.contains('vww-row-select')) return;
      state.selectAllFiltered = false;
      var id = Number(event.target.dataset.id);
      if (event.target.checked) state.selected.add(id);
      else state.selected.delete(id);
      updateSelectionText();
    });

    function resetSelection() {
      state.selected.clear();
      state.selectAllFiltered = false;
      updateSelectionText();
    }

    function filtersChanged() {
      state.page = 1;
      resetSelection();
      updateBulkActions();
      loadTickets(false);
    }

    search.addEventListener('input', function () {
      window.clearTimeout(debounceTimer);
      debounceTimer = window.setTimeout(filtersChanged, 350);
    });
    [status, interest, eventName, source, registrationUrl, batch, dateType, dateFrom, dateTo].forEach(function (element) {
      if (element) element.addEventListener('change', filtersChanged);
    });

    Array.prototype.forEach.call(document.querySelectorAll('.vww-quick-tabs button'), function (button) {
      button.addEventListener('click', function () {
        document.querySelectorAll('.vww-quick-tabs button').forEach(function (item) { item.classList.remove('is-active'); });
        button.classList.add('is-active');
        state.view = button.dataset.view || '';
        status.value = button.dataset.status || '';
        filtersChanged();
      });
    });

    if (refresh) refresh.addEventListener('click', function () {
      refresh.disabled = true;
      refresh.textContent = '↻ Đang tải…';
      loadTickets(false).finally(function () {
        refresh.disabled = false;
        refresh.textContent = '↻ Làm mới';
      });
    });
    if (advancedToggle && advancedFilters) advancedToggle.addEventListener('click', function () {
      var opening = advancedFilters.hidden;
      advancedFilters.hidden = !opening;
      advancedToggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
      advancedToggle.textContent = opening ? 'Thu gọn bộ lọc' : 'Bộ lọc nâng cao';
    });
    if (prev) prev.addEventListener('click', function () { if (state.page > 1) { state.page--; loadTickets(false); } });
    if (next) next.addEventListener('click', function () { if (state.page < state.pages) { state.page++; loadTickets(false); } });

    function togglePage(checked) {
      state.selectAllFiltered = false;
      state.visibleIds.forEach(function (id) {
        if (checked) state.selected.add(id);
        else state.selected.delete(id);
      });
      Array.prototype.forEach.call(document.querySelectorAll('.vww-row-select'), function (box) { box.checked = checked; });
      updateSelectionText();
    }
    if (selectPage) selectPage.addEventListener('change', function () { togglePage(selectPage.checked); });
    if (selectPageHead) selectPageHead.addEventListener('change', function () { togglePage(selectPageHead.checked); });
    if (selectFiltered) selectFiltered.addEventListener('click', function () {
      state.selectAllFiltered = true;
      state.selected.clear();
      document.querySelectorAll('.vww-row-select').forEach(function (box) { box.checked = true; });
      updateSelectionText();
    });
    if (bulkAction) bulkAction.addEventListener('change', function () {
      bulkAction.classList.toggle('is-danger', bulkAction.value === 'delete_permanently');
    });

    function exportUrl(base, selectedOnly) {
      var url = appendFilters(new URL(base, window.location.origin), false);
      if (selectedOnly && !state.selectAllFiltered && state.selected.size) {
        url.searchParams.set('ids', Array.from(state.selected).join(','));
      }
      return url.toString();
    }
    var exportXlsx = document.getElementById('vww-export-xlsx');
    var exportCsv = document.getElementById('vww-export-csv');
    if (exportXlsx) exportXlsx.addEventListener('click', function () { window.location.href = exportUrl(VWWDashboard.exportXlsxUrl, false); });
    if (exportCsv) exportCsv.addEventListener('click', function () { window.location.href = exportUrl(VWWDashboard.exportCsvUrl, false); });

    if (applyBulk) applyBulk.addEventListener('click', function () {
      var action = bulkAction.value;
      if (!action) {
        showNotice('Hãy chọn một thao tác hàng loạt.', 'error');
        return;
      }
      if (!state.selectAllFiltered && !state.selected.size) {
        showNotice('Hãy chọn ít nhất một vé.', 'error');
        return;
      }
      if (action === 'export_selected') {
        window.location.href = exportUrl(VWWDashboard.exportXlsxUrl, true);
        return;
      }
      var labels = {
        confirm_send: 'xác nhận và gửi Vé Mời',
        resend: 'gửi lại Vé Mời',
        mark_checked_in: 'đánh dấu đã check-in',
        undo_checkin: 'chuyển về chưa check-in',
        cancel: 'hủy',
        restore_cancelled: 'khôi phục vé đã hủy',
        trash: 'chuyển vào thùng rác',
        restore_trash: 'khôi phục từ thùng rác',
        delete_permanently: 'XÓA VĨNH VIỄN'
      };
      var selectedLabel = state.selectAllFiltered ? state.total + ' vé trong kết quả lọc' : state.selected.size + ' vé';
      if (!window.confirm('Bạn chắc chắn muốn ' + labels[action] + ' ' + selectedLabel + '?')) return;
      if (action === 'mark_checked_in' && !window.confirm('Thời gian check-in sẽ được ghi nhận theo thời điểm hiện tại. Tiếp tục?')) return;
      if (action === 'undo_checkin' && !window.confirm('Kết quả check-in hiện tại sẽ bị hủy nhưng vẫn được lưu trong nhật ký. Tiếp tục?')) return;
      if (action === 'delete_permanently' && !window.confirm('CẢNH BÁO: ' + selectedLabel + ' sẽ bị xóa khỏi hệ thống và không thể khôi phục. Tiếp tục?')) return;
      var reason = action === 'cancel' ? (window.prompt('Lý do hủy vé (không bắt buộc):', '') || '') : '';
      applyBulk.disabled = true;
      apiPost(VWWDashboard.bulkEndpoint, {
        action: action,
        ids: Array.from(state.selected),
        select_all: state.selectAllFiltered,
        filters: filters(),
        reason: reason
      }).then(function (data) {
        showNotice('✓ ' + data.message, 'success');
        resetSelection();
        bulkAction.value = '';
      }).catch(function (error) {
        showNotice(error.message, 'error');
      }).finally(function () {
        applyBulk.disabled = false;
        loadTickets(true);
      });
    });

    document.addEventListener('vww:ticket-updated', function () { loadTickets(true); });
    updateBulkActions();
    loadTickets(false);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initDashboard);
  else initDashboard();
}());

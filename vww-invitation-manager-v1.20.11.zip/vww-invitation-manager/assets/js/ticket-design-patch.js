document.addEventListener('DOMContentLoaded', function () {
    'use strict';
    var frame = document.getElementById('vww-ticket-preview');
    var editor = document.querySelector('[data-vww-custom-css]');
    if (!frame || !editor) return;
    function applyCss() {
        if (!frame.contentDocument) return;
        var style = frame.contentDocument.getElementById('vww-preview-custom-css');
        if (!style) {
            style = frame.contentDocument.createElement('style');
            style.id = 'vww-preview-custom-css';
            frame.contentDocument.head.appendChild(style);
        }
        style.textContent = editor.value || '';
    }
    frame.addEventListener('load', applyCss);
    editor.addEventListener('input', applyCss);
    applyCss();
});

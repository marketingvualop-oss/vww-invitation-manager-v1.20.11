<?php
/**
 * Plugin Name: VWW Invitation Manager
 * Description: Quản lý vé mời Vietnam Wedding Week: Contact Form 7, Excel, email QR và check-in.
 * Version: 1.20.11
 * Author: VWW
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: vww-invitation-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'VWW_IM_FILE', __FILE__ );
define( 'VWW_IM_DIR', plugin_dir_path( __FILE__ ) );

require_once VWW_IM_DIR . 'includes/class-vww-xlsx.php';
require_once VWW_IM_DIR . 'includes/class-vww-invitation-manager.php';

register_activation_hook( __FILE__, array( 'VWW_Invitation_Manager', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'VWW_Invitation_Manager', 'deactivate' ) );

VWW_Invitation_Manager::instance();
